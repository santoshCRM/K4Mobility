using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class UpdateOpportunityLine : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[RequiredArgument]
		[Input("OpportunityLine")]
		[ReferenceTarget("opportunityproduct")]
		public InArgument<EntityReference> OpportunityLine
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("ProductSubType")]
		public InArgument<string> ProductSubType
		{
			get;
			set;
		}
        [Input("OppProductSubType")]
        public InArgument<string> OppProductSubType
        {
            get;
            set;
        }

        [Input("ProductTaxPercentage")]
		public InArgument<string> ProductTaxPercentage
		{
			get;
			set;
		}

        [Input("OppTaxPercentage")]
        public InArgument<string> OppTaxPercentage
        {
            get;
            set;
        }
        [RequiredArgument]
		[Input("ProductDicountPercentage")]
		public InArgument<string> ProductDicountPercentage
		{
			get;
			set;
		}
        [Input("PromoCodeDiscountPercentage")]
        public InArgument<string> PromoCodeDiscountPercentage
        {
            get;
            set;
        }
        [Input("OppDicountPercentage")]
        public InArgument<string> OppDicountPercentage
        {
            get;
            set;
        }
        [RequiredArgument]
		[Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}
        [Input("OppAmount")]
        public InArgument<Money> OppAmount
        {
            get;
            set;
        }
        [Input("k4_purchasevalue")]
        public InArgument<Money> k4_purchasevalue
        {
            get;
            set;
        }
        [Input("Operator")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Operator
        {
            get;
            set;
        }
        [Input("Activation Date")]
        public InArgument<DateTime> ActivationDate
        {
            get;
            set;
        }
        [Input("DeActivation Date")]
        public InArgument<DateTime> DeActivationDate
        {
            get;
            set;
        }
        [Input("Contract Length")]
        public InArgument<decimal> k4_contractlength
        {
            get;
            set;
        }
        [Input("OnGoing")]
        public InArgument<bool> k4_activated
        {
            get;
            set;
        }

        #endregion
        #region Execute  function

        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (OpportunityLine.Get<EntityReference>(executionContext) != null)
                {
                    Entity MyOpportunityLine = new Entity(OpportunityLine.Get<EntityReference>(executionContext).LogicalName,
                        OpportunityLine.Get<EntityReference>(executionContext).Id);
                    decimal numP = Convert.ToDecimal("0.00");//promodiscout
                    if (OppProductSubType.Get<string>(executionContext) != null)
                    {

                    }
                    else
                    {
                        if (ProductSubType.Get<string>(executionContext) != null)
                        {
                            if (ProductSubType.Get<string>(executionContext) == "Subscription")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130000);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Top Up Plan-VSAT")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130001);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "HardWare")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130002);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Top Up Plan-4G")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130003);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Hardware Installation Fee")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130004);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "VSAT Activation Fees")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130005);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "VoIP Activation Fees")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130006);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Survey Fee")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130007);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "4G Activation Fees")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130008);
                            }
                            traceMessage += ProductSubType.Get<string>(executionContext).ToString();
                        }
                    }
                    if (Operator.Get<EntityReference>(executionContext) != null)
                    {
                        MyOpportunityLine.Attributes["msdyn_serviceaccount"] = Operator.Get<EntityReference>(executionContext);
                    }
                    decimal numD = Convert.ToDecimal("0.00");//discount
                    decimal numT = Convert.ToDecimal("0.00");//tax
                    MyOpportunityLine.Attributes["manualdiscountamount"] = new Money(numD);
                    MyOpportunityLine.Attributes["tax"] = new Money(numT);
                    decimal baseAmount = Convert.ToDecimal("0.00");
                    if (OppAmount.Get<Money>(executionContext) != null && OppAmount.Get<Money>(executionContext).Value > 0)
                        baseAmount = OppAmount.Get<Money>(executionContext).Value;
                    else if (Amount.Get<Money>(executionContext) != null && Amount.Get<Money>(executionContext).Value > 0)
                        baseAmount = Amount.Get<Money>(executionContext).Value;
                    #region On going Opportunity product-yes

                    if (k4_activated.Get<bool>(executionContext))
                    {
                        //throw new InvalidPluginExecutionException("1");
                         if (ActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue && DeActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue)
                        {

                            if (k4_purchasevalue.Get<Money>(executionContext) != null)
                                baseAmount = k4_purchasevalue.Get<Money>(executionContext).Value;
                            else
                                MyOpportunityLine.Attributes["k4_purchasevalue"] = new Money(baseAmount);
                            decimal datediff = (DeActivationDate.Get<DateTime>(executionContext) - ActivationDate.Get<DateTime>(executionContext)).Days + 1;
                            baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(ActivationDate.Get<DateTime>(executionContext).Year,
                                ActivationDate.Get<DateTime>(executionContext).Month);
                        }
                        else
                            throw new InvalidPluginExecutionException("Activation or Deactivation date not found.");
                        MyOpportunityLine.Attributes["priceperunit"] = new Money(baseAmount);
                        MyOpportunityLine.Attributes["ispriceoverridden"] = true;
                    }
                    #endregion
                    #region Contract length present
                    if (k4_contractlength.Get<decimal>(executionContext) > 0 && ActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue)
                    {
                        //throw new InvalidPluginExecutionException("2");
                        if (k4_purchasevalue.Get<Money>(executionContext) != null)
                            baseAmount = k4_purchasevalue.Get<Money>(executionContext).Value;
                        else
                            MyOpportunityLine.Attributes["k4_purchasevalue"] = new Money(baseAmount);
                        if (ActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue)
                        {
                            decimal datediff = k4_contractlength.Get<decimal>(executionContext);
                            baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(ActivationDate.Get<DateTime>(executionContext).Year,
                                ActivationDate.Get<DateTime>(executionContext).Month);
                        }
                        else
                            throw new InvalidPluginExecutionException("Activation date not found.");
                        MyOpportunityLine.Attributes["priceperunit"] = new Money(baseAmount);
                        MyOpportunityLine.Attributes["ispriceoverridden"] = true;
                    }
                    #endregion

                    #region No contract length,On going-NO, have activation and deactivation date 
                    if (k4_contractlength.Get<decimal>(executionContext) == 0 && k4_activated.Get<bool>(executionContext) ==false
                        && ActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue &&
                        DeActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue)
                    {
                       // throw new InvalidPluginExecutionException("3:" +DeActivationDate.Get<DateTime>(executionContext).ToString());
                        if (k4_purchasevalue.Get<Money>(executionContext) != null)
                            baseAmount = k4_purchasevalue.Get<Money>(executionContext).Value;
                        else
                            MyOpportunityLine.Attributes["k4_purchasevalue"] = new Money(baseAmount);
                        decimal datediff = (DeActivationDate.Get<DateTime>(executionContext) - ActivationDate.Get<DateTime>(executionContext)).Days + 1;
                        baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(ActivationDate.Get<DateTime>(executionContext).Year,
                            ActivationDate.Get<DateTime>(executionContext).Month);
                        MyOpportunityLine.Attributes["priceperunit"] = new Money(baseAmount);
                        MyOpportunityLine.Attributes["ispriceoverridden"] = true;
                    }
                    #endregion
                    traceMessage += "/n1 OppAmount";
                    if (OppDicountPercentage.Get<string>(executionContext) != null)
                    {
                        numD = Convert.ToDecimal(OppDicountPercentage.Get<string>(executionContext));
                        traceMessage += "/n2";
                    }
                    else
                    {
                        if (ProductDicountPercentage.Get<string>(executionContext) != null)
                        {
                            numD = Convert.ToDecimal(ProductDicountPercentage.Get<string>(executionContext));
                            numD += numP;
                            MyOpportunityLine.Attributes["k4_discountpercentage"] = numD;
                            traceMessage += "/n3";
                        }
                    }
                    traceMessage += numD.ToString();
                    decimal num1 = baseAmount * numD / 100m;//Disount Amount calculated
                    MyOpportunityLine.Attributes["manualdiscountamount"] = new Money(num1);
                    //Tax
                    if (OppTaxPercentage.Get<string>(executionContext) != null)
                    {
                        traceMessage += "/n4";
                        numT = Convert.ToDecimal(OppTaxPercentage.Get<string>(executionContext));
                    }
                    else
                    {
                        if (ProductTaxPercentage.Get<string>(executionContext) != null)
                        {
                            traceMessage += "/n5";
                            numT = Convert.ToDecimal(ProductTaxPercentage.Get<string>(executionContext));
                            MyOpportunityLine.Attributes["k4_taxpercentage"] = numT;
                        }
                    }
                    traceMessage += numT.ToString();

                    decimal num2 = (baseAmount - num1) * numT / 100m;//Tax Amount calculated
                    MyOpportunityLine.Attributes["tax"] = new Money(num2);
                    // throw new InvalidPluginExecutionException("error occured in UpdateOpportunityLine workflow: " + traceMessage);
                    service.Update(MyOpportunityLine);
                }
			}
			catch (Exception ex)
			{
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("Error occured in UpdateOpportunityLine workflow: " + ex.Message.ToString());
			}
		}
        #endregion
        public static int GetMonthDifference(DateTime startDate, DateTime endDate)
        {
            int numMonths = 0;

            while (startDate.Year != endDate.Year || startDate.Month != endDate.Month)
            {
                startDate = startDate.AddMonths(1);
                numMonths++;
            }
            if (startDate.Year == endDate.Year && startDate.Month == endDate.Month)
            {
                numMonths++;
            }
            return numMonths;
        }
    }
}
