using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreatePaymentPlanChange : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;

        [RequiredArgument]
        [Input("Account")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("Activation Date")]
        public InArgument<DateTime> ActivationDate
        {
            get;
            set;
        }
        [RequiredArgument]
        [Input("Service Start Date")]
        public InArgument<DateTime> ServiceStartDate
        {
            get;
            set;
        }
        [Output("Service End Date")]
        public OutArgument<DateTime> ServiceEndDate
        {
            get;
            set;
        }
       
        [RequiredArgument]
        [Input("PlanDuration")]
        public InArgument<Int32> PlanDuration
        {
            get;
            set;
        }

        //[RequiredArgument]
        //[Input("NewVsatCost")]
        //public InArgument<Money> NewVsatCost
        //{
        //    get;
        //    set;
        //}
        //[RequiredArgument]
        //[Input("New4GCost")]
        //public InArgument<Money> New4GCost
        //{
        //    get;
        //    set;
        //}

        [RequiredArgument]
        [Input("OldVsatCost")]
        public InArgument<Money> OldVsatCost
        {
            get;
            set;
        }
        [RequiredArgument]
        [Input("Old4GCost")]
        public InArgument<Money> Old4GCost
        {
            get;
            set;
        }
        [Input("OldVsatPrice")]
        public InArgument<Money> OldVsatOveragePrice
        {
            get;
            set;
        }
        [Input("Old4GOveragePrice")]
        public InArgument<Money> Old4GOveragePrice
        {
            get;
            set;
        }
        [Input("Voip Rate")]
        public InArgument<Money> VoipRate
        {
            get;
            set;
        }



        [Input("Old Plan")]
        [ReferenceTarget("msdyn_customerasset")]
        public InArgument<EntityReference> OldPlan
        {
            get;
            set;
        }

        [Input("Old VSATPlan")]
        [ReferenceTarget("msdyn_customerasset")]
        public InArgument<EntityReference> OldVSATPlan
        {
            get;
            set;
        }

        [Input("Old 4GPlan")]
        [ReferenceTarget("msdyn_customerasset")]
        public InArgument<EntityReference> Old4GPlan
        {
            get;
            set;
        }



        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            #region variable used
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            decimal k4_baseplancost = 0.0m;
            decimal k4_associatedplancost = 0.0m;
            decimal k4_4gactivationfee = 0.0m;
            decimal k4_4gpackcost = 0.0m;
            decimal k4_voipfee = 0.0m;

            decimal k4_vsatoverageprice = 0.0m;
            decimal k4_4goverageprice = 0.0m;
            decimal k4_newvsatoverageprice = 0.0m;
            decimal k4_new4goverageprice = 0.0m;
            decimal k4_voiprate = 0.0m;

            Decimal OldVsatCost1 = 0.0m;
            Decimal Old4GCost1 = 0.0m;

            Decimal NewVsatCost1 = 0.0m;
            Decimal New4GCost1 = 0.0m;

            decimal k4_Arrear = 0.0m;
            decimal k4_OldPlanAmount = 0.0m;
            decimal k4_NewPlanAmount = 0.0m;

            EntityReference k4_newvsatplan = null;
            EntityReference k4_new4gplan = null;
            EntityReference k4_newplan = null;

            EntityReference k4_vsat = null;
            EntityReference k4_4gplan = null;
            EntityReference k4_plan = null;
            #endregion
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Account.Get<EntityReference>(executionContext) != null && ActivationDate.Get<DateTime>(executionContext) != null
                    && ServiceStartDate.Get<DateTime>(executionContext) != null && PlanDuration.Get<float>(executionContext) > 0
                    )
                {
                    DateTime BaseDate = new DateTime(ActivationDate.Get<DateTime>(executionContext).AddMonths(1).Year,
                        ActivationDate.Get<DateTime>(executionContext).AddMonths(1).Month, ServiceStartDate.Get<DateTime>(executionContext).Day);// ActivationDate.ToUniversalTime().AddHours(5.5d);
                    int months = (int)PlanDuration.Get<float>(executionContext);
                    ServiceEndDate.Set(executionContext, BaseDate.AddMonths(months).AddDays(-1));
                    int days = 7;

                    if (VoipRate.Get<Money>(executionContext) != null)
                    {
                        tracingService.Trace("k4_voiprate");
                        k4_voiprate = VoipRate.Get<Money>(executionContext).Value;
                    }
                    if (OldVsatOveragePrice.Get<Money>(executionContext) != null)
                    {
                        tracingService.Trace("OldVsatOveragePrice");
                        k4_vsatoverageprice = OldVsatOveragePrice.Get<Money>(executionContext).Value;
                    }
                    if (Old4GOveragePrice.Get<Money>(executionContext) != null)
                    {
                        tracingService.Trace("Old4GOveragePrice");
                        k4_4goverageprice = Old4GOveragePrice.Get<Money>(executionContext).Value;
                    }
                    if (OldVsatCost.Get<Money>(executionContext) != null)
                        OldVsatCost1 = OldVsatCost.Get<Money>(executionContext).Value;
                    if (Old4GCost.Get<Money>(executionContext) != null)
                        Old4GCost1 = Old4GCost.Get<Money>(executionContext).Value;


                   if(OldPlan.Get<EntityReference>(executionContext) != null)
                        k4_plan = OldPlan.Get<EntityReference>(executionContext);
                    if (OldVSATPlan.Get<EntityReference>(executionContext) != null)
                        k4_vsat = OldVSATPlan.Get<EntityReference>(executionContext);
                    if (Old4GPlan.Get<EntityReference>(executionContext) != null)
                        k4_4gplan = Old4GPlan.Get<EntityReference>(executionContext);

                    EntityCollection customerAsset = getAccAsset(service, Account.Get<EntityReference>(executionContext).Id.ToString());
                    if (customerAsset.Entities.Count > 0)
                    {
                        foreach (var myasset in customerAsset.Entities)
                        {
                            if (myasset.Contains("k4_productsubtype") &&
                           ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130000)//Subscription
                            {
                                k4_newplan = new EntityReference(myasset.LogicalName, myasset.Id);
                            }
                            if (myasset.Attributes.Contains("k4_productsubtype") &&
                               ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130001)//Top Up Plan-VSAT
                            {
                                NewVsatCost1 = ((Microsoft.Xrm.Sdk.Money)(myasset.Attributes["k4_extendedamount"])).Value;
                                k4_newvsatplan = new EntityReference(myasset.LogicalName, myasset.Id);
                                if (myasset.Contains("k4_vsatoverageprice"))
                                {
                                    k4_newvsatoverageprice = ((Money)myasset.Attributes["k4_vsatoverageprice"]).Value;
                                }
                            }
                            if (myasset.Attributes.Contains("k4_productsubtype") &&
                               ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130003)//Top Up Plan-4G
                            {
                                New4GCost1 = ((Microsoft.Xrm.Sdk.Money)(myasset.Attributes["k4_extendedamount"])).Value;
                                k4_new4gplan = new EntityReference(myasset.LogicalName, myasset.Id);
                                if (myasset.Contains("k4_4goverageprice"))
                                {
                                    k4_new4goverageprice = ((Money)myasset.Attributes["k4_4goverageprice"]).Value;
                                }
                            }
                        }



                    }


                    // First Month adjustment
                    tracingService.Trace("First Month adjustment ");
                    DateTime current = new DateTime(ActivationDate.Get<DateTime>(executionContext).AddMonths(1).Year,
                        ActivationDate.Get<DateTime>(executionContext).AddMonths(1).Month, ServiceStartDate.Get<DateTime>(executionContext).Day);

                    k4_4gpackcost = ((current.Subtract(ActivationDate.Get<DateTime>(executionContext)).Days) * (New4GCost1 - Old4GCost1) / (current.Subtract((current.AddMonths(-1))).Days))
                                 + ((New4GCost1 * (DateTime.DaysInMonth(current.Year, current.Month) - current.Day)) / DateTime.DaysInMonth(current.Year, current.Month))
                               + ((current.AddMonths(1).Day) * Old4GCost1) / ((current.AddMonths(1)).Subtract(current)).Days;
                    k4_associatedplancost = ((current.Subtract(ActivationDate.Get<DateTime>(executionContext)).Days) * (NewVsatCost1 - OldVsatCost1) / (current.Subtract((current.AddMonths(-1))).Days))
                                         + ((NewVsatCost1 * (DateTime.DaysInMonth(current.Year, current.Month) - current.Day)) / DateTime.DaysInMonth(current.Year, current.Month))
                                       + ((current.AddMonths(1).Day) * OldVsatCost1) / ((current.AddMonths(1)).Subtract(current)).Days;
                     k4_Arrear = ((current.Subtract(ActivationDate.Get<DateTime>(executionContext)).Days) * (New4GCost1 - Old4GCost1) / (current.Subtract((current.AddMonths(-1))).Days))
                        + ((current.Subtract(ActivationDate.Get<DateTime>(executionContext)).Days) * (NewVsatCost1 - OldVsatCost1) / (current.Subtract((current.AddMonths(-1))).Days))
                                         ;
                    k4_OldPlanAmount = ((New4GCost1 * (DateTime.DaysInMonth(current.Year, current.Month) - current.Day)) / DateTime.DaysInMonth(current.Year, current.Month))
                              + ((NewVsatCost1 * (DateTime.DaysInMonth(current.Year, current.Month) - current.Day)) / DateTime.DaysInMonth(current.Year, current.Month));
                     k4_NewPlanAmount = ((current.AddMonths(1).Day) * Old4GCost1) / ((current.AddMonths(1)).Subtract(current)).Days+
                    +((current.AddMonths(1).Day) * OldVsatCost1) / ((current.AddMonths(1)).Subtract(current)).Days;


                    CreateBillingInvoice(service,
                            Account.Get<EntityReference>(executionContext), current,
                           new Money(Convert.ToDecimal("0.0")), new Money(k4_baseplancost),
                new Money(Convert.ToDecimal("0.0")), new Money(k4_associatedplancost),
                new Money(k4_4gpackcost), new Money(k4_voipfee), new Money(Convert.ToDecimal("0.0")),
                new Money(k4_baseplancost + k4_associatedplancost + k4_4gpackcost + k4_voipfee), 0, days,
                 current.ToUniversalTime(), current.AddDays(-1).ToUniversalTime()
        , new Money(k4_4gactivationfee)
        , new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_newvsatoverageprice), new Money(k4_new4goverageprice)
        , new Money(k4_voiprate), new Money(k4_Arrear), new Money(k4_OldPlanAmount), new Money(k4_NewPlanAmount)
          , k4_plan, k4_vsat, k4_4gplan, k4_newplan, k4_newvsatplan, k4_new4gplan);

                    //Payment schedules
                    for (int i = 0; i < months; i++)
                    {
                        tracingService.Trace("For: " + i.ToString());
                        current = new DateTime(ActivationDate.Get<DateTime>(executionContext).AddMonths(1).AddMonths(i).Year,
                           ActivationDate.Get<DateTime>(executionContext).AddMonths(1).AddMonths(i).Month, ServiceStartDate.Get<DateTime>(executionContext).Day);

                        k4_4gpackcost = New4GCost1;
                        k4_associatedplancost = NewVsatCost1;

                        CreateBillingInvoice(service,
                                Account.Get<EntityReference>(executionContext), current,
                               new Money(Convert.ToDecimal("0.0")), new Money(k4_baseplancost),
                    new Money(Convert.ToDecimal("0.0")), new Money(k4_associatedplancost),
                    new Money(k4_4gpackcost), new Money(k4_voipfee), new Money(Convert.ToDecimal("0.0")),
                    new Money(k4_baseplancost + k4_associatedplancost + k4_4gpackcost + k4_voipfee), 0, days,
                     current.ToUniversalTime(), current.AddDays(-1).ToUniversalTime()
            , new Money(k4_4gactivationfee)
            , new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_newvsatoverageprice), new Money(k4_new4goverageprice)
            , new Money(k4_voiprate), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0"))
             , k4_newplan, k4_newvsatplan, k4_new4gplan, null, null, null);


                    }
                        //Last payment-For overage
                        CreateBillingInvoice(service, 
                       Account.Get<EntityReference>(executionContext), BaseDate,
                      new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
           new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
           new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
           new Money(Convert.ToDecimal("0.0")), months, days,
             BaseDate.AddMonths(months).ToUniversalTime(), BaseDate.AddMonths(months+1).AddDays(-1).ToUniversalTime(),
             new Money(Convert.ToDecimal("0.0")),
              new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_newvsatoverageprice), new Money(k4_new4goverageprice)
              , new Money(k4_voiprate), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0"))
               , k4_newplan, k4_newvsatplan, k4_new4gplan, null, null, null);




                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreatePayments workflow: " + ex.Message.ToString());
            }
        }
        #endregion
        public void CreateBillingInvoice(IOrganizationService service,  EntityReference Account, DateTime ActivationDate,
            Money k4_installationfee, Money k4_baseplancost,
            Money k4_hardwarecost, Money k4_associatedplancost,
            Money k4_4gpackcost, Money k4_voipfee, Money k4_activationfee, Money amount, int month, int days,
            DateTime k4_periodstartdate, DateTime k4_periodenddate, Money k4_4gactivationfee,
            Money k4_vsatoverageprice, Money k4_4goverageprice, Money k4_newvsatoverageprice, Money k4_new4goverageprice, Money k4_voiprate
            , Money k4_Arrear, Money k4_OldPlanAmount, Money k4_NewPlanAmount
            , EntityReference k4_plan, EntityReference k4_vsat, EntityReference k4_4gplan
              , EntityReference k4_newplan, EntityReference k4_newvsatplan, EntityReference k4_new4gplan)
        {
            Entity msdyn_payment = new Entity("msdyn_payment");
            msdyn_payment.Attributes["msdyn_account"] = Account;
            msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
            msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + ActivationDate.AddMonths(month).ToString("dd MMMM yyyy"));
            msdyn_payment.Attributes["msdyn_date"] = ActivationDate.AddMonths(month).ToUniversalTime();
            msdyn_payment.Attributes["k4_duedateforpayment"] = ActivationDate.AddMonths(month).AddDays(days).ToUniversalTime();
            msdyn_payment.Attributes["k4_periodstartdate"] = k4_periodstartdate;
            msdyn_payment.Attributes["k4_periodenddate"] = k4_periodenddate;
            msdyn_payment.Attributes["k4_installationfee"] = k4_installationfee;
            msdyn_payment.Attributes["k4_baseplancost"] = k4_baseplancost;
            msdyn_payment.Attributes["k4_hardwarecost"] = k4_hardwarecost;
            msdyn_payment.Attributes["k4_associatedplancost"] = k4_associatedplancost;
            msdyn_payment.Attributes["k4_4gpackcost"] = k4_4gpackcost;
            msdyn_payment.Attributes["k4_voipfee"] = k4_voipfee;
            msdyn_payment.Attributes["k4_activationfee"] = k4_activationfee;//VSAT activation fee
            msdyn_payment.Attributes["k4_4gactivationfee"] = k4_4gactivationfee;
            msdyn_payment.Attributes["k4_4goveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_vsatoveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_other"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["msdyn_amount"] = amount;

            msdyn_payment.Attributes["k4_vsatoverageprice"] = k4_vsatoverageprice;
            msdyn_payment.Attributes["k4_4goverageprice"] = k4_4goverageprice;
            msdyn_payment.Attributes["k4_newvsatoverageprice"] = k4_newvsatoverageprice;
            msdyn_payment.Attributes["k4_new4goverageprice"] = k4_new4goverageprice;
            msdyn_payment.Attributes["k4_voiprate"] = k4_voiprate;
            msdyn_payment.Attributes["k4_totalvoipcharges"] = new Money(Convert.ToDecimal("0.0"));

            msdyn_payment.Attributes["k4_arrear"] = k4_Arrear;
            msdyn_payment.Attributes["k4_oldplanamount"] = k4_OldPlanAmount;
            msdyn_payment.Attributes["k4_newplanamount"] = k4_NewPlanAmount;

            if (k4_plan != null)
                msdyn_payment.Attributes["k4_plan"] = k4_plan;
            if (k4_vsat != null)
                msdyn_payment.Attributes["k4_vsatplan"] = k4_vsat;
            if (k4_4gplan != null)
                msdyn_payment.Attributes["k4_4gplan"] = k4_4gplan;

            if (k4_newplan != null)
                msdyn_payment.Attributes["k4_newplan"] = k4_newplan;
            if (k4_newvsatplan != null)
                msdyn_payment.Attributes["k4_newvsatplan"] = k4_newvsatplan;
            if (k4_new4gplan != null)
                msdyn_payment.Attributes["k4_new4gplan"] = k4_new4gplan;

            service.Create(msdyn_payment);
        }
        private EntityCollection getAccAsset(IOrganizationService service, string accId)
        {
            string fetchQuery =
                "<fetch top='50' >" +
"  <entity name='msdyn_customerasset' alias='Asset' >" +
"    <attribute name='k4_extendedamount' />" +
"    <attribute name='k4_4goverageprice' />" +
"    <attribute name='k4_vsatoverageprice' />" +
"    <attribute name='k4_voiprate' />" +
"    <attribute name='k4_productsubtype' />" +
"    <filter>" +
"      <condition attribute='msdyn_account' operator='eq' value='{" + accId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
" <condition attribute='k4_extendedamount' operator='not-null' />" +
"        <condition attribute='k4_productsubtype' operator='in' >" +
"          <value>636130000</value>" +//Subscription
"          <value>636130001</value>" +//Top Up Plan-VSAT
"          <value>636130003</value>" +//Top Up Plan-4G
"        </condition>" +
"    </filter>" +
"  </entity>" +
"</fetch>";


            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }

    }
}
