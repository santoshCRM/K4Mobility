﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;

namespace K4Mobility.Assembly.WorkflowActivities
{
   public class PaymentRecalculate : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;


       
        [RequiredArgument]
        [Input("Payment")]
        [ReferenceTarget("msdyn_payment")]
        public InArgument<EntityReference> Payment

        {
            get;
            set;
        }
        
       

        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if(Payment.Get(executionContext)!=null)
            {
                Entity msdyn_paymentUpdate = new Entity(Payment.Get(executionContext).LogicalName, Payment.Get(executionContext).Id);
                EntityCollection paymentDetails = getPaymentDetails(service, Payment.Get(executionContext).Id.ToString());
                decimal k4_baseamount = 0.00m;//msdyn_amount
                decimal k4_discountamount = 0.00m;//k4_totaldiscount
                decimal k4_taxamount = 0.00m;//k4_totaltax
                decimal k4_totaloveragecost = 0.00m;//k4_totaloveragecost
                foreach (Entity paymentDetail in paymentDetails.Entities)
                {
                    if (paymentDetail.Attributes.Contains("k4_baseamount") && paymentDetail.GetAttributeValue<Money>("k4_baseamount").Value > 0)
                        k4_baseamount += paymentDetail.GetAttributeValue<Money>("k4_baseamount").Value;
                    if (paymentDetail.Attributes.Contains("k4_discountamount") && paymentDetail.GetAttributeValue<Money>("k4_discountamount").Value > 0)
                        k4_discountamount += paymentDetail.GetAttributeValue<Money>("k4_discountamount").Value;
                    if (paymentDetail.Attributes.Contains("k4_taxamount") && paymentDetail.GetAttributeValue<Money>("k4_taxamount").Value > 0)
                        k4_taxamount += paymentDetail.GetAttributeValue<Money>("k4_taxamount").Value;
                    if (paymentDetail.Attributes.Contains("k4_totaloveragecost") && paymentDetail.GetAttributeValue<Money>("k4_totaloveragecost").Value > 0)
                        k4_totaloveragecost += paymentDetail.GetAttributeValue<Money>("k4_totaloveragecost").Value;
                }

                msdyn_paymentUpdate.Attributes["msdyn_amount"] = new Money(decimal.Round(k4_baseamount, 2, MidpointRounding.AwayFromZero));
                msdyn_paymentUpdate.Attributes["k4_totaldiscount"] = new Money(decimal.Round(k4_discountamount, 2, MidpointRounding.AwayFromZero));
                msdyn_paymentUpdate.Attributes["k4_totaltax"] = new Money(decimal.Round(k4_taxamount, 2, MidpointRounding.AwayFromZero));
                msdyn_paymentUpdate.Attributes["k4_totaloveragecost"] = new Money(decimal.Round(k4_totaloveragecost, 2, MidpointRounding.AwayFromZero));
                service.Update(msdyn_paymentUpdate);

            }
        }
        #endregion
        private EntityCollection getPaymentDetails(IOrganizationService service, string payId)
        {
            string fetchQuery =
               "<fetch top='50' >" +
"  <entity name='msdyn_paymentdetail' >" +
"    <attribute name='k4_totaloveragecost'  />" +
"    <attribute name='k4_baseamount' />" +
"    <attribute name='k4_discountamount' />" +
"    <attribute name='k4_taxamount'  />" +
"    <filter>" +
"      <condition attribute='msdyn_payment' operator='eq' value='{" + payId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
