using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class PaymentToInvoice : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

        [RequiredArgument]
        [Input("Payment")]
        [ReferenceTarget("msdyn_payment")]
        public InArgument<EntityReference> Payment
        {
            get;
            set;
        }
		[RequiredArgument]
		[Input("Invoice")]
		[ReferenceTarget("invoice")]
		public InArgument<EntityReference> Invoice
		{
			get;
			set;
		}

      
        #endregion
        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
			{
				traceMessage = "Workflow started.";
				tracingService.Trace(traceMessage);
				if (Invoice.Get<EntityReference>(executionContext) != null && Payment.Get<EntityReference>(executionContext)!=null)
				{
                    //Get Payment details
                    EntityCollection paymentDetails = getPaymentDetails(service, Payment.Get<EntityReference>(executionContext).Id.ToString());
                    foreach (Entity paymentDetail in paymentDetails.Entities)
                    {
                        Entity Product = new Entity();
                        Money Amount = new Money(0.00m);
                        Entity invoicedetail = new Entity("invoicedetail");
                        //    if (paymentDetail.Attributes.Contains("k4_baseamount") && paymentDetail.GetAttributeValue<Money>("k4_baseamount").Value > 0)
                        //        k4_baseamount += paymentDetail.GetAttributeValue<Money>("k4_baseamount").Value;
                        //    if (paymentDetail.Attributes.Contains("k4_discountamount") && paymentDetail.GetAttributeValue<Money>("k4_discountamount").Value > 0)
                        //        k4_discountamount += paymentDetail.GetAttributeValue<Money>("k4_discountamount").Value;
                        //    if (paymentDetail.Attributes.Contains("k4_taxamount") && paymentDetail.GetAttributeValue<Money>("k4_taxamount").Value > 0)
                        //        k4_taxamount += paymentDetail.GetAttributeValue<Money>("k4_taxamount").Value;
                        //    if (paymentDetail.Attributes.Contains("k4_totaloveragecost") && paymentDetail.GetAttributeValue<Money>("k4_totaloveragecost").Value > 0)
                        //        k4_totaloveragecost += paymentDetail.GetAttributeValue<Money>("k4_totaloveragecost").Value;
                        if (Product != null)
                        {
                            Entity MyProduct = service.Retrieve(Product.LogicalName,
                                Product.Id, new ColumnSet(new string[1]
                            {
                            "defaultuomid"
                            }));
                           
                            invoicedetail.Attributes["invoiceid"] = Invoice.Get<EntityReference>(executionContext);
                            invoicedetail.Attributes["productid"] = new EntityReference(Product.LogicalName, Product.Id);
                            invoicedetail.Attributes["quantity"] = decimal.One;
                            traceMessage += "\n Step 1";
                            if (MyProduct.Attributes.Contains("defaultuomid"))
                            {
                                traceMessage += "\n Primary unit found";
                                invoicedetail.Attributes["uomid"] = MyProduct.Attributes["defaultuomid"];
                                invoicedetail.Attributes["ispriceoverridden"] = true;
                                invoicedetail.Attributes["priceperunit"] = Amount;
                                Guid invoicedetailId = service.Create(invoicedetail);
                                traceMessage += "\n invoicedetail Created";
                            }
                        }

                      
                    }
                   
					
				}
			}
			catch (Exception ex)
			{
				  tracingService.Trace(traceMessage);
				throw new InvalidPluginExecutionException("error occured in CreateInvoiceLines workflow: " + ex.Message.ToString());
			}
		}
        private EntityCollection getPaymentDetails(IOrganizationService service, string payId)
        {
            string fetchQuery =
               "<fetch top='50' >" +
"  <entity name='msdyn_paymentdetail' >" +
"    <attribute name='k4_totaloveragecost'  />" +
"    <attribute name='k4_baseamount' />" +
"    <attribute name='k4_discountamount' />" +
"    <attribute name='k4_taxamount'  />" +
"    <filter>" +
"      <condition attribute='msdyn_payment' operator='eq' value='{" + payId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
