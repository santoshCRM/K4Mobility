﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class StatusChangePayments : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Contact")]
        [ReferenceTarget("contact")]
        public InArgument<EntityReference> Contact { get; set; }
        

        [Input("Activate")]
        [RequiredArgument]
        public InArgument<bool> Activate { get; set; }


        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                /*
                if (Contact.Get<EntityReference>(executionContext) != null )
                {
                    
                    QueryExpression qe = new QueryExpression();
                    qe.EntityName = "k4_paymentinformation";
                    qe.ColumnSet = new ColumnSet();
                    qe.ColumnSet.Columns.Add("k4_paymentinformationid");
                    bool changeType = true;
                    if (Activate.Get<bool>(executionContext))//Start Service-Activate:True
                    {
                        qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1);//Get InActive record
                        qe.Criteria.AddCondition("statuscode", ConditionOperator.NotEqual, Convert.ToInt32(636130000));//Paid Payment
                        qe.Criteria.AddCondition("k4_contact", ConditionOperator.Equal, Contact.Get<EntityReference>(executionContext).Id);
                        qe.Criteria.AddCondition("k4_paymentdate", ConditionOperator.OnOrAfter, DateTime.Now.ToString("yyyy-MM-dd"));
                       
                    }
                    else//Stop Service-Activate:False
                    {
                        qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);//Get Active record
                        qe.Criteria.AddCondition("statuscode", ConditionOperator.NotEqual, Convert.ToInt32(636130000));//Paid Payment
                        qe.Criteria.AddCondition("k4_contact", ConditionOperator.Equal, Contact.Get<EntityReference>(executionContext).Id);
                        qe.Criteria.AddCondition("k4_paymentdate", ConditionOperator.OnOrAfter, DateTime.Now.ToString("yyyy-MM-dd"));
                        changeType = false;
                    }

                    EntityCollection Payments= service.RetrieveMultiple(qe);
                    if(Payments.Entities.Count>0)
                    {
                        traceMessage+= " Entity Count: " +Payments.Entities.Count.ToString();
                        ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                        {

                            Settings = new ExecuteMultipleSettings()
                            {
                                ContinueOnError = false,
                                ReturnResponses = false
                            },
                            // Create an empty organization request collection.
                            Requests = new OrganizationRequestCollection()
                        };
                        foreach (var entity in Payments.Entities)
                        {
                            SetStateRequest StateRequest = new SetStateRequest();
                            StateRequest.EntityMoniker = new EntityReference(entity.LogicalName, entity.Id);
                            if(changeType)//Activate
                            {
                                StateRequest.State = new OptionSetValue(0);
                                StateRequest.Status = new OptionSetValue(1);
                            }
                            else//Deactivate
                            {
                                StateRequest.State = new OptionSetValue(1);
                                StateRequest.Status = new OptionSetValue(2);
                            }
                            requestWithResults.Requests.Add(StateRequest);
                            
                        }
                        ExecuteMultipleResponse responseWithResults =
                       (ExecuteMultipleResponse)service.Execute(requestWithResults);
                    }
                    else
                        traceMessage += " No Record found to update.";
                }
                */
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in StatusChangePayments workflow: " + ex.Message.ToString());
            }

        }




        #endregion
    }
}
