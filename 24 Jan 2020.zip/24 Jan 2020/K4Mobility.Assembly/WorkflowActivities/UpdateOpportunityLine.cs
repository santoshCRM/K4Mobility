using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class UpdateOpportunityLine : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[RequiredArgument]
		[Input("OpportunityLine")]
		[ReferenceTarget("opportunityproduct")]
		public InArgument<EntityReference> OpportunityLine
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("ProductSubType")]
		public InArgument<string> ProductSubType
		{
			get;
			set;
		}
        [Input("OppProductSubType")]
        public InArgument<string> OppProductSubType
        {
            get;
            set;
        }

        [Input("ProductTaxPercentage")]
		public InArgument<string> ProductTaxPercentage
		{
			get;
			set;
		}

        [Input("OppTaxPercentage")]
        public InArgument<string> OppTaxPercentage
        {
            get;
            set;
        }
        [RequiredArgument]
		[Input("ProductDicountPercentage")]
		public InArgument<string> ProductDicountPercentage
		{
			get;
			set;
		}
        [Input("PromoCodeDiscountPercentage")]
        public InArgument<string> PromoCodeDiscountPercentage
        {
            get;
            set;
        }
        [Input("OppDicountPercentage")]
        public InArgument<string> OppDicountPercentage
        {
            get;
            set;
        }
        [RequiredArgument]
		[Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}
        [Input("OppAmount")]
        public InArgument<Money> OppAmount
        {
            get;
            set;
        }
        [Input("k4_purchasevalue")]
        public InArgument<Money> k4_purchasevalue
        {
            get;
            set;
        }
        [Input("Operator")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Operator
        {
            get;
            set;
        }
        [Input("Least Activation Date")]
        public InArgument<DateTime> k4_leastactivationdate
        {
            get;
            set;
        }
        [Input("Activation Date")]
        public InArgument<DateTime> ActivationDate
        {
            get;
            set;
        }
        [Input("DeActivation Date")]
        public InArgument<DateTime> DeActivationDate
        {
            get;
            set;
        }
        [Input("Contract Length")]
        public InArgument<decimal> k4_contractlength
        {
            get;
            set;
        }
        [Input("OnGoing")]
        public InArgument<bool> k4_activated
        {
            get;
            set;
        }
        [Input("VSAT Quota (GB)")]
        public InArgument<string> k4_vsatquotaingb
        {
            get;
            set;
        }
        [Input("FourG Quota (GB)")]
        public InArgument<string> k4_4gquotaingb
        {
            get;
            set;
        }
        #endregion
        #region Execute  function

        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (OpportunityLine.Get<EntityReference>(executionContext) != null)
                {
                    Entity MyOpportunityLine = new Entity(OpportunityLine.Get<EntityReference>(executionContext).LogicalName,
                        OpportunityLine.Get<EntityReference>(executionContext).Id);
                    decimal numP = Convert.ToDecimal("0.00");//promodiscout
                    if (OppProductSubType.Get<string>(executionContext) != null)
                    {

                    }
                    else
                    {
                        #region Set ProductSubType
                        if (ProductSubType.Get<string>(executionContext) != null)
                        {
                            if (ProductSubType.Get<string>(executionContext) == "Subscription")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130000);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Top Up Plan-VSAT")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130001);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "HardWare")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130002);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Top Up Plan-4G")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130003);
                                if (PromoCodeDiscountPercentage.Get<string>(executionContext) != null)
                                {
                                    numP = Convert.ToDecimal(PromoCodeDiscountPercentage.Get<string>(executionContext));
                                    traceMessage += "/n PromoCodeDiscountPercentage";
                                }
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Hardware Installation Fee")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130004);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "VSAT Activation Fees")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130005);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "VoIP Activation Fees")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130006);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "Survey Fee")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130007);
                            }
                            else if (ProductSubType.Get<string>(executionContext) == "4G Activation Fees")
                            {
                                MyOpportunityLine.Attributes["k4_productsubtype"] = new OptionSetValue(636130008);
                            }
                            traceMessage += ProductSubType.Get<string>(executionContext).ToString();
                        }
                        #endregion
                    }
                    if (Operator.Get<EntityReference>(executionContext) != null)
                    {
                        MyOpportunityLine.Attributes["msdyn_serviceaccount"] = Operator.Get<EntityReference>(executionContext);
                    }
                    decimal quotaingb = 0.00m;
                    decimal numD = Convert.ToDecimal("0.00");//discount
                    decimal numT = Convert.ToDecimal("0.00");//tax
                    decimal baseAmount = Convert.ToDecimal("0.00");
                    MyOpportunityLine.Attributes["manualdiscountamount"] = new Money(numD);
                    MyOpportunityLine.Attributes["tax"] = new Money(numT);
                    MyOpportunityLine.Attributes["k4_quotaingb"] = quotaingb.ToString();

                    if (OppAmount.Get<Money>(executionContext) != null && OppAmount.Get<Money>(executionContext).Value > 0)
                        baseAmount = OppAmount.Get<Money>(executionContext).Value;
                    else if (Amount.Get<Money>(executionContext) != null && Amount.Get<Money>(executionContext).Value > 0)
                        baseAmount = Amount.Get<Money>(executionContext).Value;

                    if (k4_vsatquotaingb.Get<string>(executionContext) != null && k4_vsatquotaingb.Get<string>(executionContext)!=string.Empty)
                        quotaingb =Convert.ToDecimal(k4_vsatquotaingb.Get<string>(executionContext));
                    else if (k4_4gquotaingb.Get<string>(executionContext) != null && k4_4gquotaingb.Get<string>(executionContext) != string.Empty)
                        quotaingb = Convert.ToDecimal(k4_4gquotaingb.Get<string>(executionContext));

                    #region Least Activation Date is not null
                    if(k4_leastactivationdate.Get<DateTime>(executionContext) != DateTime.MinValue)
                    {
                        // throw new InvalidPluginExecutionException("3:");
                        #region Contract length present
                        if (k4_contractlength.Get<decimal>(executionContext) > 0)
                        {
                            //throw new InvalidPluginExecutionException("2");
                            if (k4_purchasevalue.Get<Money>(executionContext) != null)
                                baseAmount = k4_purchasevalue.Get<Money>(executionContext).Value;
                            else
                                MyOpportunityLine.Attributes["k4_purchasevalue"] = new Money(baseAmount);
                            decimal datediff = k4_contractlength.Get<decimal>(executionContext);
                            baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(k4_leastactivationdate.Get<DateTime>(executionContext).Year,
                                k4_leastactivationdate.Get<DateTime>(executionContext).Month);
                            quotaingb= ((datediff *quotaingb) / DateTime.DaysInMonth(k4_leastactivationdate.Get<DateTime>(executionContext).Year,
                                k4_leastactivationdate.Get<DateTime>(executionContext).Month));
                            MyOpportunityLine.Attributes["priceperunit"] = new Money(decimal.Round(baseAmount, 2, MidpointRounding.AwayFromZero));
                            MyOpportunityLine.Attributes["ispriceoverridden"] = true;
                        }
                    #endregion
                        DateTime NextMonthLeastActivationDate = k4_leastactivationdate.Get<DateTime>(executionContext).AddMonths(1).AddDays(-1);
                        #region Deactivation date is greater than Next Month Least Activation Date
                        if (k4_contractlength.Get<decimal>(executionContext) == 0
                        && ActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue &&
                        DeActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue &&
                         DeActivationDate.Get<DateTime>(executionContext) > NextMonthLeastActivationDate
                        )
                        {
                            // throw new InvalidPluginExecutionException("4:");
                            if (k4_purchasevalue.Get<Money>(executionContext) != null)
                                baseAmount = k4_purchasevalue.Get<Money>(executionContext).Value;
                            else
                                MyOpportunityLine.Attributes["k4_purchasevalue"] = new Money(baseAmount);
                            decimal datediff = (NextMonthLeastActivationDate - ActivationDate.Get<DateTime>(executionContext)).Days + 1;
                            baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(k4_leastactivationdate.Get<DateTime>(executionContext).Year,
                                k4_leastactivationdate.Get<DateTime>(executionContext).Month);
                            quotaingb = ((datediff * quotaingb) / DateTime.DaysInMonth(k4_leastactivationdate.Get<DateTime>(executionContext).Year,
                                k4_leastactivationdate.Get<DateTime>(executionContext).Month));

                            MyOpportunityLine.Attributes["priceperunit"] = new Money(decimal.Round(baseAmount, 2, MidpointRounding.AwayFromZero));
                            MyOpportunityLine.Attributes["ispriceoverridden"] = true;
                        }
                        #endregion
                        #region Deactivation date is less than equal Next Month Least Activation Date
                        if (k4_contractlength.Get<decimal>(executionContext) == 0
                         && ActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue &&
                         DeActivationDate.Get<DateTime>(executionContext) != DateTime.MinValue &&
                          DeActivationDate.Get<DateTime>(executionContext) <= NextMonthLeastActivationDate
                         )
                        {
                           
                            // throw new InvalidPluginExecutionException("4:");
                            if (k4_purchasevalue.Get<Money>(executionContext) != null)
                                baseAmount = k4_purchasevalue.Get<Money>(executionContext).Value;
                            else
                                MyOpportunityLine.Attributes["k4_purchasevalue"] = new Money(baseAmount);
                            decimal datediff = (DeActivationDate.Get<DateTime>(executionContext) - ActivationDate.Get<DateTime>(executionContext)).Days + 1;
                            baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(k4_leastactivationdate.Get<DateTime>(executionContext).Year,
                                k4_leastactivationdate.Get<DateTime>(executionContext).Month);
                            quotaingb = ((datediff * quotaingb) / DateTime.DaysInMonth(k4_leastactivationdate.Get<DateTime>(executionContext).Year,
                                k4_leastactivationdate.Get<DateTime>(executionContext).Month));

                            MyOpportunityLine.Attributes["priceperunit"] = new Money(decimal.Round(baseAmount, 2, MidpointRounding.AwayFromZero));
                            MyOpportunityLine.Attributes["ispriceoverridden"] = true;
                        }
                        #endregion
                    }
                    else
                        throw new InvalidPluginExecutionException("Least Activation date not found.");
                    #endregion
                    traceMessage += "/n1 OppAmount";
                    if (OppDicountPercentage.Get<string>(executionContext) != null)
                    {
                        numD = Convert.ToDecimal(OppDicountPercentage.Get<string>(executionContext));
                        traceMessage += "/n2";
                    }
                    else
                    {
                        if (ProductDicountPercentage.Get<string>(executionContext) != null)
                        {
                            numD = Convert.ToDecimal(ProductDicountPercentage.Get<string>(executionContext));
                            numD += numP;
                            MyOpportunityLine.Attributes["k4_discountpercentage"] = decimal.Round(numD, 2, MidpointRounding.AwayFromZero) ;
                            traceMessage += "/n3";
                        }
                    }
                    traceMessage += numD.ToString();
                    decimal num1 = baseAmount * numD / 100m;//Disount Amount calculated
                    MyOpportunityLine.Attributes["manualdiscountamount"] = new Money(decimal.Round(num1, 2, MidpointRounding.AwayFromZero) );
                    //Tax
                    if (OppTaxPercentage.Get<string>(executionContext) != null)
                    {
                        traceMessage += "/n4";
                        numT = Convert.ToDecimal(OppTaxPercentage.Get<string>(executionContext));
                    }
                    else
                    {
                        if (ProductTaxPercentage.Get<string>(executionContext) != null)
                        {
                            traceMessage += "/n5";
                            numT = Convert.ToDecimal(ProductTaxPercentage.Get<string>(executionContext));
                            MyOpportunityLine.Attributes["k4_taxpercentage"] = decimal.Round(numT, 2, MidpointRounding.AwayFromZero) ;
                        }
                    }
                    traceMessage += numT.ToString();

                    decimal num2 = (baseAmount - num1) * numT / 100m;//Tax Amount calculated
                    MyOpportunityLine.Attributes["tax"] = new Money(decimal.Round(num2, 2, MidpointRounding.AwayFromZero) );
                       MyOpportunityLine.Attributes["k4_quotaingb"] =  (decimal.Round(quotaingb, 2, MidpointRounding.AwayFromZero)).ToString();
                    //throw new InvalidPluginExecutionException("error occured in UpdateOpportunityLine workflow: " + decimal.Round(quotaingb, 2, MidpointRounding.AwayFromZero).ToString());
                    service.Update(MyOpportunityLine);
                }
			}
			catch (Exception ex)
			{
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("Error occured in UpdateOpportunityLine workflow: " + ex.Message.ToString());
			}
		}
        #endregion
        public static int GetMonthDifference(DateTime startDate, DateTime endDate)
        {
            int numMonths = 0;

            while (startDate.Year != endDate.Year || startDate.Month != endDate.Month)
            {
                startDate = startDate.AddMonths(1);
                numMonths++;
            }
            if (startDate.Year == endDate.Year && startDate.Month == endDate.Month)
            {
                numMonths++;
            }
            return numMonths;
        }
    }
}
