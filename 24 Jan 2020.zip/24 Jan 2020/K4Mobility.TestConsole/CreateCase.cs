﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class CreateCase
    {
        public void Execute(IOrganizationService service)
        {
            Entity mycase = new Entity("incident");
            mycase["customerid"] = new EntityReference("account", new Guid("1711F03B-1ACE-E911-A812-000D3A0A8303"));
            mycase["k4_suspensiondate"] = new DateTime(2019, 9, 25);
            mycase["k4_activationdate"] = new DateTime(2019, 9, 30);
            mycase["subjectid"] = new EntityReference("subject", new Guid("c18b995c-ecbf-e911-a963-000d3af2c9d4")); //Temporary suspension
            mycase["title"] = "test from console";
            service.Create(mycase);
        }
        }
}
