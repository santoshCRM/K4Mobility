﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class CreateMonthlyBilling
    {
        public void Execute(IOrganizationService service)
        {
            #region Variable to Update
            Money amount = new Money();

            EntityReference Account = new EntityReference("account", new Guid("6e67c65d-753e-ea11-a812-000d3a0a827e"));
            EntityReference Payment = new EntityReference("msdyn_payment", new Guid("6cf75cea-fc3c-ea11-a813-000d3a0a8279"));
            DateTime current = new DateTime(2020, 2, 11).AddDays(1);
            float PlanDuration = 1;
            int months = (int)PlanDuration;
            DateTime NextMonthLeastActivationDate = current.AddMonths(months).AddDays(-1);
            int days = 7;
            bool AssetExpired = false;

            decimal TotalTaxAmt = 0.00m;//TotalTaxAmount
            decimal TotalDiscountAmt = 0.00m;//TotalTaxAmount
            decimal TotalBaseAmt = 0.00m;//TotalBaseAmt
            decimal InstallmentAmount = 0.00m;//InstallmentAmount
            decimal AdvancePayment = 0.00m;//AdvancePayment
            Money AccAdvancePayment =new Money(0.00m);//AccAdvancePayment
            #endregion
            //if (Payment != null)
            //{
            //    Entity sdd = new Entity(Payment.LogicalName, Payment.Id);

            //    EntityCollection paymentDetails = getPaymentDetails(service, Payment.Id.ToString());
            //    decimal k4_baseamount = 0.00m;//msdyn_amount
            //    decimal k4_discountamount = 0.00m;//k4_totaldiscount
            //    decimal k4_taxamount = 0.00m;//k4_totaltax
            //    decimal k4_totaloveragecost = 0.00m;//k4_totaloveragecost
            //    foreach (Entity paymentDetail in paymentDetails.Entities)
            //    {
            //        if (paymentDetail.Attributes.Contains("k4_baseamount") && paymentDetail.GetAttributeValue<Money>("k4_baseamount").Value > 0)
            //            k4_baseamount += paymentDetail.GetAttributeValue<Money>("k4_baseamount").Value;
            //        if (paymentDetail.Attributes.Contains("k4_discountamount") && paymentDetail.GetAttributeValue<Money>("k4_discountamount").Value > 0)
            //            k4_discountamount += paymentDetail.GetAttributeValue<Money>("k4_discountamount").Value;
            //        if (paymentDetail.Attributes.Contains("k4_taxamount") && paymentDetail.GetAttributeValue<Money>("k4_taxamount").Value > 0)
            //            k4_taxamount += paymentDetail.GetAttributeValue<Money>("k4_taxamount").Value;
            //        if (paymentDetail.Attributes.Contains("k4_totaloveragecost") && paymentDetail.GetAttributeValue<Money>("k4_totaloveragecost").Value > 0)
            //            k4_totaloveragecost += paymentDetail.GetAttributeValue<Money>("k4_totaloveragecost").Value;
            //    }

            //    sdd.Attributes["msdyn_amount"] = new Money(decimal.Round(k4_baseamount, 2, MidpointRounding.AwayFromZero));
            //    sdd.Attributes["k4_totaldiscount"] = new Money(decimal.Round(k4_discountamount, 2, MidpointRounding.AwayFromZero));
            //    sdd.Attributes["k4_totaltax"] = new Money(decimal.Round(k4_taxamount, 2, MidpointRounding.AwayFromZero));
            //    sdd.Attributes["k4_totaloveragecost"] = new Money(decimal.Round(k4_totaloveragecost, 2, MidpointRounding.AwayFromZero));
            //    service.Update(sdd);

            //}
            if (AccAdvancePayment != null&& AccAdvancePayment.Value>0)
                AdvancePayment = AccAdvancePayment.Value;
            Entity msdyn_payment = new Entity("msdyn_payment");
            msdyn_payment.Attributes["msdyn_account"] = Account;
            msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
            msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + current.ToString("dd MMMM yyyy"));
            msdyn_payment.Attributes["msdyn_date"] = current.ToUniversalTime();
            msdyn_payment.Attributes["k4_duedateforpayment"] = current.AddDays(days).ToUniversalTime();
            msdyn_payment.Attributes["k4_periodstartdate"] = current;
            msdyn_payment.Attributes["k4_periodenddate"] = current.AddMonths(months).AddDays(-1);
            //   msdyn_payment.Attributes["msdyn_amount"] = new Money(0.00m);
            msdyn_payment.Attributes["k4_totaldiscount"] = new Money(0.00m);
            msdyn_payment.Attributes["k4_totaltax"] = new Money(0.00m);
            msdyn_payment.Attributes["k4_installmentamount"] = new Money(0.00m);
            msdyn_payment.Attributes["k4_totaloveragecost"] = new Money(0.00m);
            msdyn_payment.Attributes["k4_advancepayment"] = new Money(AdvancePayment);
            Guid paymentId = service.Create(msdyn_payment);
            
            #region Installments
         
            EntityCollection Installments = getAccInstallment(service, Account.Id.ToString(), current, current.AddMonths(months));
            foreach (Entity myInstallment in Installments.Entities)
            {
                AssociateRequest request = new AssociateRequest();
                EntityReference mon1 = new EntityReference(msdyn_payment.LogicalName, paymentId);
                EntityReference mon2 = new EntityReference(myInstallment.LogicalName, myInstallment.Id);
                request.Target = mon2;
                request.RelatedEntities = new EntityReferenceCollection { mon1 };
                request.Relationship = new Relationship("k4_msdyn_payment_k4_installment");
                service.Execute(request);
                if(myInstallment.Attributes.Contains("k4_amount"))
                {
                    InstallmentAmount += ((Microsoft.Xrm.Sdk.Money)(myInstallment.Attributes["k4_amount"])).Value;
                }
            }
            #endregion


            #region Payment Details
           
            EntityCollection customerAsset = getAccAsset(service, Account.Id.ToString());
            foreach (Entity myasset in customerAsset.Entities)
            {
                Entity msdyn_paymentdetail = new Entity("msdyn_paymentdetail");
                decimal numD = 0.00m;//discount
                decimal numT = 0.00m;//tax
                decimal baseAmount = 0.00m;
                string k4_quotaingb = "0";
                msdyn_paymentdetail.Attributes["k4_discountpercentage"] = 0.00m;
                msdyn_paymentdetail.Attributes["k4_discountamount"] = new Money(numT);
                msdyn_paymentdetail.Attributes["k4_taxpercentage"] = 0.00m;
                msdyn_paymentdetail.Attributes["k4_taxamount"] = new Money(numD);
                msdyn_paymentdetail.Attributes["msdyn_payment"] = new EntityReference(msdyn_payment.LogicalName, paymentId);
                msdyn_paymentdetail.Attributes["k4_customerasset"] = new EntityReference(myasset.LogicalName, myasset.Id);
                msdyn_paymentdetail.Attributes["k4_totaloveragecost"] = new Money(numT);
                if (myasset.Attributes.Contains("k4_contractlength"))
                    msdyn_paymentdetail.Attributes["k4_contractlength"] = myasset.GetAttributeValue<decimal>("k4_contractlength");
                if (myasset.Attributes.Contains("k4_activationdate") && myasset.GetAttributeValue<DateTime>("k4_activationdate") != DateTime.MinValue)
                    msdyn_paymentdetail.Attributes["k4_activationdate"] = myasset.GetAttributeValue<DateTime>("k4_activationdate");
                if (myasset.Attributes.Contains("k4_deactivationdate") && myasset.GetAttributeValue<DateTime>("k4_deactivationdate") != DateTime.MinValue)
                    msdyn_paymentdetail.Attributes["k4_deactivationdate"] = myasset.GetAttributeValue<DateTime>("k4_deactivationdate");
                if (myasset.Attributes.Contains("k4_activated"))
                    msdyn_paymentdetail.Attributes["k4_ongoing"] = myasset.GetAttributeValue<bool>("k4_activated");
               
                if (myasset.Attributes.Contains("currentcost") && myasset.GetAttributeValue<Money>("currentcost").Value > 0)
                    baseAmount = myasset.GetAttributeValue<Money>("currentcost").Value;

                if (myasset.Attributes.Contains("vsatquotaingb") && myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatquotaingb").Value.ToString() != string.Empty)
                    k4_quotaingb = myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatquotaingb").Value.ToString();
                if (myasset.Attributes.Contains("Fourgquotaingb") && myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgquotaingb").Value.ToString() != string.Empty)
                    k4_quotaingb = myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgquotaingb").Value.ToString();


                #region On going Customer asset product-yes
                if (myasset.Attributes.Contains("k4_activated") && myasset.GetAttributeValue<bool>("k4_activated"))
                {
                    if (myasset.GetAttributeValue<DateTime>("k4_activationdate") > current.AddMonths(-1) &&
                      myasset.GetAttributeValue<DateTime>("k4_activationdate") < current)//Overage for this asset
                    {
                        decimal datediff;
                        datediff = (current.AddDays(-1) - myasset.GetAttributeValue<DateTime>("k4_activationdate")).Days + 1;
                        k4_quotaingb = ((datediff * Convert.ToDecimal(k4_quotaingb)) / DateTime.DaysInMonth(myasset.GetAttributeValue<DateTime>("k4_activationdate").Year, myasset.GetAttributeValue<DateTime>("k4_activationdate").Month)).ToString();
                    }
                }
                #endregion
                #region Contract length present
                if (myasset.Attributes.Contains("k4_contractlength") && myasset.GetAttributeValue<decimal>("k4_contractlength") > 0
                    && myasset.Attributes.Contains("k4_activationdate") && current != DateTime.MinValue)
                {
                    DateTime Deact = (myasset.GetAttributeValue<DateTime>("k4_activationdate").AddDays(Convert.ToDouble(myasset.GetAttributeValue<decimal>("k4_contractlength"))));
                    if (Deact < current.AddMonths(-1))//no billing for this asset
                    {
                        AssetExpired = true;
                    }
                    else
                    {
                        if (Deact > current && Deact <= NextMonthLeastActivationDate)//Use k4_deactivationdate
                        {
                            decimal datediff = (Deact - current).Days + 1;
                            baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(current.Year, current.Month);
                        }
                        else if (Deact > current.AddMonths(-1) && Deact < current)//Overage for this asset
                        {
                            baseAmount = 0.00m;
                        }
                        else if (Deact > current && Deact > NextMonthLeastActivationDate)//Use Monthly cost
                        {

                        }
                        if (myasset.GetAttributeValue<DateTime>("k4_activationdate") > current.AddMonths(-1) &&
                    myasset.GetAttributeValue<DateTime>("k4_activationdate") < current)//Overage for this asset
                        {
                            decimal datediff;
                            datediff = (current.AddDays(-1) - myasset.GetAttributeValue<DateTime>("k4_activationdate")).Days + 1;
                            k4_quotaingb = ((datediff * Convert.ToDecimal(k4_quotaingb)) / DateTime.DaysInMonth(myasset.GetAttributeValue<DateTime>("k4_activationdate").Year, myasset.GetAttributeValue<DateTime>("k4_activationdate").Month)).ToString();
                        }
                    }

                }
                #endregion
                #region No contract length,On going-NO, have activation and deactivation date 
                if (!myasset.Attributes.Contains("k4_contractlength")
                    && myasset.Attributes.Contains("k4_activated") && myasset.GetAttributeValue<bool>("k4_activated") == false
                    && myasset.Attributes.Contains("k4_activationdate") && current != DateTime.MinValue &&
                   myasset.Attributes.Contains("k4_deactivationdate") && myasset.GetAttributeValue<DateTime>("k4_deactivationdate") != DateTime.MinValue)
                {

                    if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") < current.AddMonths(-1))//no billing for this asset
                    {
                        AssetExpired = true;
                    }
                    else
                    {
                        if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > current &&
                       myasset.GetAttributeValue<DateTime>("k4_deactivationdate") <= NextMonthLeastActivationDate)//Use k4_deactivationdate
                        {
                            decimal datediff = (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") - current).Days + 1;
                            baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(current.Year, current.Month);


                        }
                        else if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > current.AddMonths(-1) &&
                            myasset.GetAttributeValue<DateTime>("k4_deactivationdate") < current)//Overage for this asset
                        {
                            baseAmount = 0.00m;
                        }
                        else if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > current &&
                          myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > NextMonthLeastActivationDate)//Use Monthly cost
                        {

                        }

                        if (myasset.GetAttributeValue<DateTime>("k4_activationdate") > current.AddMonths(-1) &&
                    myasset.GetAttributeValue<DateTime>("k4_activationdate") < current)//Overage for this asset
                        {
                            decimal datediff;
                            datediff = (current.AddDays(-1) - myasset.GetAttributeValue<DateTime>("k4_activationdate")).Days + 1;
                            k4_quotaingb = ((datediff * Convert.ToDecimal(k4_quotaingb)) / DateTime.DaysInMonth(myasset.GetAttributeValue<DateTime>("k4_activationdate").Year, myasset.GetAttributeValue<DateTime>("k4_activationdate").Month)).ToString();
                        }

                    }

                }
                #endregion
                msdyn_paymentdetail.Attributes["k4_baseamount"] = new Money(baseAmount);
                msdyn_paymentdetail.Attributes["k4_quotaingb"] = decimal.Round(Convert.ToDecimal(k4_quotaingb), 2, MidpointRounding.AwayFromZero).ToString() ;
                if (myasset.Attributes.Contains("discountpercentage") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("discountpercentage").Value) > 0)
                    numD = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("discountpercentage").Value);
                msdyn_paymentdetail.Attributes["k4_discountpercentage"] = numD;
                decimal num1 = baseAmount * numD / 100m;//Disount Amount calculated
                msdyn_paymentdetail.Attributes["k4_discountamount"] = new Money(num1);
                TotalDiscountAmt += num1;
                //Tax
                if (myasset.Attributes.Contains("taxpercentage") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("taxpercentage").Value) > 0)
                    numT = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("taxpercentage").Value);
                msdyn_paymentdetail.Attributes["k4_taxpercentage"] = numT;

                decimal num2 = (baseAmount - num1) * numT / 100m;//Tax Amount calculated
                msdyn_paymentdetail.Attributes["k4_taxamount"] = new Money(num2);
                TotalTaxAmt += num2;
                decimal k4_overagerate = 0.00m; 
                if (myasset.Attributes.Contains("vsatoverageprice") && ((Microsoft.Xrm.Sdk.Money)(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoverageprice")).Value).Value > 0)
                    k4_overagerate = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoverageprice").Value);
                if (myasset.Attributes.Contains("Fourgoverageprice") && ((Microsoft.Xrm.Sdk.Money)(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoverageprice").Value)).Value > 0)
                    k4_overagerate = ((Microsoft.Xrm.Sdk.Money)(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoverageprice").Value)).Value;
                msdyn_paymentdetail.Attributes["k4_overagerate"] = new Money(k4_overagerate);

                decimal k4_overageslabgb = 0.00m;
                if (myasset.Attributes.Contains("vsatoveragequotagb") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoveragequotagb").Value) > 0)
                    k4_overageslabgb = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoveragequotagb").Value);
                if (myasset.Attributes.Contains("Fourgoveragequotagb") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoveragequotagb").Value) > 0)
                    k4_overageslabgb = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoveragequotagb").Value);
                msdyn_paymentdetail.Attributes["k4_overageslabgb"] = k4_overageslabgb;
                msdyn_paymentdetail.Attributes["k4_dataspentasoveragegb"] = 0.00m;
                
                msdyn_paymentdetail.Attributes["msdyn_paymentamount"] = new Money(baseAmount + num2 - num1);
                TotalBaseAmt += baseAmount;
                if (!AssetExpired)
                    service.Create(msdyn_paymentdetail);
            }
            #endregion
            Entity msdyn_paymentUpdate = new Entity("msdyn_payment",paymentId);
            msdyn_paymentUpdate.Attributes["k4_totaldiscount"] = new Money(decimal.Round(TotalDiscountAmt, 2, MidpointRounding.AwayFromZero) );
            msdyn_paymentUpdate.Attributes["k4_totaltax"] = new Money(decimal.Round(TotalTaxAmt, 2, MidpointRounding.AwayFromZero));
            msdyn_paymentUpdate.Attributes["k4_installmentamount"] = new Money(decimal.Round(InstallmentAmount, 2, MidpointRounding.AwayFromZero) );
            msdyn_paymentUpdate.Attributes["msdyn_amount"] = new Money(decimal.Round(TotalBaseAmt, 2, MidpointRounding.AwayFromZero)  );
            service.Update(msdyn_paymentUpdate);
        }
        private EntityCollection getAccInstallment(IOrganizationService service, string accId, DateTime Current, DateTime endDate)
        {
            string fetchQuery =

                "<fetch top='50' >" +
"  <entity name='k4_installment' >" +
"    <attribute name='k4_periodstartdate' />" +
"    <attribute name='k4_paymentstage' />" +
"    <attribute name='k4_periodenddate' />" +
"    <attribute name='k4_amount' />" +
"    <filter>" +
"      <condition attribute='k4_account' operator='eq' value='{" + accId + "}' />" +
"      <condition attribute='k4_periodstartdate' operator='ge' value='" + Current.ToString("yyyy-MM-dd") + "' />" +
"      <condition attribute='k4_periodenddate' operator='le' value='" + endDate.ToString("yyyy-MM-dd") + "' />" +
"      <condition attribute='k4_paymentstage' operator='not-in' >" +
"        <value>636130001</value>" +
"        <value>636130003</value>" +
"      </condition>" +
"    </filter>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }

        private EntityCollection getAccAsset(IOrganizationService service, string accId)
        {
            string fetchQuery =
              "<fetch top='50' >" +
"  <entity name='msdyn_customerasset' alias='Asset' >" +
"    <attribute name='k4_deactivationdate'  />" +
"    <attribute name='k4_contractlength' />" +
"    <attribute name='k4_activated' />" +
"    <attribute name='k4_activationdate'  />" +
"    <attribute name='msdyn_customerassetid' alias='customerassetid' />" +
"    <filter>" +
"      <condition attribute='msdyn_account' operator='eq' value='{" + accId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"      <condition attribute='k4_productsubtype' operator='in' >" +
"        <value>636130000</value>" +
"        <value>636130001</value>" +
"        <value>636130003</value>" +
"      </condition>" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='msdyn_product' >" +

"      <attribute name='currentcost' alias='currentcost' />" +

"      <attribute name='k4_vsatquotaingb' alias='vsatquotaingb' />" +
"      <attribute name='k4_vsatoveragequotagb' alias='vsatoveragequotagb' />" +
"      <attribute name='k4_vsatoverageprice' alias='vsatoverageprice' />" +
"      <attribute name='k4_4gquotaingb' alias='Fourgquotaingb' />" +
"      <attribute name='k4_4goveragequotagb' alias='Fourgoveragequotagb' />" +
"      <attribute name='k4_4goverageprice' alias='Fourgoverageprice' />" +
"      <attribute name='k4_discountpercentage' alias='discountpercentage' />" +
"      <attribute name='k4_taxpercentage' alias='taxpercentage' />" +
"      <attribute name='k4_productsubtype' alias='productsubtype' />" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
        private EntityCollection getPaymentDetails(IOrganizationService service, string payId)
        {
            string fetchQuery =
               "<fetch top='50' >" +
"  <entity name='msdyn_paymentdetail' >" +
"    <attribute name='k4_totaloveragecost'  />" +
"    <attribute name='k4_baseamount' />" +
"    <attribute name='k4_discountamount' />" +
"    <attribute name='k4_taxamount'  />" +
"    <filter>" +
"      <condition attribute='msdyn_payment' operator='eq' value='{" + payId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
