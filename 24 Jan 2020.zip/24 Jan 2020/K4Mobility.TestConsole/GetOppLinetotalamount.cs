﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class GetOppLinetotalamount
    {
        public void Execute(IOrganizationService service)
        {
            #region Variable to Update
            EntityReference Opportunity = new EntityReference("opportunity", new Guid("6E82ECC5-0602-EA11-A811-000D3A0A827E"));
            decimal TotalExtendedAmount = 0.0m;
            #endregion
            String fetch =
                        "<fetch top='50' aggregate='true' >" +
"  <entity name='opportunityproduct' >" +
"    <attribute name='extendedamount' alias='total' aggregate='sum' />" +
"    <filter>" +
"      <condition attribute='opportunityid' operator='eq' value='" + Opportunity.Id + "' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";



            EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetch));
            if(result.Entities.Count>0)
            {
                TotalExtendedAmount = ((Microsoft.Xrm.Sdk.Money)((Microsoft.Xrm.Sdk.AliasedValue)result.Entities[0].Attributes["total"]).Value).Value;
            }

        }

    }
}
