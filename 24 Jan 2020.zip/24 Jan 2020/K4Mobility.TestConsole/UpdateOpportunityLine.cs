﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class UpdateOpportunityLine
    {
        public void Execute(IOrganizationService service)
        {
            decimal baseAmount = 325;
            decimal totalamount = 0;
            int k4_contractlength = 0;
            DateTime ActivationDate = new DateTime(2020, 1, 12);
            DateTime DeActivationDate = new DateTime(2020, 02, 02);
            DateTime k4_leastactivationdate = new DateTime(2020, 1, 12);
            decimal datediff = 0;// (DeActivationDate - ActivationDate).Days + 1;
            if (k4_leastactivationdate != DateTime.MinValue)
            {
                DateTime NextMonthLeastActivationDate = k4_leastactivationdate.AddMonths(1).AddDays(-1);
                if (k4_contractlength > 0)
                {
                    datediff = k4_contractlength;
                    totalamount = (datediff * baseAmount) / DateTime.DaysInMonth(k4_leastactivationdate.Year,
                        k4_leastactivationdate.Month);

                }
                if (k4_contractlength == 0 && ActivationDate != DateTime.MinValue &&
                  DeActivationDate != DateTime.MinValue && DeActivationDate > NextMonthLeastActivationDate)
                {
                    datediff = (NextMonthLeastActivationDate - ActivationDate).Days + 1;
                    totalamount = (datediff * baseAmount) / DateTime.DaysInMonth(k4_leastactivationdate.Year,
                        k4_leastactivationdate.Month);

                }
                #region Deactivation date is less than equal Next Month Least Activation Date
                if (k4_contractlength == 0 && ActivationDate != DateTime.MinValue &&
                  DeActivationDate != DateTime.MinValue && DeActivationDate <= NextMonthLeastActivationDate)
                {
                    datediff = (DeActivationDate - ActivationDate).Days + 1;
                    baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(k4_leastactivationdate.Year,
                        k4_leastactivationdate.Month);
                    decimal.Round(baseAmount, 2, MidpointRounding.AwayFromZero);
                }
                #endregion
            }
        }

    }
}
