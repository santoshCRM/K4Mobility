﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CloneProductExtra : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("TargetProductRecord")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> TargetProductRecord { get; set; }
        [RequiredArgument]
        [Input("SourceProductRecord")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> SourceProductRecord { get; set; }
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (TargetProductRecord.Get<EntityReference>(executionContext) != null && SourceProductRecord.Get<EntityReference>(executionContext) != null)
                {
                    EntityReference TargetProduct =new EntityReference(TargetProductRecord.Get<EntityReference>(executionContext).LogicalName,
                        TargetProductRecord.Get<EntityReference>(executionContext).Id);
                    EntityReference SourceProduct =
                        new EntityReference(SourceProductRecord.Get<EntityReference>(executionContext).LogicalName,
                        SourceProductRecord.Get<EntityReference>(executionContext).Id);
                    #region Clone Price list
                    string fetchPricelist = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
 "  <entity name='productpricelevel' >" +
 "    <attribute name='productid' />" +
 "    <attribute name='uomid' />" +
 "    <attribute name='pricingmethodcode' />" +
 "    <attribute name='amount' />" +
 "    <attribute name='transactioncurrencyid' />" +
 "    <attribute name='pricelevelid' />" +
 "    <order attribute='productid' descending='false' />" +
 "    <filter type='and' >" +
 "      <condition attribute='productid' operator='eq' value='{" + SourceProduct.Id + "}' />" +
 "    </filter>" +
 "  </entity>" +
 "</fetch>";
                    EntityCollection PricelistResult = service.RetrieveMultiple(new FetchExpression(fetchPricelist));
                    foreach (Entity pricelist in PricelistResult.Entities)
                    {
                        Entity newPricelist = new Entity(pricelist.LogicalName);
                        newPricelist["productid"] = TargetProduct;
                        newPricelist["uomid"] = pricelist["uomid"];
                        newPricelist["pricingmethodcode"] = pricelist["pricingmethodcode"];
                        newPricelist["amount"] = pricelist["amount"];
                        newPricelist["pricelevelid"] = pricelist["pricelevelid"];
                        service.Create(newPricelist);
                    }
                    #endregion
                    #region clone packs
                    string fetchproductsubstitute = "<fetch top='50' >" +
"  <entity name='productsubstitute' >" +
"    <attribute name='productid' />" +
"    <attribute name='direction' />" +
"    <attribute name='substitutedproductid' />" +
"    <attribute name='salesrelationshiptype' />" +
"    <filter>" +
"      <condition attribute='productid' operator='eq' value='{" + SourceProduct.Id + "}' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";

                    EntityCollection productsubstituteResult = service.RetrieveMultiple(new FetchExpression(fetchproductsubstitute));
                    foreach (Entity productsubstitute in productsubstituteResult.Entities)
                    {
                        Entity newproductsubstitute = new Entity(productsubstitute.LogicalName);
                        newproductsubstitute["productid"] = TargetProduct;
                        newproductsubstitute["direction"] = productsubstitute["direction"];
                        newproductsubstitute["substitutedproductid"] = productsubstitute["substitutedproductid"];
                        newproductsubstitute["salesrelationshiptype"] = productsubstitute["salesrelationshiptype"];
                        service.Create(newproductsubstitute);
                    }
                    #endregion
                    #region clone additional rules
                    string fetchadditionalrules = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='k4_planrule' >" +
"    <attribute name='k4_planruleid' />" +
"    <attribute name='k4_name' />" +
"    <attribute name='createdon' />" +
"    <order attribute='k4_name' descending='false' />" +
"    <link-entity name='k4_product_k4_additionalrules' from='k4_planruleid' to='k4_planruleid' intersect='true' >" +
"      <filter>" +
"        <condition attribute='productid' operator='eq' value='{" + SourceProduct.Id + "}' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";


                    EntityCollection additionalrulesResult = service.RetrieveMultiple(new FetchExpression(fetchadditionalrules));
                    foreach (Entity additionalrules in additionalrulesResult.Entities)
                    {
                        AssociateRequest request = new AssociateRequest();
                        EntityReference mon1 = new EntityReference(TargetProduct.LogicalName, TargetProduct.Id);
                        EntityReference mon2 = new EntityReference(additionalrules.LogicalName, additionalrules.Id);
                        request.Target = mon2;
                        request.RelatedEntities = new EntityReferenceCollection { mon1 };
                        request.Relationship = new Relationship("k4_product_k4_additionalrules");
                        service.Execute(request);
                    }
                    #endregion
                    #region clone recommended rules
                    string fetchrecommendedrules = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='k4_planrule' >" +
"    <attribute name='k4_planruleid' />" +
"    <attribute name='k4_name' />" +
"    <attribute name='createdon' />" +
"    <order attribute='k4_name' descending='false' />" +
"    <link-entity name='k4_product_k4_recommendedrules' from='k4_planruleid' to='k4_planruleid' intersect='true' >" +
"      <filter>" +
"        <condition attribute='productid' operator='eq' value='{" + SourceProduct.Id + "}' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";


                    EntityCollection recommendedrulesResult = service.RetrieveMultiple(new FetchExpression(fetchrecommendedrules));
                    foreach (Entity recommendedrules in recommendedrulesResult.Entities)
                    {
                        AssociateRequest request = new AssociateRequest();
                        EntityReference mon1 = new EntityReference(TargetProduct.LogicalName, TargetProduct.Id);
                        EntityReference mon2 = new EntityReference(recommendedrules.LogicalName, recommendedrules.Id);
                        request.Target = mon2;
                        request.RelatedEntities = new EntityReferenceCollection { mon1 };
                        request.Relationship = new Relationship("k4_product_k4_recommendedrules");
                        service.Execute(request);
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreateOppLine workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
