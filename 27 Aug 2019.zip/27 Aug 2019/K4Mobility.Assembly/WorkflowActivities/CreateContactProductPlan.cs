﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreateContactProductPlan : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Contact")]
        [ReferenceTarget("contact")]
        public InArgument<EntityReference> Contact { get; set; }
        [RequiredArgument]
        [Input("Order")]
        [ReferenceTarget("salesorder")]
        public InArgument<EntityReference> Order { get; set; }

        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Contact.Get<EntityReference>(executionContext) != null && Order.Get<EntityReference>(executionContext) != null)
                {
                    EntityReference ContactEntity = Contact.Get<EntityReference>(executionContext);
                    EntityReference OrderEntity = Order.Get<EntityReference>(executionContext);

                    string fetchsubscriptions = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>  <entity name='salesorderdetail'>    <attribute name='productid' />    <attribute name='extendedamount' />    <order attribute='productid' descending='false' />    <filter type='and'>      <condition attribute='salesorderid' operator='eq' value='{" + OrderEntity.Id + "}' />    </filter>    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ab'>      <filter type='and'>        <condition attribute='k4_productsubtype' operator='eq' value='636130000' />      </filter>    </link-entity>  </entity></fetch>";
                    EntityCollection subscriptions = service.RetrieveMultiple(new FetchExpression(fetchsubscriptions));
                    foreach (Entity subscription in subscriptions.Entities)
                    {
                        traceMessage += "\n creating subscription.";
                        Entity contactproductline = new Entity("k4_contactproductline");
                        contactproductline.Attributes["k4_contact"] = Contact.Get<EntityReference>(executionContext);
                        if (subscription.Attributes.Contains("productid"))
                        {
                            contactproductline.Attributes["k4_name"] = ((EntityReference)subscription.Attributes["productid"]).Name;
                            contactproductline.Attributes["k4_product"] = ((EntityReference)subscription.Attributes["productid"]);
                            contactproductline.Attributes["k4_productsubtype"] = new OptionSetValue(636130000);
                        }
                        if (subscription.Attributes.Contains("extendedamount"))
                            contactproductline.Attributes["k4_amount"] = (Money)subscription.Attributes["extendedamount"];
                        service.Create(contactproductline);
                    }

                    string fetchAddOns = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>  <entity name='salesorderdetail'>    <attribute name='productid' />    <attribute name='extendedamount' />    <order attribute='productid' descending='false' />    <filter type='and'>      <condition attribute='salesorderid' operator='eq' value='{" + OrderEntity.Id + "}' />    </filter>    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ab'>      <filter type='and'>        <condition attribute='k4_productsubtype' operator='eq' value='636130001' />      </filter>    </link-entity>  </entity></fetch>";
                    EntityCollection AddOns = service.RetrieveMultiple(new FetchExpression(fetchAddOns));
                    foreach (Entity AddOn in AddOns.Entities)
                    {
                        traceMessage += "\n creating Add On.";
                        Entity contactproductline = new Entity("k4_contactproductline");
                        contactproductline.Attributes["k4_contact"] = Contact.Get<EntityReference>(executionContext);
                        if (AddOn.Attributes.Contains("productid"))
                        {
                            contactproductline.Attributes["k4_name"] = ((EntityReference)AddOn.Attributes["productid"]).Name;
                            contactproductline.Attributes["k4_product"] = ((EntityReference)AddOn.Attributes["productid"]);
                            contactproductline.Attributes["k4_productsubtype"] = new OptionSetValue(636130001);
                        }
                        if (AddOn.Attributes.Contains("extendedamount"))
                            contactproductline.Attributes["k4_amount"] = (Money)AddOn.Attributes["extendedamount"];
                        service.Create(contactproductline);
                    }



                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreatePayments workflow: " + traceMessage+ ex.Message.ToString());
            }

        }
        #endregion
    }
}
