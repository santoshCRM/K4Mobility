﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace K4Mobility.Assembly.WorkflowActivities
{
   public class GetWorkOrderFromURL : CodeActivity
    {

        #region variable used
        private string traceMessage = string.Empty;

        [RequiredArgument]
        [Input("RecordURL")]
        public InArgument<string> RecordURL
        {
            get;
            set;
        }

        [Output("Work Order")]
        [ReferenceTarget("msdyn_workorder")]
        public OutArgument<EntityReference> msdyn_workorder
        {
            get;
            set;
        }
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (RecordURL.Get<string>(executionContext) != null)
                {
                    msdyn_workorder.Set(executionContext, new EntityReference("msdyn_workorder",new Guid(
                        RecordURL.Get<string>(executionContext).Substring(RecordURL.Get<string>(executionContext).IndexOf("&id=") + 4, 36)
                        )));
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in GetRecordIDFromURL workflow: " + ex.Message.ToString());
            }
        }
        #endregion
    }
}
