using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class PermanentSuspension : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;
        [RequiredArgument]
        [Input("Vessel Account")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("Suspension Date")]
        public InArgument<DateTime> SuspensionDate
        {
            get;
            set;
        }
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            decimal k4_baseplancost = 0.0m;
            decimal k4_associatedplancost = 0.0m;
            decimal k4_4gpackcost = 0.0m;
            decimal k4_voipfee = 0.0m;
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Account.Get<EntityReference>(executionContext) != null && SuspensionDate.Get<DateTime>(executionContext) != null
                    )
                {
                    DateTime CorrectSuspensionDate= SuspensionDate.Get<DateTime>(executionContext).ToUniversalTime().AddHours(5.5d);
                    DateTime suspensionFirstDate=new DateTime(CorrectSuspensionDate.Year, CorrectSuspensionDate.Month, 1).AddHours(-5.5d);
                    EntityCollection paymentInfo = getPaymentInfo(service, Account.Get<EntityReference>(executionContext).Id.ToString(), suspensionFirstDate);
                    if (paymentInfo.Entities.Count > 0)
                    {
                        foreach (Entity payment in paymentInfo.Entities)//Deactivate future payments
                        {

                            payment["statecode"] = new OptionSetValue(1);//Status
                            payment["statuscode"] = new OptionSetValue(2);//Status Reason
                            service.Update(payment);
                        }
                    }
                        EntityCollection CustomerAssets = getCustomerAssetInfo(service, Account.Get<EntityReference>(executionContext).Id.ToString());
                        if (CustomerAssets.Entities.Count > 0)
                        {
                        var details = from so in (IEnumerable<Entity>)CustomerAssets.Entities
                                      group so by ((Microsoft.Xrm.Sdk.OptionSetValue)so.Attributes["k4_productsubtype"]).Value into TotaledOrders
                                      select new
                                      {
                                          ProductSubType = TotaledOrders.Key,
                                          TotalValue = TotaledOrders.Sum((Entity s) => ((Money)((Microsoft.Xrm.Sdk.AliasedValue)s.Attributes["aa.msdyn_unitamount"]).Value).Value),
                                          Orders = TotaledOrders.ToList()
                                      };
                        foreach (var item in details)
                        {
                            if (item.ProductSubType == 636130000)//Subscription
                                k4_baseplancost = item.TotalValue;
                            if (item.ProductSubType == 636130001)//Top Up Plan-VSAT
                                k4_associatedplancost = item.TotalValue;
                            if (item.ProductSubType == 636130002)//HardWare
                            {
                            }
                            if (item.ProductSubType == 636130003)//Top Up Plan-4G
                                k4_4gpackcost = item.TotalValue;
                            if (item.ProductSubType == 636130004)// Hardware Installation Fee
                            {
                            }
                            if (item.ProductSubType == 636130005)//Activation Fee
                            {
                            }
                            if (item.ProductSubType == 636130006)//VOIP Fee
                                k4_voipfee = item.TotalValue;
                            if (item.ProductSubType == 636130007)//Survey Fee
                            {
                            }
                        }
                    }
                           
                        int days = 7;
                        //Suspension month payment:calculation
                        int Currentday = CorrectSuspensionDate.Day - 1;
                        decimal Secondlastmonth_k4baseplancost = (k4_baseplancost * Currentday) / DateTime.DaysInMonth(CorrectSuspensionDate.Year, CorrectSuspensionDate.Month);
                        decimal Secondlastmonth_k4_associatedplancost = (k4_associatedplancost * Currentday) / DateTime.DaysInMonth(CorrectSuspensionDate.Year, CorrectSuspensionDate.Month);
                        decimal Secondlastmonth_k4_4gpackcost = (k4_4gpackcost * Currentday) / DateTime.DaysInMonth(CorrectSuspensionDate.Year, CorrectSuspensionDate.Month);
                        decimal Secondlastmonth_k4_voipfee = (k4_voipfee * Currentday) / DateTime.DaysInMonth(CorrectSuspensionDate.Year, CorrectSuspensionDate.Month);
                        CreateBillingInvoice(service, 
                             Account.Get<EntityReference>(executionContext), suspensionFirstDate,
                            new Money(Convert.ToDecimal("0.0")), new Money(Secondlastmonth_k4baseplancost),
                 new Money(Convert.ToDecimal("0.0")), new Money(Secondlastmonth_k4_associatedplancost),
                 new Money(Secondlastmonth_k4_4gpackcost), new Money(Secondlastmonth_k4_voipfee), new Money(Convert.ToDecimal("0.0")),
                 new Money(Secondlastmonth_k4baseplancost + Secondlastmonth_k4_associatedplancost + Secondlastmonth_k4_4gpackcost +
                 Secondlastmonth_k4_voipfee), 0, days);
                        //Last Payment
                        CreateBillingInvoice(service,
                           Account.Get<EntityReference>(executionContext), suspensionFirstDate,
                          new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
               new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
               new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
               new Money(Convert.ToDecimal("0.0")), 1, days);
                    }
                
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreatePayments workflow: " + ex.Message.ToString());
            }
        }
        #endregion
        public void CreateBillingInvoice(IOrganizationService service,  EntityReference Account,
            DateTime Date, Money InstallationFee, Money k4_baseplancost, Money k4_hardwarecost, Money k4_associatedplancost,
            Money k4_4gpackcost, Money k4_voipfee, Money k4_activationfee, Money amount, int month, int days)
        {
            Entity msdyn_payment = new Entity("msdyn_payment");
            msdyn_payment.Attributes["msdyn_account"] = Account;
            msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
            msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + Date.AddMonths(month).ToString("dd MMMM yyyy"));
            msdyn_payment.Attributes["msdyn_date"] = Date.AddMonths(month).ToUniversalTime();
            msdyn_payment.Attributes["k4_duedateforpayment"] = Date.AddMonths(month).AddDays(days).ToUniversalTime();
            msdyn_payment.Attributes["k4_installationfee"] = InstallationFee;
            msdyn_payment.Attributes["k4_baseplancost"] = k4_baseplancost;
            msdyn_payment.Attributes["k4_hardwarecost"] = k4_hardwarecost;
            msdyn_payment.Attributes["k4_associatedplancost"] = k4_associatedplancost;
            msdyn_payment.Attributes["k4_4gpackcost"] = k4_4gpackcost;
            msdyn_payment.Attributes["k4_voipfee"] = k4_voipfee;
            msdyn_payment.Attributes["k4_activationfee"] = k4_activationfee;
            msdyn_payment.Attributes["k4_4goveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_vsatoveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_other"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["msdyn_amount"] = amount;
            service.Create(msdyn_payment);
        }
        private EntityCollection getPaymentInfo(IOrganizationService service, string AccId,DateTime suspensionFirstDate)
        {
            string fetchQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"  <entity name='msdyn_payment'>" +
"  " +
"    <attribute name='msdyn_paymentid' />" +
"   " +
"    <filter type='and'>" +
"      <condition attribute='msdyn_account' operator='eq' uiname='V215' uitype='account' value='{"+AccId+"}' />" +
"      <condition attribute='msdyn_date' operator='on-or-after' value='"+ suspensionFirstDate.ToString("yyyy-MM-dd") +"' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }

        private EntityCollection getCustomerAssetInfo(IOrganizationService service, string AccId)
        {
            string fetchQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='msdyn_customerasset' >" +
"    <attribute name='msdyn_customerassetid' />" +
"    <attribute name='k4_productsubtype' />" +
"    <filter type='and' >" +
"      <condition attribute='msdyn_account' operator='eq' uiname='V215' uitype='account' value='{" + AccId+"}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"    </filter>" +
"    <link-entity name='msdyn_workorderproduct' from='msdyn_workorderproductid' to='msdyn_workorderproduct' link-type='inner' alias='aa' >" +
"      <attribute name='msdyn_unitamount' />" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
