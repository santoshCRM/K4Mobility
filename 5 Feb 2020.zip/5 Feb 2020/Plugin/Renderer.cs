﻿using K4Mobility.Assembly.Plugin.Base;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;

namespace K4Mobility.Assembly.Plugin
{
    public class Renderer
    {
        private CookieContainer _cookies = new CookieContainer();
        private readonly Token _token;
        private readonly ILoggingService _logger;
        public Renderer(string resource, string username, string password, ILoggingService logger)
        {
            _logger = logger;
            _logger.Write($"Authenticating....");
            _token = GetToken(resource, username, password);
            _logger.Write($"Authenticated.");
        }

        public byte[] RenderReport(Microsoft.Xrm.Sdk.Entity report, string format, string parameters, ILoggingService trace)
        {
            
            var session = GetReportSession(report, parameters,trace);
            
            var url = "/Reserved.ReportViewerWebControl.axd";
            var lcid = report.GetAttributeValue<int>("languagecode");
            format = format.ToUpper();
            if (format == "WORD" || format == "EXCEL")
            {
                format = format + "OPENXML";
            }
            var data = new Dictionary<string, dynamic>()
            {
                ["OpType"] = "Export",
                ["Format"] = format,
                ["ContentDisposition"] = "AlwaysAttachment",
                ["FileName"] = string.Empty,
                ["Culture"] = lcid.ToString(),
                ["CultureOverrides"] = "False",
                ["UICulture"] = lcid.ToString(),
                ["UICultureOverrides"] = "False",
                ["ReportSession"] = session.Item1,
                ["ControlID"] = session.Item2
            };

            return GetResponse(GetRequest("GET", $"{url}?{data.UrlEncode()}"));
        }

        public string RenderExcelTemplate(Guid templateId, Guid viewId)
        {
            var url = "/api/data/v9.0/RenderTemplateFromView";
            var data = "{ \"Template\": { \"@odata.type\": \"Microsoft.Dynamics.CRM.documenttemplate\", \"documenttemplateid\": \"" + templateId.ToString("D") + "\"  }, \"View\": { \"@odata.type\": \"Microsoft.Dynamics.CRM.savedquery\", \"savedqueryid\": \"" + viewId.ToString("D") + "\"  } }";

            var request = GetRequest("POST", url, data, true);
            try
            {
                using (var response = request.GetResponse())
                using (var stream = response.GetResponseStream())
                using (var reader = new StreamReader(stream))
                {
                    var body = reader.ReadToEnd().Parse();
                    return body["ExcelFile"];
                }
            }
            catch (WebException ex)
            {
                using (var stream = ex.Response.GetResponseStream())
                using (var reader = new StreamReader(stream))
                {
                    Console.Write(reader.ReadToEnd());
                    throw;
                }
            }
        }

        public string RenderWordTemplate(Guid templateId, Guid entityId, int entityTypeCode)
        {
            var url = "/api/data/v9.0/ExportWordDocument";
            var data = "{ \"EntityTypeCode\": " + entityTypeCode + ", \"SelectedRecords\": \"[ '{" + entityId.ToString("D") + "}' ]\", \"SelectedTemplate\": { \"@odata.type\": \"Microsoft.Dynamics.CRM.documenttemplate\", \"documenttemplateid\": \"" + templateId.ToString("D") + "\" } }";

            var request = GetRequest("POST", url, data, true);

            try
            {
                using (var response = request.GetResponse())
                using (var stream = response.GetResponseStream())
                using (var reader = new StreamReader(stream))
                {
                    var body = reader.ReadToEnd().Parse();
                    return body["WordFile"];
                }
            }
            catch (WebException ex)
            {
                using (var stream = ex.Response.GetResponseStream())
                using (var reader = new StreamReader(stream))
                {
                    Console.Write(reader.ReadToEnd());
                    throw;
                }
            }
        }

        private Token GetToken(string resource, string username, string password)
        {
            var uri = $"https://login.microsoftonline.com/common/oauth2/token";

            var parameters = new Dictionary<string, dynamic>()
            {
                ["grant_type"] = "password",
                ["client_id"] = "2ad88395-b77d-4561-9441-d0e40824f9bc",
                ["username"] = username,
                ["password"] = password,
                ["resource"] = resource,
            };
            var request = WebRequest.CreateHttp(uri);
            request.Method = "POST";
            var body = Encoding.ASCII.GetBytes(parameters.UrlEncode());

            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = body.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(body, 0, body.Length);
            }

            using (var response = request.GetResponse())
            using (var stream = response.GetResponseStream())
            {
                var serializer = new DataContractJsonSerializer(typeof(Token));
                return serializer.ReadObject(stream) as Token;
            }
        }

        private Tuple<string, string> GetReportSession(Microsoft.Xrm.Sdk.Entity report, string parameters, ILoggingService trace)
        {
            var name = report.GetAttributeValue<string>("reportnameonsrs");
            var isCustom = name == null;
           // trace.Write(parameters.ToString());
            var url = "/CRMReports/RSViewer/ReportViewer.aspx";
            var data = new Dictionary<string, dynamic>()
            {
                ["id"] = report.Id.ToString("B"),
                ["iscustomreport"] = isCustom.ToString().ToLower(),
                ["reportnameonsrs"] = name
            };

            if (!string.IsNullOrEmpty(parameters))
            {
                if (isCustom)
                {
                    string[] array = parameters.Split(',');
                    foreach (string text in array)
                    {
                        string[] itemArr = text.Split(':');
                        if (itemArr.Length > 1)
                        {
                            data.Add("p:" + itemArr[0], itemArr[1]);
                        }
                    }
                }
                else
                {
                    var filter = new StringBuilder();
                    filter.Append("<ReportFilter>");
                    filter.Append("");
                    string[] arr = parameters.Split(',');
                    foreach (var ar1 in arr)
                    {
                        string[] itemArr = ar1.Split(':');
                        if (itemArr.Length > 1)
                        {
                            filter.Append("<ReportEntity paramname='"+itemArr[0]+"'>"+itemArr[1]+"</ReportEntity>");
                        }
                    }

                    //foreach (var parameter in parameters.Parse())
                    //{
                    //    filter.Append($"<ReportEntity paramname=\"{parameter.Key}\">{parameter.Value}</ReportEntity>");

                    //}
                    filter.Append("</ReportFilter>");
                    trace.Write(filter.ToString());
                    data.Add("CRM_Filter", filter.ToString());
                }
            }
            else
            {
                if (!isCustom)
                {
                    var defaultFilter = report.GetAttributeValue<string>("defaultfilter");
                    data.Add("CRM_Filter", defaultFilter);
                }
            }

            var response = Encoding.UTF8.GetString(GetResponse(GetRequest("POST", url, data.UrlEncode())));

            var sessionId = response.Substring(response.LastIndexOf("ReportSession=") + 14, 24);
            var controlId = response.Substring(response.LastIndexOf("ControlID=") + 10, 32);

            return new Tuple<string, string>(sessionId, controlId);
        }

        private HttpWebRequest GetRequest(string method, string url, string data = null, bool isJson = false)
        {
            var request = WebRequest.CreateHttp($"{_token.Resource}{url}");
            request.Method = method;
            request.CookieContainer = _cookies;
            if (_token != null)
            {
                request.Headers.Add("Authorization", $"Bearer {_token.AccessToken}");
            }
            request.AutomaticDecompression = DecompressionMethods.GZip;
            _logger.Write($"{request.Method} {request.RequestUri.ToString()}");
            if (string.IsNullOrEmpty(data) == false)
            {
                if (isJson)
                {
                    var body = Encoding.ASCII.GetBytes(data);

                    request.ContentType = "application/json";
                    request.ContentLength = body.Length;

                    using (var stream = request.GetRequestStream())
                    {
                        stream.Write(body, 0, body.Length);
                    }
                }
                else
                {
                    var body = Encoding.ASCII.GetBytes(data);

                    request.ContentType = "application/x-www-form-urlencoded";
                    request.ContentLength = body.Length;

                    using (var stream = request.GetRequestStream())
                    {
                        stream.Write(body, 0, body.Length);
                    }
                }
                _logger.Write(data);
            }

            return request;
        }

        private byte[] GetResponse(HttpWebRequest request)
        {
            using (var response = request.GetResponse() as HttpWebResponse)
            {
                if (response.ResponseUri.PathAndQuery.Contains("errorhandler.aspx"))
                {
                    var queryString = response.ResponseUri.Query.UrlDecode();

                    if (queryString.ContainsKey("Parm0"))
                    {
                        _logger.Write($"Parm0: {queryString["Parm0"]}");
                    }
                    if (queryString.ContainsKey("Parm1"))
                    {
                        _logger.Write($"Parm1: {queryString["Parm1"]}");
                    }

                    throw new Exception($"Error executing web request: {request.RequestUri}");
                }

                using (var stream = response.GetResponseStream())
                using (var stream2 = new MemoryStream())
                {
                    stream.CopyTo(stream2);
                    return stream2.ToArray();
                }
            }
        }
    }
}
