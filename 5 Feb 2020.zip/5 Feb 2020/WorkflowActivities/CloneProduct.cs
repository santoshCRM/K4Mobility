﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CloneProduct : CodeActivity
    {

        #region variable used
       
        [RequiredArgument]
        [Input("Source Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> SourceProduct { get; set; }

        [RequiredArgument]
        [Output("Cloned Product")]
        [ReferenceTarget("product")]
        public OutArgument<EntityReference> ClonedProduct { get; set; }
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (SourceProduct.Get<EntityReference>(executionContext) != null )
                {
                    CloneProductRequest cloneReq = new CloneProductRequest
                    {
                        Source = new EntityReference(SourceProduct.Get<EntityReference>(executionContext).LogicalName, SourceProduct.Get<EntityReference>(executionContext).Id)
                    };

                    CloneProductResponse cloned = (CloneProductResponse)service.Execute(cloneReq);
                    EntityReference TargetProduct = new EntityReference(SourceProduct.Get<EntityReference>(executionContext).LogicalName, cloned.ClonedProduct.Id);
                    ClonedProduct.Set(executionContext, TargetProduct);
                    #region Clone Price list
                    string fetchPricelist = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
 "  <entity name='productpricelevel' >" +
 "    <attribute name='productid' />" +
 "    <attribute name='uomid' />" +
 "    <attribute name='pricingmethodcode' />" +
 "    <attribute name='amount' />" +
 "    <attribute name='transactioncurrencyid' />" +
 "    <attribute name='pricelevelid' />" +
 "    <order attribute='productid' descending='false' />" +
 "    <filter type='and' >" +
 "      <condition attribute='productid' operator='eq' value='{" + SourceProduct.Get<EntityReference>(executionContext).Id + "}' />" +
 "    </filter>" +
 "  </entity>" +
 "</fetch>";
                    EntityCollection PricelistResult = service.RetrieveMultiple(new FetchExpression(fetchPricelist));
                    foreach (Entity pricelist in PricelistResult.Entities)
                    {
                        Entity newPricelist = new Entity(pricelist.LogicalName);
                        newPricelist["productid"] = TargetProduct;
                        newPricelist["uomid"] = pricelist["uomid"];
                        newPricelist["pricingmethodcode"] = pricelist["pricingmethodcode"];
                        newPricelist["amount"] = pricelist["amount"];
                        newPricelist["pricelevelid"] = pricelist["pricelevelid"];
                        service.Create(newPricelist);
                    }
                    #endregion

                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CloneProduct workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
