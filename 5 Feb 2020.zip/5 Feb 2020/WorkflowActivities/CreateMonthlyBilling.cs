using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreateMonthlyBilling : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;

        [RequiredArgument]
        [Input("Account")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("Date From")]
        public InArgument<DateTime> DateFrom
        {
            get;
            set;
        }
        [Output("Service End Date")]
        public OutArgument<DateTime> ServiceEndDate
        {
            get;
            set;
        }
       
        [RequiredArgument]
        [Input("PlanDuration")]
        public InArgument<Int32> PlanDuration
        {
            get;
            set;
        }
        [Input("Acc Advance Payment")]
        public InArgument<Money> AccAdvancePayment
        {
            get;
            set;
        }

        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            //decimal k4_baseplancost = 0.0m;
            //decimal k4_associatedplancost = 0.0m;
            //decimal k4_4gactivationfee = 0.0m;
            //decimal k4_4gpackcost = 0.0m;
            //decimal k4_voipfee = 0.0m;
            //decimal k4_vsatoverageprice = 0.0m;
            //decimal k4_4goverageprice = 0.0m;
            //decimal k4_voiprate = 0.0m;

            //decimal k4_Arrear = 0.0m;
            //decimal k4_OldPlanAmount = 0.0m;
            //decimal k4_NewPlanAmount = 0.0m;

            //EntityReference k4_newvsatplan = null;
            //EntityReference k4_new4gplan = null;
            //EntityReference k4_newplan = null;

            //EntityReference k4_vsat = null;
            //EntityReference k4_4gplan = null;
            //EntityReference k4_plan = null;

            bool AssetExpired = false;
            decimal TotalTaxAmt = 0.00m;//TotalTaxAmount
            decimal TotalDiscountAmt = 0.00m;//TotalTaxAmount
            decimal TotalBaseAmt = 0.00m;//TotalBaseAmt
            decimal InstallmentAmount = 0.00m;//InstallmentAmount
            decimal AdvancePayment = 0.00m;//AdvancePayment
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Account.Get<EntityReference>(executionContext) != null && DateFrom.Get<DateTime>(executionContext) != null
                    && PlanDuration.Get<float>(executionContext) > 0)
                {
                    if(AccAdvancePayment.Get<Money>(executionContext) != null)
                        AdvancePayment = AccAdvancePayment.Get<Money>(executionContext).Value;
                    
                    DateTime current = DateFrom.Get<DateTime>(executionContext).ToUniversalTime().AddDays(1);//.AddHours(5.5d);
                    int months = (int)PlanDuration.Get<float>(executionContext);
                    int days = 7;
                    DateTime NextMonthLeastActivationDate = current.AddMonths(months).AddDays(-1);
                    ServiceEndDate.Set(executionContext, NextMonthLeastActivationDate);

                    Entity msdyn_payment = new Entity("msdyn_payment");
                    msdyn_payment.Attributes["msdyn_account"] = new EntityReference(Account.Get<EntityReference>(executionContext).LogicalName, Account.Get<EntityReference>(executionContext).Id); ;
                    msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
                    msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + current.ToString("dd MMMM yyyy"));
                    msdyn_payment.Attributes["msdyn_date"] = current.ToUniversalTime();
                    msdyn_payment.Attributes["k4_duedateforpayment"] = current.AddDays(days).ToUniversalTime();
                    msdyn_payment.Attributes["k4_periodstartdate"] = current;
                    msdyn_payment.Attributes["k4_periodenddate"] = current.AddMonths(months).AddDays(-1);
                    //   msdyn_payment.Attributes["msdyn_amount"] = new Money(0.00m);
                    msdyn_payment.Attributes["k4_totaldiscount"] = new Money(0.00m);
                    msdyn_payment.Attributes["k4_totaltax"] = new Money(0.00m);
                    msdyn_payment.Attributes["k4_installmentamount"] = new Money(0.00m);
                    msdyn_payment.Attributes["k4_totaloveragecost"] = new Money(0.00m);
                    msdyn_payment.Attributes["k4_advancepayment"] = new Money(AdvancePayment);
                    Guid paymentId = service.Create(msdyn_payment);
                    #region Add Installment
                    EntityCollection Installments = getAccInstallment(service, Account.Get<EntityReference>(executionContext).Id.ToString(), current, current.AddMonths(months));
                    //throw new InvalidPluginExecutionException("Installment Count: " +Installments.Entities.Count.ToString());
                    foreach (Entity myInstallment in Installments.Entities)
                    {
                        AssociateRequest request = new AssociateRequest();
                        EntityReference mon1 = new EntityReference(msdyn_payment.LogicalName, paymentId);
                        EntityReference mon2 = new EntityReference(myInstallment.LogicalName, myInstallment.Id);
                        request.Target = mon2;
                        request.RelatedEntities = new EntityReferenceCollection { mon1 };
                        request.Relationship = new Relationship("k4_msdyn_payment_k4_installment");
                        service.Execute(request);
                        if (myInstallment.Attributes.Contains("k4_amount"))
                        {
                            InstallmentAmount += ((Microsoft.Xrm.Sdk.Money)(myInstallment.Attributes["k4_amount"])).Value;
                        }
                    }
                    #endregion
                    EntityCollection customerAsset = getAccAsset(service, Account.Get<EntityReference>(executionContext).Id.ToString());

                    #region Create payment details
                    foreach (Entity myasset in customerAsset.Entities)
                    {
                        //Create payment details
                        Entity msdyn_paymentdetail = new Entity("msdyn_paymentdetail");
                        decimal numD = 0.00m;//discount
                        decimal numT = 0.00m;//tax
                        decimal baseAmount = 0.00m;
                        string k4_quotaingb = "0";
                        msdyn_paymentdetail.Attributes["k4_discountpercentage"] = 0.00m;
                        msdyn_paymentdetail.Attributes["k4_discountamount"] = new Money(numT);
                        msdyn_paymentdetail.Attributes["k4_taxpercentage"] = 0.00m;
                        msdyn_paymentdetail.Attributes["k4_taxamount"] = new Money(numD);
                        msdyn_paymentdetail.Attributes["msdyn_payment"] = new EntityReference(msdyn_payment.LogicalName, paymentId);
                        msdyn_paymentdetail.Attributes["k4_customerasset"] = new EntityReference(myasset.LogicalName, myasset.Id);
                        msdyn_paymentdetail.Attributes["k4_totaloveragecost"] = new Money(numT);

                        if (myasset.Attributes.Contains("k4_contractlength"))
                            msdyn_paymentdetail.Attributes["k4_contractlength"] = myasset.GetAttributeValue<decimal>("k4_contractlength");
                        if (myasset.Attributes.Contains("k4_activationdate") && myasset.GetAttributeValue<DateTime>("k4_activationdate") != DateTime.MinValue)
                            msdyn_paymentdetail.Attributes["k4_activationdate"] = myasset.GetAttributeValue<DateTime>("k4_activationdate");
                        if (myasset.Attributes.Contains("k4_deactivationdate") && myasset.GetAttributeValue<DateTime>("k4_deactivationdate") != DateTime.MinValue)
                            msdyn_paymentdetail.Attributes["k4_deactivationdate"] = myasset.GetAttributeValue<DateTime>("k4_deactivationdate");
                        if (myasset.Attributes.Contains("k4_activated"))
                            msdyn_paymentdetail.Attributes["k4_ongoing"] = myasset.GetAttributeValue<bool>("k4_activated");

                        if (myasset.Attributes.Contains("currentcost") && myasset.GetAttributeValue<Money>("currentcost").Value > 0)
                            baseAmount = myasset.GetAttributeValue<Money>("currentcost").Value;
                        if (myasset.Attributes.Contains("vsatquotaingb") && myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatquotaingb").Value.ToString()!=string.Empty)
                            k4_quotaingb = myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatquotaingb").Value.ToString();
                        if (myasset.Attributes.Contains("Fourgquotaingb") && myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgquotaingb").Value.ToString() != string.Empty)
                            k4_quotaingb = myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgquotaingb").Value.ToString();

                        #region On going Customer asset product-yes
                        if (myasset.Attributes.Contains("k4_activated") && myasset.GetAttributeValue<bool>("k4_activated"))
                        {
                            if (myasset.GetAttributeValue<DateTime>("k4_activationdate") > current.AddMonths(-1) &&
                              myasset.GetAttributeValue<DateTime>("k4_activationdate") < current)//Overage for this asset
                            {
                                decimal datediff;
                                datediff = (current.AddDays(-1)-myasset.GetAttributeValue<DateTime>("k4_activationdate")).Days + 1;
                                k4_quotaingb = ((datediff * Convert.ToDecimal(k4_quotaingb)) / DateTime.DaysInMonth(myasset.GetAttributeValue<DateTime>("k4_activationdate").Year, myasset.GetAttributeValue<DateTime>("k4_activationdate").Month)).ToString();
                            }
                        }
                        #endregion
                        #region Contract length present
                        if (myasset.Attributes.Contains("k4_contractlength") && myasset.GetAttributeValue<decimal>("k4_contractlength") > 0
                            && myasset.Attributes.Contains("k4_activationdate") && current != DateTime.MinValue)
                        {
                            DateTime Deact = (myasset.GetAttributeValue<DateTime>("k4_activationdate").AddDays(Convert.ToDouble(myasset.GetAttributeValue<decimal>("k4_contractlength"))));
                            if (Deact< current.AddMonths(-1))//no billing for this asset
                            {
                                AssetExpired = true;
                            }
                            else
                            {
                                if (Deact > current && Deact <= NextMonthLeastActivationDate)//Use k4_deactivationdate
                                {
                                    decimal datediff = (Deact - current).Days + 1;
                                    baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(current.Year, current.Month);
                                }
                                else if (Deact > current.AddMonths(-1) &&  Deact < current)//Overage for this asset
                                {
                                    baseAmount = 0.00m;
                                }
                                else if (Deact > current && Deact > NextMonthLeastActivationDate)//Use Monthly cost
                                {

                                }
                                if (myasset.GetAttributeValue<DateTime>("k4_activationdate") > current.AddMonths(-1) &&
                            myasset.GetAttributeValue<DateTime>("k4_activationdate") < current)//Overage for this asset
                                {
                                    decimal datediff;
                                    datediff = (current.AddDays(-1) - myasset.GetAttributeValue<DateTime>("k4_activationdate")).Days + 1;
                                    k4_quotaingb = ((datediff * Convert.ToDecimal(k4_quotaingb)) / DateTime.DaysInMonth(myasset.GetAttributeValue<DateTime>("k4_activationdate").Year, myasset.GetAttributeValue<DateTime>("k4_activationdate").Month)).ToString();
                                }
                            }

                        }
                        #endregion
                        #region No contract length,On going-NO, have activation and deactivation date 
                        if (!myasset.Attributes.Contains("k4_contractlength")
                            && myasset.Attributes.Contains("k4_activated") && myasset.GetAttributeValue<bool>("k4_activated") == false
                            && myasset.Attributes.Contains("k4_activationdate") && current != DateTime.MinValue &&
                           myasset.Attributes.Contains("k4_deactivationdate") && myasset.GetAttributeValue<DateTime>("k4_deactivationdate") != DateTime.MinValue)
                        {
                          
                            if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") < current.AddMonths(-1))//no billing for this asset
                            {
                                AssetExpired = true;
                            }
                            else
                            {
                                if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > current &&
                               myasset.GetAttributeValue<DateTime>("k4_deactivationdate") <= NextMonthLeastActivationDate)//Use k4_deactivationdate
                                {
                                    decimal datediff = (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") - current).Days + 1;
                                    baseAmount = (datediff * baseAmount) / DateTime.DaysInMonth(current.Year, current.Month);

                                   
                                }
                                else if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > current.AddMonths(-1) &&
                                    myasset.GetAttributeValue<DateTime>("k4_deactivationdate") < current)//Overage for this asset
                                {
                                    baseAmount = 0.00m;
                                }
                                else if (myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > current &&
                                  myasset.GetAttributeValue<DateTime>("k4_deactivationdate") > NextMonthLeastActivationDate)//Use Monthly cost
                                {

                                }

                                if (myasset.GetAttributeValue<DateTime>("k4_activationdate") > current.AddMonths(-1) &&
                            myasset.GetAttributeValue<DateTime>("k4_activationdate") < current)//Overage for this asset
                                {
                                    decimal datediff;
                                    datediff = (current.AddDays(-1) - myasset.GetAttributeValue<DateTime>("k4_activationdate")).Days + 1;
                                    k4_quotaingb = ((datediff * Convert.ToDecimal(k4_quotaingb)) / DateTime.DaysInMonth(myasset.GetAttributeValue<DateTime>("k4_activationdate").Year, myasset.GetAttributeValue<DateTime>("k4_activationdate").Month)).ToString();
                                }

                            }

                        }
                        #endregion
                        msdyn_paymentdetail.Attributes["k4_baseamount"] = new Money(baseAmount);
                        msdyn_paymentdetail.Attributes["k4_quotaingb"] = decimal.Round(Convert.ToDecimal(k4_quotaingb), 2, MidpointRounding.AwayFromZero).ToString(); 
                        if (myasset.Attributes.Contains("discountpercentage") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("discountpercentage").Value) > 0)
                            numD = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("discountpercentage").Value);
                        msdyn_paymentdetail.Attributes["k4_discountpercentage"] = numD;
                        decimal num1 = baseAmount * numD / 100m;//Discount Amount calculated
                        msdyn_paymentdetail.Attributes["k4_discountamount"] = new Money(num1);
                        TotalDiscountAmt += num1;
                        //Tax
                        if (myasset.Attributes.Contains("taxpercentage") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("taxpercentage").Value) > 0)
                            numT = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("taxpercentage").Value);
                        msdyn_paymentdetail.Attributes["k4_taxpercentage"] = numT;

                        decimal num2 = (baseAmount - num1) * numT / 100m;//Tax Amount calculated
                        msdyn_paymentdetail.Attributes["k4_taxamount"] = new Money(num2);
                        TotalTaxAmt += num2;
                        decimal k4_overagerate = 0.00m;
                        if (myasset.Attributes.Contains("vsatoverageprice") && ((Microsoft.Xrm.Sdk.Money)(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoverageprice")).Value).Value > 0)
                            k4_overagerate = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoverageprice").Value);
                        if (myasset.Attributes.Contains("Fourgoverageprice") && ((Microsoft.Xrm.Sdk.Money)(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoverageprice").Value)).Value > 0)
                            k4_overagerate = ((Microsoft.Xrm.Sdk.Money)(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoverageprice").Value)).Value;
                        msdyn_paymentdetail.Attributes["k4_overagerate"] = new Money(k4_overagerate);

                        decimal k4_overageslabgb = 0.00m;
                        if (myasset.Attributes.Contains("vsatoveragequotagb") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoveragequotagb").Value) > 0)
                            k4_overageslabgb = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("vsatoveragequotagb").Value);
                        if (myasset.Attributes.Contains("Fourgoveragequotagb") && Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoveragequotagb").Value) > 0)
                            k4_overageslabgb = Convert.ToDecimal(myasset.GetAttributeValue<Microsoft.Xrm.Sdk.AliasedValue>("Fourgoveragequotagb").Value);
                        msdyn_paymentdetail.Attributes["k4_overageslabgb"] = k4_overageslabgb;
                        msdyn_paymentdetail.Attributes["k4_dataspentasoveragegb"] = 0.00m;

                        msdyn_paymentdetail.Attributes["msdyn_paymentamount"] = new Money(baseAmount + num2 - num1);
                        TotalBaseAmt += baseAmount;
                        if (!AssetExpired)
                            service.Create(msdyn_paymentdetail);
                        traceMessage += "Create msdyn_paymentdetail Ended";
                    }
                    #endregion
                    Entity msdyn_paymentUpdate = new Entity("msdyn_payment", paymentId);
                    msdyn_paymentUpdate.Attributes["k4_totaldiscount"] = new Money(decimal.Round(TotalDiscountAmt, 2, MidpointRounding.AwayFromZero));
                    msdyn_paymentUpdate.Attributes["k4_totaltax"] = new Money(decimal.Round(TotalTaxAmt, 2, MidpointRounding.AwayFromZero));
                    msdyn_paymentUpdate.Attributes["k4_installmentamount"] = new Money(decimal.Round(InstallmentAmount, 2, MidpointRounding.AwayFromZero));
                    msdyn_paymentUpdate.Attributes["msdyn_amount"] = new Money(decimal.Round(TotalBaseAmt, 2, MidpointRounding.AwayFromZero));
                    service.Update(msdyn_paymentUpdate);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreateMonthlyBilling workflow: " + ex.Message.ToString()
                    + "traceMessage: " + traceMessage);
            }
        }
        #endregion





        private EntityCollection getAccAsset(IOrganizationService service, string accId)
        {
            string fetchQuery =
              "<fetch top='50' >" +
"  <entity name='msdyn_customerasset' alias='Asset' >" +
"    <attribute name='k4_deactivationdate'  />" +
"    <attribute name='k4_contractlength' />" +
"    <attribute name='k4_activated' />" +
"    <attribute name='k4_activationdate'  />" +
"    <attribute name='msdyn_customerassetid' alias='customerassetid' />" +
"    <filter>" +
"      <condition attribute='msdyn_account' operator='eq' value='{" + accId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"      <condition attribute='k4_productsubtype' operator='in' >" +
"        <value>636130000</value>" +
"        <value>636130001</value>" +
"        <value>636130003</value>" +
"      </condition>" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='msdyn_product' >" +

"      <attribute name='currentcost' alias='currentcost' />" +

"      <attribute name='k4_vsatquotaingb' alias='vsatquotaingb' />" +
"      <attribute name='k4_vsatoveragequotagb' alias='vsatoveragequotagb' />" +
"      <attribute name='k4_vsatoverageprice' alias='vsatoverageprice' />" +
"      <attribute name='k4_4gquotaingb' alias='Fourgquotaingb' />" +
"      <attribute name='k4_4goveragequotagb' alias='Fourgoveragequotagb' />" +
"      <attribute name='k4_4goverageprice' alias='Fourgoverageprice' />" +
"      <attribute name='k4_discountpercentage' alias='discountpercentage' />" +
"      <attribute name='k4_taxpercentage' alias='taxpercentage' />" +
"      <attribute name='k4_productsubtype' alias='productsubtype' />" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
        private EntityCollection getAccInstallment(IOrganizationService service, string accId, DateTime Current, DateTime endDate)
        {
            string fetchQuery =

                "<fetch top='50' >" +
"  <entity name='k4_installment' >" +
"    <attribute name='k4_periodstartdate' />" +
"    <attribute name='k4_paymentstage' />" +
"    <attribute name='k4_periodenddate' />" +
"    <attribute name='k4_amount' />" +
"    <filter>" +
"      <condition attribute='k4_account' operator='eq' value='{" + accId + "}' />" +
"      <condition attribute='k4_periodstartdate' operator='ge' value='" + Current.ToString("yyyy-MM-dd") + "' />" +
"      <condition attribute='k4_periodenddate' operator='le' value='" + endDate.ToString("yyyy-MM-dd") + "' />" +
"      <condition attribute='k4_paymentstage' operator='not-in' >" +
"        <value>636130001</value>" +
"        <value>636130003</value>" +
"      </condition>" +
"    </filter>" +
"  </entity>" +
"</fetch>";
          //  throw new InvalidPluginExecutionException("fetchQuery : " + fetchQuery);
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }



        #region Execute  function backup
        //public void CreateBillingInvoice(IOrganizationService service,EntityReference Account, DateTime ActivationDate,
        //       Money k4_installationfee, Money k4_baseplancost,
        //       Money k4_hardwarecost, Money k4_associatedplancost,
        //       Money k4_4gpackcost, Money k4_voipfee, Money k4_activationfee, Money amount, int month, int days,
        //       DateTime k4_periodstartdate, DateTime k4_periodenddate, Money k4_4gactivationfee,
        //        Money k4_vsatoverageprice, Money k4_4goverageprice, Money k4_voiprate
        //     , Money k4_arrear, Money k4_oldplanamount, Money k4_newplanamount
        //    , EntityReference k4_plan, EntityReference k4_vsat, EntityReference k4_4gplan
        //      , EntityReference k4_newplan, EntityReference k4_newvsatplan, EntityReference k4_new4gplan)
        //{
        //    Entity msdyn_payment = new Entity("msdyn_payment");
        //    msdyn_payment.Attributes["msdyn_account"] = Account;
        //    msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
        //    msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + ActivationDate.AddMonths(month).ToString("dd MMMM yyyy"));
        //    msdyn_payment.Attributes["msdyn_date"] = ActivationDate.AddMonths(month).ToUniversalTime();
        //    msdyn_payment.Attributes["k4_duedateforpayment"] = ActivationDate.AddMonths(month).AddDays(days).ToUniversalTime();
        //    msdyn_payment.Attributes["k4_periodstartdate"] = k4_periodstartdate;
        //    msdyn_payment.Attributes["k4_periodenddate"] = k4_periodenddate;
        //    msdyn_payment.Attributes["k4_installationfee"] = k4_installationfee;
        //    msdyn_payment.Attributes["k4_baseplancost"] = k4_baseplancost;
        //    msdyn_payment.Attributes["k4_hardwarecost"] = k4_hardwarecost;
        //    msdyn_payment.Attributes["k4_associatedplancost"] = k4_associatedplancost;
        //    msdyn_payment.Attributes["k4_4gpackcost"] = k4_4gpackcost;
        //    msdyn_payment.Attributes["k4_voipfee"] = k4_voipfee;
        //    msdyn_payment.Attributes["k4_activationfee"] = k4_activationfee;//VSAT activation fee
        //    msdyn_payment.Attributes["k4_4gactivationfee"] = k4_4gactivationfee;
        //    msdyn_payment.Attributes["k4_4goveragecost"] = new Money(Convert.ToDecimal("0.0"));
        //    msdyn_payment.Attributes["k4_vsatoveragecost"] = new Money(Convert.ToDecimal("0.0"));
        //    msdyn_payment.Attributes["k4_other"] = new Money(Convert.ToDecimal("0.0"));
        //    msdyn_payment.Attributes["msdyn_amount"] = amount;

        //    msdyn_payment.Attributes["k4_vsatoverageprice"] = k4_vsatoverageprice;
        //    msdyn_payment.Attributes["k4_4goverageprice"] = k4_4goverageprice;
        //    msdyn_payment.Attributes["k4_voiprate"] = k4_voiprate;
        //    msdyn_payment.Attributes["k4_totalvoipcharges"] = new Money(Convert.ToDecimal("0.0"));


        //    msdyn_payment.Attributes["k4_arrear"] = k4_arrear;
        //    msdyn_payment.Attributes["k4_oldplanamount"] = k4_oldplanamount;
        //    msdyn_payment.Attributes["k4_newplanamount"] = k4_newplanamount;
        //    if (k4_plan != null)
        //        msdyn_payment.Attributes["k4_plan"] = k4_plan;
        //    if (k4_vsat != null)
        //        msdyn_payment.Attributes["k4_vsatplan"] = k4_vsat;
        //    if (k4_4gplan != null)
        //        msdyn_payment.Attributes["k4_4gplan"] = k4_4gplan;

        //    if (k4_newplan != null)
        //        msdyn_payment.Attributes["k4_newplan"] = k4_newplan;
        //    if (k4_newvsatplan != null)
        //        msdyn_payment.Attributes["k4_newvsatplan"] = k4_newvsatplan;
        //    if (k4_new4gplan != null)
        //        msdyn_payment.Attributes["k4_new4gplan"] = k4_new4gplan;

        //    service.Create(msdyn_payment);
        //}

        //protected override void Execute(CodeActivityContext executionContext)
        //{
        //    //Create the tracing service
        //    ITracingService tracingService = executionContext.GetExtension<ITracingService>();
        //    //Create the context
        //    IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
        //    IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
        //    IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
        //    decimal k4_baseplancost = 0.0m;
        //    decimal k4_associatedplancost = 0.0m;
        //    decimal k4_4gactivationfee = 0.0m;
        //    decimal k4_4gpackcost = 0.0m;
        //    decimal k4_voipfee = 0.0m;
        //    decimal k4_vsatoverageprice = 0.0m;
        //    decimal k4_4goverageprice = 0.0m;
        //    decimal k4_voiprate = 0.0m;

        //    decimal k4_Arrear = 0.0m;
        //    decimal k4_OldPlanAmount = 0.0m;
        //    decimal k4_NewPlanAmount = 0.0m;

        //    EntityReference k4_newvsatplan = null;
        //    EntityReference k4_new4gplan = null;
        //    EntityReference k4_newplan = null;

        //    EntityReference k4_vsat = null;
        //    EntityReference k4_4gplan = null;
        //    EntityReference k4_plan = null;

        //    try
        //    {
        //        traceMessage = "Workflow started.";
        //        tracingService.Trace(traceMessage);
        //        if (Account.Get<EntityReference>(executionContext) != null && DateFrom.Get<DateTime>(executionContext) != null
        //            && PlanDuration.Get<float>(executionContext) > 0)
        //        {
        //            EntityCollection customerAsset = getAccAsset(service, Account.Get<EntityReference>(executionContext).Id.ToString());
        //            DateTime current = DateFrom.Get<DateTime>(executionContext).ToUniversalTime().AddDays(1);//.AddHours(5.5d);
        //            int months = (int)PlanDuration.Get<float>(executionContext);
        //            int days = 7;
        //            ServiceEndDate.Set(executionContext, current.AddMonths(months).AddDays(-1));
        //            if (customerAsset.Entities.Count > 0)
        //            {

        //                traceMessage = customerAsset.Entities.Count.ToString();

        //                foreach (Entity myasset in customerAsset.Entities)
        //                {
        //                    if (myasset.Attributes.Contains("k4_productsubtype") &&
        //                       ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130000)//Subscription
        //                    {
        //                        k4_baseplancost = ((Money)myasset.Attributes["k4_extendedamount"]).Value;
        //                        if (myasset.Contains("k4_voiprate"))
        //                        {
        //                            k4_voiprate = ((Money)myasset.Attributes["k4_voiprate"]).Value;
        //                        }
        //                        k4_plan = new EntityReference(myasset.LogicalName, myasset.Id);
        //                    }
        //                    if (myasset.Attributes.Contains("k4_productsubtype") &&
        //                       ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130001)//Top Up Plan-VSAT
        //                    {
        //                        k4_associatedplancost = ((Money)myasset.Attributes["k4_extendedamount"]).Value;
        //                        if (myasset.Contains("k4_vsatoverageprice"))
        //                        {
        //                            k4_vsatoverageprice = ((Money)myasset.Attributes["k4_vsatoverageprice"]).Value;
        //                        }
        //                        k4_vsat = new EntityReference(myasset.LogicalName, myasset.Id);
        //                    }
        //                    if (myasset.Attributes.Contains("k4_productsubtype") &&
        //                       ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130003)//Top Up Plan-4G
        //                    {
        //                        k4_4gpackcost = ((Money)myasset.Attributes["k4_extendedamount"]).Value;
        //                        if (myasset.Contains("k4_4goverageprice"))
        //                        {
        //                            k4_4goverageprice = ((Money)myasset.Attributes["k4_4goverageprice"]).Value;
        //                        }
        //                        k4_4gplan = new EntityReference(myasset.LogicalName, myasset.Id);
        //                    }
        //                }
        //                traceMessage = "for each end";

        //                CreateBillingInvoice(service,
        //                       Account.Get<EntityReference>(executionContext), current,
        //                      new Money(Convert.ToDecimal("0.0")), new Money(k4_baseplancost),
        //           new Money(Convert.ToDecimal("0.0")), new Money(k4_associatedplancost),
        //           new Money(k4_4gpackcost), new Money(k4_voipfee), new Money(Convert.ToDecimal("0.0")),
        //           new Money(k4_baseplancost + k4_associatedplancost + k4_4gpackcost + k4_voipfee), 0, days,
        //            current.AddMonths(0).ToUniversalTime(), current.AddMonths(months).AddDays(-1).ToUniversalTime()
        //   , new Money(k4_4gactivationfee), new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_voiprate),
        //            new Money(k4_Arrear), new Money(k4_OldPlanAmount), new Money(k4_NewPlanAmount)
        //   , k4_plan, k4_vsat, k4_4gplan, k4_newplan, k4_newvsatplan, k4_new4gplan);

        //                //Last payment-For overage
        //                CreateBillingInvoice(service,
        //               Account.Get<EntityReference>(executionContext), current,
        //              new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
        //   new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
        //   new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
        //   new Money(Convert.ToDecimal("0.0")), months, days,
        //     current.AddMonths(months).ToUniversalTime(), current.AddMonths(months).AddDays(-1).ToUniversalTime(),
        //     new Money(Convert.ToDecimal("0.0")), new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_voiprate)
        //     , new Money(k4_Arrear), new Money(k4_OldPlanAmount), new Money(k4_NewPlanAmount)
        //     , k4_plan, k4_vsat, k4_4gplan, k4_newplan, k4_newvsatplan, k4_new4gplan);


        //            }


        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        tracingService.Trace(traceMessage);
        //        throw new InvalidPluginExecutionException("error occured in CreateMonthlyBilling workflow: " + ex.Message.ToString());
        //    }
        //}
        #endregion
    }
}
