﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;

namespace K4Mobility.Assembly.WorkflowActivities
{
   public class GetTotalOverageCost : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;


       
        [RequiredArgument]
        [Input("Amount To Pay")]
        public InArgument<decimal> AmountToPay

        {
            get;
            set;
        }
        [RequiredArgument]
        [Input("Overage Rate")]
        public InArgument<Money> OverageRate

        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("Overage Slab (GB)")]
        public InArgument<decimal> OverageSlabGB
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("Data Spent as Overage (GB)")]
        public InArgument<decimal> DataSpentasOverageGB
        {
            get;
            set;
        }
        [RequiredArgument]
        [Output("Total Overage Cost")]
        public OutArgument<Money> TotalOverageCost
        {
            get;
            set;
        }
        [RequiredArgument]
        [Output("Total Amount To pay")]
        public OutArgument<Money> TotalAmountTopay
        {
            get;
            set;
        }
       

        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            Money overageCost = new Money(Math.Ceiling(DataSpentasOverageGB.Get(executionContext) /
              OverageSlabGB.Get(executionContext)) * OverageRate.Get(executionContext).Value);
            TotalOverageCost.Set(executionContext, overageCost);
            TotalAmountTopay.Set(executionContext, new Money(AmountToPay.Get(executionContext) + overageCost.Value));
        }
        #endregion

       
    }
}
