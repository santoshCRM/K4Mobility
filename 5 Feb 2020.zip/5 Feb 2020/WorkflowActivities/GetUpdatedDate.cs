using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class GetUpdatedDate : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;
        [RequiredArgument]
        [Input("Date From")]
        public InArgument<DateTime> DateFrom
        {
            get;
            set;
        }
      
       
        [RequiredArgument]
        [Input("Months")]
        public InArgument<Int32> Months
        {
            get;
            set;
        }
        [RequiredArgument]
        [Output("NewDate")]
        public OutArgument<DateTime> NewDate
        {
            get;
            set;
        }

        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (DateFrom.Get<DateTime>(executionContext) != null&& Months.Get<float>(executionContext) > 0)
                {
                    int months = (int)Months.Get<float>(executionContext);
                    NewDate.Set(executionContext, DateFrom.Get<DateTime>(executionContext).AddMonths(months));
                    tracingService.Trace(NewDate.Get(executionContext).ToString());
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreateMonthlyBilling workflow: " + ex.Message.ToString());
            }
        }
        #endregion
       
    }
}
