﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.IO;
using System.Net;
using System.Text;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class OnAddingRepresentative : CodeActivity
    {
        #region variable used
        [Input("EmployeeId")]
        [RequiredArgument]
        [ReferenceTarget("k4_employee")]
        public InArgument<EntityReference> Employee { get; set; }

        [Input("Emailaddress")]
        [RequiredArgument]
        public InArgument<string> Emailaddress { get; set; }

        [Input("Name")]
        [RequiredArgument]
        public InArgument<string> name { get; set; }

        [Input("Category")]
        [RequiredArgument]
        public InArgument<string> Category { get; set; }

        [Input("MobileNumber")]
        [RequiredArgument]
        public InArgument<string> MobileNumber { get; set; }

        [Input("Status")]
        [RequiredArgument]
        public InArgument<string> status { get; set; }




        #endregion
        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Employee.Get<EntityReference>(executionContext) != null)
                {
                    string EmployeeId = string.Empty;
                    string EmailAddress = string.Empty;
                    string Name = string.Empty;
                    string k4_Category = string.Empty;
                    string k4_MobileNumber = string.Empty;
                    string Status = string.Empty;

                    EmployeeId = Employee.Get<EntityReference>(executionContext).Id.ToString();
                    if (Emailaddress.Get<string>(executionContext) != null && Emailaddress.Get<string>(executionContext) != string.Empty)
                        EmailAddress = Convert.ToString(Emailaddress.Get<string>(executionContext).ToString());
                    if (name.Get<string>(executionContext) != null && name.Get<string>(executionContext) != string.Empty)
                        Name = Convert.ToString(name.Get<string>(executionContext).ToString());
                    if (Category.Get<string>(executionContext) != null && Category.Get<string>(executionContext) != string.Empty)
                        k4_Category = Convert.ToString(Category.Get<string>(executionContext).ToString());
                    if (MobileNumber.Get<string>(executionContext) != null && MobileNumber.Get<string>(executionContext) != string.Empty)
                        k4_MobileNumber = Convert.ToString(MobileNumber.Get<string>(executionContext).ToString());
                    if (status.Get<string>(executionContext) != null && status.Get<string>(executionContext) != string.Empty)
                        Status = Convert.ToString(status.Get<string>(executionContext).ToString());
                    //var K4_Imo = Convert.ToString(Imo.Get<string>(executionContext).ToString(), null);

                    #region 
                    string jsondata = "";
                    string jsonResult = "";
                    ///Dev Link
                    //HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://dev.k4mobility.co/newdev/crm_emp_update");
                    ///Prod Link
                    HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://webapp.k4mobility.com:5021/api/crm_emp_update");
                    jsondata = "{ \"K4_employeeid\":\"" + EmployeeId + "\",\"k4_name\":\"" + Name + "\",\"k4_emailaddress\":\"" + EmailAddress + "\",\"k4_category\":\"" + k4_Category + "\",\"k4_mobilenumber\":\"" + k4_MobileNumber + "\",\"k4_Status\":\"" + Status + "\"}";
                    Encoding encoding = new UTF8Encoding();
                    byte[] data = encoding.GetBytes(jsondata);
                    httpWReq.ProtocolVersion = HttpVersion.Version11;
                    httpWReq.Method = "POST";
                    httpWReq.KeepAlive = true;
                    httpWReq.ContentType = "application/json";
                    httpWReq.ContentLength = data.Length;
                    Stream stream = httpWReq.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                    string s = response.ToString();
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        jsonResult = reader.ReadToEnd();
                        reader.Close();
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in OnAddingEmployee workflow: " + ex.Message.ToString());
            }
        }
        #endregion

    }
}
