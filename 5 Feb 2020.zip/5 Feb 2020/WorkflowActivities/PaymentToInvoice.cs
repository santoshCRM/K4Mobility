using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class PaymentToInvoice : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

        [RequiredArgument]
        [Input("Payment")]
        [ReferenceTarget("msdyn_payment")]
        public InArgument<EntityReference> Payment
        {
            get;
            set;
        }
		[RequiredArgument]
		[Input("Invoice")]
		[ReferenceTarget("invoice")]
		public InArgument<EntityReference> Invoice
		{
			get;
			set;
		}

      
        #endregion
        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
			{
				traceMessage = "Workflow started.";
				tracingService.Trace(traceMessage);
				if (Invoice.Get<EntityReference>(executionContext) != null && Payment.Get<EntityReference>(executionContext)!=null)
				{
                    //Get Payment details
                    EntityCollection paymentDetails = getPaymentDetails(service, Payment.Get<EntityReference>(executionContext).Id.ToString());
                    #region Create Invoice Lines
                    traceMessage += " Create Invoice Lines Strated.";
                    foreach (Entity paymentDetail in paymentDetails.Entities)
                    {
                        if (paymentDetail.Contains("Product") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["Product"])).Value != null)
                        {
                           
                            Entity Product = new Entity(((Microsoft.Xrm.Sdk.EntityReference)((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["Product"])).Value).LogicalName,
                                ((Microsoft.Xrm.Sdk.EntityReference)((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["Product"])).Value).Id);
                            if (Product != null)
                            {
                                traceMessage += "ProductId "+ Product.Id.ToString();
                                Money Amount = new Money(0.00m);
                                Entity invoicedetail = new Entity("invoicedetail");
                                if (paymentDetail.Contains("AmountToPay") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["AmountToPay"])).Value != null)
                                {
                                    Amount = ((Microsoft.Xrm.Sdk.Money)(((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["AmountToPay"])).Value));
                                }
                                if (paymentDetail.Contains("ContractLength") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["ContractLength"])).Value != null)
                                    invoicedetail.Attributes["k4_contractlength"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["ContractLength"])).Value;
                                if (paymentDetail.Contains("BaseAmount") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["BaseAmount"])).Value != null)
                                    invoicedetail.Attributes["baseamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["BaseAmount"])).Value;
                                if (paymentDetail.Contains("DeactivationDate") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["DeactivationDate"])).Value != null)
                                    invoicedetail.Attributes["k4_deactivationdate"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["DeactivationDate"])).Value;
                                if (paymentDetail.Contains("DiscountAmount") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["DiscountAmount"])).Value != null)
                                    invoicedetail.Attributes["manualdiscountamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["DiscountAmount"])).Value;
                                if (paymentDetail.Contains("TaxPercentage") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["TaxPercentage"])).Value != null)
                                    invoicedetail.Attributes["k4_taxpercentage"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["TaxPercentage"])).Value;
                                if (paymentDetail.Contains("DiscountPercentage") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["DiscountPercentage"])).Value != null)
                                    invoicedetail.Attributes["k4_discountpercentage"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["DiscountPercentage"])).Value;
                                if (paymentDetail.Contains("OnGoing") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["OnGoing"])).Value != null)
                                    invoicedetail.Attributes["k4_activated"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["OnGoing"])).Value;
                                if (paymentDetail.Contains("ActivationDate") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["ActivationDate"])).Value != null)
                                    invoicedetail.Attributes["k4_activationdate"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["ActivationDate"])).Value;
                                if (paymentDetail.Contains("TaxAmount") && ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["TaxAmount"])).Value != null)
                                    invoicedetail.Attributes["tax"] = ((Microsoft.Xrm.Sdk.AliasedValue)(paymentDetail.Attributes["TaxAmount"])).Value;
                                Entity MyProduct = service.Retrieve(Product.LogicalName,
                                    Product.Id, new ColumnSet(new string[1]
                                {
                            "defaultuomid"
                                }));

                                invoicedetail.Attributes["invoiceid"] = Invoice.Get<EntityReference>(executionContext);
                                invoicedetail.Attributes["productid"] = new EntityReference(Product.LogicalName, Product.Id);
                                invoicedetail.Attributes["quantity"] = decimal.One;
                                if (MyProduct.Attributes.Contains("defaultuomid"))
                                {
                                    invoicedetail.Attributes["uomid"] = MyProduct.Attributes["defaultuomid"];
                                    invoicedetail.Attributes["ispriceoverridden"] = true;
                                    invoicedetail.Attributes["priceperunit"] = Amount;
                                    Guid invoicedetailId = service.Create(invoicedetail);
                                }
                            }
                        }




                    }
                    #endregion
                    traceMessage += " Create Invoice Lines Ended.";
                    EntityCollection OptionalBundleProducts = getOptionalBundleProduct(service, Invoice.Get<EntityReference>(executionContext).Id.ToString());
                    traceMessage += " OptionalBundleProduct Deletion  Started.";
                    foreach (Entity OptionalBundleProduct in OptionalBundleProducts.Entities)
                    {
                        service.Delete(OptionalBundleProduct.LogicalName, OptionalBundleProduct.Id);
                    }
                    traceMessage += " OptionalBundleProduct Deletion  Ended.";
                }
			}
			catch (Exception ex)
			{
				  tracingService.Trace(traceMessage);
				throw new InvalidPluginExecutionException("error occured in CreateInvoiceLines workflow: " + ex.Message.ToString());
			}
		}
        private EntityCollection getPaymentDetails(IOrganizationService service, string payId)
        {
            string fetchQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='msdyn_paymentdetail' >" +
"    <attribute name='msdyn_paymentamount' alias='AmountToPay' />" +
"    <attribute name='msdyn_paymentdetailid' />" +
"    <attribute name='k4_contractlength' alias='ContractLength' />" +
"    <attribute name='k4_baseamount' alias='BaseAmount' />" +
"    <attribute name='k4_deactivationdate' alias='DeactivationDate' />" +
"    <attribute name='k4_discountamount' alias='DiscountAmount' />" +
"    <attribute name='k4_taxpercentage' alias='TaxPercentage' />" +
"    <attribute name='k4_discountpercentage' alias='DiscountPercentage' />" +
"    <attribute name='k4_ongoing' alias='OnGoing' />" +
"    <attribute name='k4_activationdate' alias='ActivationDate' />" +
"    <attribute name='k4_taxamount' alias='TaxAmount' />" +
"    <filter>" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"      <condition attribute='msdyn_payment' operator='eq' value='{" + payId + "}' />" +
"    </filter>" +
"    <link-entity name='msdyn_customerasset' from='msdyn_customerassetid' to='k4_customerasset' link-type='inner' alias='CustomerAssets' >" +
"      <attribute name='msdyn_product' alias='Product' />" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";




            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
        private EntityCollection getOptionalBundleProduct(IOrganizationService service, string InvoiceId)
        {
            string fetchQuery =
                "<fetch top='50' >" +
"  <entity name='invoicedetail' >" +
"    <attribute name='productid' />" +
"    <filter>" +
"      <condition attribute='producttypecode' operator='eq' value='4' />" +
"      <condition attribute='invoiceid' operator='eq' value='{" + InvoiceId + "}' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
