using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class UpdateQuoteLine : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[RequiredArgument]
		[Input("QuoteLine")]
		[ReferenceTarget("quotedetail")]
		public InArgument<EntityReference> QuoteLine
		{
			get;
			set;
		}

		
       

        

        [Input("QLTaxPercentage")]
        public InArgument<string> QLTaxPercentage
        {
            get;
            set;
        }
      
        [Input("QLDicountPercentage")]
        public InArgument<string> QLDicountPercentage
        {
            get;
            set;
        }
        [RequiredArgument]
		[Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}
        #endregion
        #region Execute  function

        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (QuoteLine.Get<EntityReference>(executionContext) != null)
                {
                    Entity MyQuoteLine = new Entity(QuoteLine.Get<EntityReference>(executionContext).LogicalName,
                        QuoteLine.Get<EntityReference>(executionContext).Id);
                    decimal numD = Convert.ToDecimal("0.00");
                    decimal numT = Convert.ToDecimal("0.00");
                    MyQuoteLine.Attributes["manualdiscountamount"] = new Money(numD);
                    MyQuoteLine.Attributes["tax"] = new Money(numT);
                    if (Amount.Get<Money>(executionContext) != null)
                    {
                        traceMessage += "/n1";
                        if (QLDicountPercentage.Get<string>(executionContext) != null)
                        {
                            numD = Convert.ToDecimal(QLDicountPercentage.Get<string>(executionContext));
                            traceMessage += "/n2";
                        }
                        traceMessage += numD.ToString();
                        decimal num1 = Amount.Get<Money>(executionContext).Value * numD / 100m;
                        MyQuoteLine.Attributes["manualdiscountamount"] = new Money(num1);
                        //Tax
                        if (QLTaxPercentage.Get<string>(executionContext) != null)
                        {
                            traceMessage += "/n4";
                            numT = Convert.ToDecimal(QLTaxPercentage.Get<string>(executionContext));
                        }

                        traceMessage += numT.ToString();
                        decimal num2 = (Amount.Get<Money>(executionContext).Value - num1) * numT / 100m;
                        MyQuoteLine.Attributes["tax"] = new Money(num2);
                    }
                    service.Update(MyQuoteLine);
                }
            }
			
			catch (Exception ex)
			{
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in UpdateOpportunityLine workflow: " + ex.Message.ToString());
			}
		}
        #endregion
    }
}
