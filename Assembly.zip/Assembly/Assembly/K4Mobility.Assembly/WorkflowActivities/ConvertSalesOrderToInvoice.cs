﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class ConvertSalesOrderToInvoice : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("SalesOrder")]
        [ReferenceTarget("salesorder")]
        public InArgument<EntityReference> SalesOrder { get; set; }

        [RequiredArgument]
        [Output("Invoice")]
        [ReferenceTarget("invoice")]
        public OutArgument<EntityReference> Invoice { get; set; }
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (SalesOrder.Get<EntityReference>(executionContext) != null)
                {
                    #region Convert SalesOrder to Invoice

                    // Convert the order to an invoice
                    ConvertSalesOrderToInvoiceRequest convertOrderRequest =
                        new ConvertSalesOrderToInvoiceRequest()
                        {
                            SalesOrderId = SalesOrder.Get(executionContext).Id,
                        };
                    ConvertSalesOrderToInvoiceResponse convertOrderResponse =
                        (ConvertSalesOrderToInvoiceResponse)service.Execute(convertOrderRequest);
                    #endregion
                    Invoice.Set(executionContext, new EntityReference(convertOrderResponse.Entity.LogicalName,
                         convertOrderResponse.Entity.Id));
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in ConvertSalesOrderToInvoice workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
