﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Linq;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreateOrderVendorLines : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("SalesOrder")]
        [ReferenceTarget("salesorder")]
        public InArgument<EntityReference> SalesOrder { get; set; }

       
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (SalesOrder.Get<EntityReference>(executionContext) != null)
                {

                    string fetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='salesorderdetail' >" +
"    <attribute name='salesorderdetailid' />" +
"    <order attribute='productid' descending='false' />" +
"    <filter type='and' >" +
"      <condition attribute='salesorderid' operator='eq' value='{" + SalesOrder.Get(executionContext).Id + "}' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='MyProduct' >" +
"      <attribute name='msdyn_defaultvendor' />" +
"      <filter type='and' >" +
"        <condition attribute='k4_productsubtype' operator='null' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";

                    EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetch));
                    var details = from r in result.Entities.AsEnumerable()
                                  group r by new
                                  {
                                      msdyn_defaultvendor = (((Microsoft.Xrm.Sdk.EntityReference)
                                      ((Microsoft.Xrm.Sdk.AliasedValue)r.Attributes["MyProduct.msdyn_defaultvendor"]).Value).Id)
                                  }
                                  into g
                                  select new
                                  {
                                      VendorId = g.Key.msdyn_defaultvendor
                                  };
                    foreach (var detail in details)
                    {
                        Entity k4_ordervendormapping = new Entity("k4_ordervendormapping");
                        k4_ordervendormapping.Attributes["k4_name"] = detail.VendorId.ToString();
                        k4_ordervendormapping.Attributes["k4_order"] = new EntityReference("salesorder",
                            SalesOrder.Get(executionContext).Id);
                        k4_ordervendormapping.Attributes["k4_vendor"] = new EntityReference("account",
                         detail.VendorId);
                        Guid k4_ordervendormappingId = service.Create(k4_ordervendormapping);
                        var res = result.Entities.Where(e => (((Microsoft.Xrm.Sdk.EntityReference)
                                      ((Microsoft.Xrm.Sdk.AliasedValue)e.Attributes["MyProduct.msdyn_defaultvendor"]).Value).Id) == detail.VendorId);
                        foreach (var ent in res)
                        {
                            Entity salesorderdetail = new Entity("salesorderdetail", ent.Id);
                            salesorderdetail.Attributes["k4_ordervendormapping"] = new EntityReference("k4_ordervendormapping", k4_ordervendormappingId);
                            service.Update(salesorderdetail);
                        }

                    }


                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in ConvertSalesOrderToInvoice workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
