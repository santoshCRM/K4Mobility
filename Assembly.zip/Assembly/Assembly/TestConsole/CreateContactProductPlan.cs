﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class CreateContactProductPlan
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference order = new EntityReference("salesorder", new Guid("13B6DB1E-8663-E911-A95D-000D3AF2C610"));
            EntityReference Contact = new EntityReference("contact", new Guid("B187FFA8-A161-E911-A95A-000D3AF2CECB"));
            #endregion


            #region Create subscription
            string fetchSubscrption = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"  <entity name='salesorderdetail'>" +
"    <attribute name='productid' />" +
"    <attribute name='extendedamount' />" +
"    <order attribute='productid' descending='false' />" +
"    <filter type='and'>" +
"      <condition attribute='salesorderid' operator='eq' value='{" + order.Id + "}' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ab'>" +
"    <attribute name='k4_productsubtype' />" +
//"      <filter type='and'>" +
//"        <condition attribute='k4_productsubtype' operator='eq' value='636130000' />" +
//"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            EntityCollection orderLines = service.RetrieveMultiple(new FetchExpression(fetchSubscrption));
            foreach (Entity orderline in orderLines.Entities)
            {
                Entity contactproductline = new Entity("k4_contactproductline");
                contactproductline.Attributes["k4_contact"] = Contact;
                if (orderline.Attributes.Contains("productid"))
                {
                    contactproductline.Attributes["k4_name"] = ((EntityReference)orderline.Attributes["productid"]).Name;
                    contactproductline.Attributes["k4_product"] = ((EntityReference)orderline.Attributes["productid"]);
                }
                if (orderline.Attributes.Contains("ab.k4_productsubtype"))
                    contactproductline.Attributes["k4_productsubtype"] =((Microsoft.Xrm.Sdk.OptionSetValue)((Microsoft.Xrm.Sdk.AliasedValue)contactproductline.Attributes["ab.k4_productsubtype"]).Value).Value;
                        // new OptionSetValue(636130000);
                if (orderline.Attributes.Contains("extendedamount"))
                    contactproductline.Attributes["k4_amount"] = (Money)orderline.Attributes["extendedamount"];


                service.Create(contactproductline);
            }
            #endregion
            //Create Add-on Product
//            #region Create Add on
//            string fetchAddOn = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
//"  <entity name='salesorderdetail'>" +
//"    <attribute name='productid' />" +
//"    <attribute name='extendedamount' />" +
//"    <order attribute='productid' descending='false' />" +
//"    <filter type='and'>" +
//"      <condition attribute='salesorderid' operator='eq' value='{" + order.Id + "}' />" +
//"    </filter>" +
//"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ab'>" +
//"      <filter type='and'>" +
//"        <condition attribute='k4_productsubtype' operator='eq' value='636130001' />" +
//"      </filter>" +
//"    </link-entity>" +
//"  </entity>" +
//"</fetch>";
//            EntityCollection orderAddon = service.RetrieveMultiple(new FetchExpression(fetchAddOn));
//            foreach (Entity orderline in orderAddon.Entities)
//            {
//                Entity contactproductline = new Entity("k4_contactproductline");
//                contactproductline.Attributes["k4_contact"] = Contact;
//                if (orderline.Attributes.Contains("productid"))
//                {
//                    contactproductline.Attributes["k4_name"] = ((EntityReference)orderline.Attributes["productid"]).Name;
//                    contactproductline.Attributes["k4_product"] = ((EntityReference)orderline.Attributes["productid"]);
//                }
//                if (orderline.Attributes.Contains("productid"))
//                    contactproductline.Attributes["k4_productsubtype"] = new OptionSetValue(636130001);
//                if (orderline.Attributes.Contains("extendedamount"))
//                    contactproductline.Attributes["k4_amount"] = (Money)orderline.Attributes["extendedamount"];


//                service.Create(contactproductline);
//            }
//            #endregion

        }

    }
}
