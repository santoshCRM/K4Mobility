﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreateContactProductPlan : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Contact")]
        [ReferenceTarget("contact")]
        public InArgument<EntityReference> Contact { get; set; }
        [RequiredArgument]
        [Input("Order")]
        [ReferenceTarget("salesorder")]
        public InArgument<EntityReference> Order { get; set; }

        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Contact.Get<EntityReference>(executionContext) != null && Order.Get<EntityReference>(executionContext) != null)
                {
                    EntityReference ContactEntity = Contact.Get<EntityReference>(executionContext);
                    EntityReference OrderEntity = Order.Get<EntityReference>(executionContext);
                    
                    #region Contact Product Lines
                    string fetchOrderLines = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"  <entity name='salesorderdetail'>" +
"    <attribute name='productid' />" +
"    <attribute name='extendedamount' />" +
"    <attribute name='quantity' />" +

"    <filter type='and'>" +
"      <condition attribute='salesorderid' operator='eq' value='{" + OrderEntity.Id + "}' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ab'>" +
"    <attribute name='k4_productsubtype' />" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
                    traceMessage += "\n Fetching  Order Lines.";
                    EntityCollection orderLines = service.RetrieveMultiple(new FetchExpression(fetchOrderLines));
                    foreach (Entity orderline in orderLines.Entities)
                    {
                        if (orderline.Attributes.Contains("quantity"))
                        {
                            decimal Quantity = (decimal)orderline.Attributes["quantity"];
                            for (int x = 0; x < Quantity; x++)
                            {
                                traceMessage += "\n creating Contact order line.";
                                Entity contactproductline = new Entity("k4_contactproductline");
                                contactproductline.Attributes["k4_contact"] = Contact.Get<EntityReference>(executionContext);
                                if (orderline.Attributes.Contains("productid"))
                                {
                                    contactproductline.Attributes["k4_name"] = ((EntityReference)orderline.Attributes["productid"]).Name;
                                    contactproductline.Attributes["k4_product"] = ((EntityReference)orderline.Attributes["productid"]);
                                }
                                if (orderline.Attributes.Contains("ab.k4_productsubtype"))
                                    contactproductline.Attributes["k4_productsubtype"] = new OptionSetValue(((Microsoft.Xrm.Sdk.OptionSetValue)((Microsoft.Xrm.Sdk.AliasedValue)orderline.Attributes["ab.k4_productsubtype"]).Value).Value);
                                if (orderline.Attributes.Contains("extendedamount"))
                                    contactproductline.Attributes["k4_amount"] = (Money)orderline.Attributes["extendedamount"];
                                service.Create(contactproductline);
                            }
                        }
                            
                    }
                    #endregion
                   
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("error occured in CreatePayments workflow: " + traceMessage+ ex.Message.ToString());
            }

        }
        #endregion
    }
}
