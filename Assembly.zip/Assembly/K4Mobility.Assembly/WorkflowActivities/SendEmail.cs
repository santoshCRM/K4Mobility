﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class SendEmail : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Email")]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> Email { get; set; }
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";

                if (Email.Get<EntityReference>(executionContext) != null)
                {
                    SendEmailRequest request = new SendEmailRequest();
                    request.EmailId = Email.Get<EntityReference>(executionContext).Id;
                    request.TrackingToken = "";
                    request.IssueSend = true;
                    SendEmailResponse response = (SendEmailResponse)service.Execute(request);
                }

                else
                    traceMessage += " No Record found to update.";

            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in SendEmail workflow: " + ex.Message.ToString());
            }

        }




        #endregion
    }
}
