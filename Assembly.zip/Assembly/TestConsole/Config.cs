﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class Config
    {
        OrganizationServiceProxy serviceproxy = null;
        public string OrganizationUrl = "https://k4mobilityltdsb.api.crm8.dynamics.com/XRMServices/2011/Organization.svc";
        public ClientCredentials Credentials = null;
        public void CreateConnection()
        {
            Credentials = new ClientCredentials();
            Credentials.UserName.UserName = "admin@k4mobilityltd.onmicrosoft.com";
            Credentials.UserName.Password = "K4Mobility@123";
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                serviceproxy = new OrganizationServiceProxy(new Uri(OrganizationUrl), null, Credentials, null);
                Guid orgId = ((WhoAmIResponse)serviceproxy.Execute(new WhoAmIRequest())).OrganizationId;
                Console.Write("connection success !!");
                // CreatePayment cPayment = new CreatePayment();
                //cPayment.Execute(serviceproxy);
                //  StatusChangePayments updatePayment = new StatusChangePayments();
                //updatePayment.Execute(serviceproxy);
                //CreateContactProductPlan CreateContactProductPlan = new CreateContactProductPlan();
                //CreateContactProductPlan.Execute(serviceproxy);
                // CreateOppLine opline = new CreateOppLine();
                //opline.Execute(serviceproxy);
                SendEmail SendEmail = new SendEmail();
                SendEmail.Execute(serviceproxy);

            }
            catch (Exception ex)
            { }
        }


     

    }
}
