﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class CreateOppLine
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference ProductRef = new EntityReference("product", new Guid("8382041F-7450-E911-A95D-000D3AF2C9D4"));
            Entity Product = service.Retrieve("product", new Guid("8382041F-7450-E911-A95D-000D3AF2C9D4"), new ColumnSet("defaultuomid"));
            EntityReference Opportunity = new EntityReference("opportunity", new Guid("01BEC204-3D55-E911-A95B-000D3AF2C610"));
            #endregion

            if (ProductRef != null && Opportunity != null)
            {
                try
                {
                    Entity opportunityproduct = new Entity("opportunityproduct");
                    opportunityproduct.Attributes["opportunityid"] = Opportunity;
                    opportunityproduct.Attributes["productid"] = ProductRef;
                    opportunityproduct.Attributes["quantity"] = (decimal)1;
                    if (Product.Attributes.Contains("defaultuomid"))
                    {
                        opportunityproduct.Attributes["uomid"] = Product.Attributes["defaultuomid"];
                        service.Create(opportunityproduct);
                    }
                }
                catch (Exception ex)
                {

                }
            }
        }

    }
}
