﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
   public class SendEmail
    {
        public void Execute(IOrganizationService service)
        {
            try
            {

                SendEmailRequest request = new SendEmailRequest();
                request.EmailId = new Guid("cc5ee1ba-6b5b-e911-a959-000d3af2cecb");
                request.TrackingToken = "";
                request.IssueSend = true;
                SendEmailResponse response = (SendEmailResponse)service.Execute(request);

                //Entity email = new Entity("email", new Guid("cc5ee1ba-6b5b-e911-a959-000d3af2cecb"));
                //email.Attributes["statecode"] = 1;
                //email.Attributes["statuscode"] = 6;
                //email.Attributes["deliveryattempts"] = 0;
                //service.Update(email);
            }
            catch(Exception ex)
            {


            }
        }
    }
}
