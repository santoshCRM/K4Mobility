﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
   public class StatusChangePayments
    {
        public void Execute(IOrganizationService service)
        {

            EntityReference Contact = new EntityReference("contact",new Guid("1C93E195-BB4E-E911-A95B-000D3AF266C5"));
            bool Activate=false;
            QueryExpression qe = new QueryExpression();
            qe.EntityName = "k4_paymentinformation";
            qe.ColumnSet = new ColumnSet();
            qe.ColumnSet.Columns.Add("k4_paymentinformationid");
            bool changeType = true;
            if (Activate)//Start Service-Activate:True
            {
                qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1);//Get InActive record
                qe.Criteria.AddCondition("k4_contact", ConditionOperator.Equal, Contact.Id);
                qe.Criteria.AddCondition("k4_paymentdate", ConditionOperator.OnOrAfter, DateTime.Now.ToString("yyyy-MM-dd"));
            }
            else//Stop Service-Activate:False
            {
                qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);//Get Active record
                qe.Criteria.AddCondition("k4_contact", ConditionOperator.Equal, Contact.Id);
                qe.Criteria.AddCondition("k4_paymentdate", ConditionOperator.OnOrAfter, DateTime.Now.ToString("yyyy-MM-dd"));
                changeType = false;
            }
            EntityCollection Payments = service.RetrieveMultiple(qe);
            if (Payments.Entities.Count > 0)
            {
                ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                {

                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = false,
                        ReturnResponses = false
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };
                requestWithResults.Requests.Clear();
                foreach (var entity in Payments.Entities)
                {
                    SetStateRequest StateRequest = new SetStateRequest();
                    StateRequest.EntityMoniker = new EntityReference(entity.LogicalName, entity.Id);
                    if (changeType)//Activate
                    {
                        StateRequest.State = new OptionSetValue(0);
                        StateRequest.Status = new OptionSetValue(1);
                    }
                    else//Deactivate
                    {
                        StateRequest.State = new OptionSetValue(1);
                        StateRequest.Status = new OptionSetValue(2);
                    }
                    requestWithResults.Requests.Add(StateRequest);
                }
                ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);
            }

        }
    }
}
