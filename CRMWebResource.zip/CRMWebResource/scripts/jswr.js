﻿function GetTeam()
{
    savSDKCollection.callGetUserTeamRequest();


}

var savSDKCollection = {
    _getServerUrl: function () {
        var e = "/XRMServices/2011/Organization.svc/web";
        var t = "";
        if (typeof GetGlobalContext == "function") {
            var n = GetGlobalContext();
            t = n.getClientUrl()
        } else {
            if (typeof Xrm.Page.context == "object") {
                t = Xrm.Page.context.getClientUrl()
            }
            else {
                throw new Error("Unable to access the server URL")
            }
        }
        if (t.match(/\/$/)) {
            t = t.substring(0, t.length - 1)
        }
        return t + e
    },
    callGetUserTeamRequest: function () {

        var UserID = Xrm.Page.context.getUserId();
        UserID = UserID.substring(1, UserID.length - 1);

        var i = "<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>" +
"  <s:Body>" +
"    <Execute xmlns='http://schemas.microsoft.com/xrm/2011/Contracts/Services' xmlns:i='http://www.w3.org/2001/XMLSchema-instance'>" +
"      <request xmlns:a='http://schemas.microsoft.com/xrm/2011/Contracts'>" +
"        <a:Parameters xmlns:b='http://schemas.datacontract.org/2004/07/System.Collections.Generic'>" +
"          <a:KeyValuePairOfstringanyType>" +
"            <b:key>User</b:key>" +
"            <b:value i:type='a:EntityReference'>" +
"              <a:Id>"+UserID+"</a:Id>" +
"              <a:KeyAttributes xmlns:c='http://schemas.microsoft.com/xrm/7.1/Contracts' />" +
"              <a:LogicalName>systemuser</a:LogicalName>" +
"              <a:Name i:nil='true' />" +
"              <a:RowVersion i:nil='true' />" +
"            </b:value>" +
"          </a:KeyValuePairOfstringanyType>" +
"        </a:Parameters>" +
"        <a:RequestId i:nil='true' />" +
"        <a:RequestName>sav_GetUserTeam</a:RequestName>" +
"      </request>" +
"    </Execute>" +
"  </s:Body>" +
"</s:Envelope>";

        var errorHandler;
        var s = new XMLHttpRequest;
        var errorHandler;
        s.open("POST", savSDKCollection._getServerUrl(), true);
        s.setRequestHeader("Accept", "application/xml, text/xml, */*");
        s.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
        s.setRequestHeader("SOAPAction", "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute");
        s.onreadystatechange = function () {
            savSDKCollection.SetStateResponse(s, null, errorHandler)
        };
        s.send(i)
    },
    callGetUserTeamRequestJson: function () {

        var UserID = Xrm.Page.context.getUserId();
        UserID = UserID.substring(1, UserID.length - 1);
        var parameters = {
            "User": {
                "LogicalName": "systemuser",
                "Id@odata.bind": UserID
            }
        }

        var serverURL = Xrm.Page.context.getClientUrl();
        var query="sav_GetUserTeam";
        var req = new XMLHttpRequest()
        req.open("POST", serverURL + "/api/data/v8.2/"+query, true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"OData.Community.Display.V1.FormattedValue\"");
        req.onreadystatechange = function () {
            savSDKCollection.SetStateResponse(s, null, errorHandler)
        };
        req.send(window.JSON.stringify(parameters));
    },
    SetStateResponse: function (e, t, n) {
        if (e.readyState == 4) {
            if (e.status == 200) {
                {
                    //debugger;
                    var xmlDoc;
                    if (window.DOMParser) {
                        parser = new DOMParser();
                        xmlDoc = parser.parseFromString(e.responseText, "text/xml");

                    }
                    else // Internet Explorer
                    {
                        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                        xmlDoc.async = false;
                        xmlDoc.loadXML(e.responseText);
                    }

                    x = xmlDoc.getElementsByTagName("a:Entity");
                    for (var i = 0; i < x.length; i++) {
                        var TeamName = x[i].childNodes[0].firstChild.lastChild.lastChild.nodeValue;
                        var TeamId = x[i].childNodes[3].firstChild.nodeValue;
                        console.log("Team: " + TeamName + " and TeamId: " + TeamId);
                    }
                    //do your action
                    
                }

                if (t != null) { t() }
            }
            else {
                savSDKCollection._getError(e.responseXML)
            }
        }
    },
    _getError: function (e) {

        var t = "Unknown Error (Unable to parse the fault)"; if (typeof e == "object") {
            try {
                var n = e.firstChild.firstChild; for (var r = 0; r < n.childNodes.length; r++) {
                    var i = n.childNodes[r]; if ("s:Fault" == i.nodeName) {
                        for (var s = 0; s < i.childNodes.length; s++) {
                            var o = i.childNodes[s];
                            if ("faultstring" == o.nodeName) {

                            }
                            if ("faultstring" == o.nodeName
                    ) {
                                t = o.text + " textContent:=" + n.textContent;
                                alert(o.firstChild.data);
                                break;
                            }
                        } break
                    }
                }
            } catch (u) { }
        } return new Error(t)
    }
}