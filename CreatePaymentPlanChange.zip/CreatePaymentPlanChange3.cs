﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class CreatePaymentPlanChange3
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference Account = new EntityReference("account", new Guid("846906FF-DFE5-E911-A812-000D3A0A8303"));
            //EntityReference Case = new EntityReference("case", new Guid("D4F4EB84-4AC0-E911-A961-000D3AF2CB54"));
            DateTime ServiceStartDate = new DateTime(2019, 10, 3);
            DateTime ActivationDate = new DateTime(2019, 10, 3);
            DateTime BaseDate = new DateTime(ActivationDate.AddMonths(1).Year, ActivationDate.AddMonths(1).Month, ServiceStartDate.Day);// ActivationDate.ToUniversalTime().AddHours(5.5d);
            float PlanDuration = 3;

            Decimal OldVsatCost = 10449.05m;
            Decimal Old4GCost = 949.05m;

            Decimal NewVsatCost = 0;//4,502.32
            Decimal New4GCost = 0;

            //Get customer asset from account
            EntityCollection CusAsset = getAccAsset(service, Account.Id.ToString());
            if (CusAsset.Entities.Count > 0)
            {
                foreach (var entity in CusAsset.Entities)
                {
                    if (entity.Contains("Product.k4_productsubtype") &&
                  ((OptionSetValue)((Microsoft.Xrm.Sdk.AliasedValue)(entity.Attributes["Product.k4_productsubtype"])).Value).Value == 636130000)//Subscription
                    {

                    }
                    if (entity.Contains("Product.k4_productsubtype") &&
               ((OptionSetValue)((Microsoft.Xrm.Sdk.AliasedValue)(entity.Attributes["Product.k4_productsubtype"])).Value).Value == 636130001)//Top Up Plan-VSAT
                    {
                        NewVsatCost = ((Microsoft.Xrm.Sdk.Money)(entity.Attributes["k4_extendedamount"])).Value;
                    }
                    if (entity.Contains("Product.k4_productsubtype") &&
                   ((OptionSetValue)((Microsoft.Xrm.Sdk.AliasedValue)(entity.Attributes["Product.k4_productsubtype"])).Value).Value == 636130003)//Top Up Plan-4G
                    {
                        New4GCost = ((Microsoft.Xrm.Sdk.Money)(entity.Attributes["k4_extendedamount"])).Value;
                    }
                }



            }





            decimal k4_vsatoverageprice = 0.0m;
            decimal k4_4goverageprice = 0.0m;
            decimal k4_newvsatoverageprice = 0.0m;
            decimal k4_new4goverageprice = 0.0m;
            decimal k4_voiprate = 0.0m;
            #endregion

            #region not in use
            decimal k4_baseplancost = 0.0m;
            decimal k4_voipfee = 0.0m;
            decimal k4_4gactivationfee = 0.0m;
            decimal k4_activationfee = 0.0m;
            decimal k4_installationfee = 0.0m;
            decimal k4_hardwarecost = 0.0m;
            #endregion

            decimal k4_associatedplancost = 0.0m;
            decimal k4_4gpackcost = 0.0m;
            int months = (int)PlanDuration;
            int days = 7;

            DateTime current = new DateTime(ActivationDate.AddMonths(1).Year, ActivationDate.AddMonths(1).Month, ServiceStartDate.Day);
            k4_4gpackcost = ((current.Subtract(ActivationDate).Days) * (New4GCost - Old4GCost) / (current.Subtract((current.AddMonths(-1))).Days))
                         + (New4GCost * (DateTime.DaysInMonth(current.Year, current.Month) - current.Day) / DateTime.DaysInMonth(current.Year, current.Month))
                       + ((current.AddMonths(1).Day) * Old4GCost) / ((current.AddMonths(1)).Subtract(current)).Days;
            k4_associatedplancost = ((current.Subtract(ActivationDate).Days) * (NewVsatCost - OldVsatCost) / (current.Subtract((current.AddMonths(-1))).Days))
                                 + (NewVsatCost * (DateTime.DaysInMonth(current.Year, current.Month) - current.Day) / DateTime.DaysInMonth(current.Year, current.Month))
                               + ((current.AddMonths(1).Day) * OldVsatCost) / ((current.AddMonths(1)).Subtract(current)).Days;

            CreateBillingInvoice(service,
                    Account, current,
                   new Money(k4_installationfee), new Money(k4_baseplancost),
        new Money(k4_hardwarecost), new Money(k4_associatedplancost),
        new Money(k4_4gpackcost), new Money(k4_voipfee), new Money(k4_activationfee),
        new Money(k4_installationfee + k4_baseplancost + k4_hardwarecost + k4_associatedplancost + k4_4gpackcost + k4_voipfee + k4_activationfee
        + k4_4gactivationfee), 0, days,
        current.ToUniversalTime(), current.AddMonths(1).AddDays(-1).ToUniversalTime()
        , new Money(k4_4gactivationfee),
          new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_newvsatoverageprice), new Money(k4_new4goverageprice)
          , new Money(k4_voiprate)
          );

            for (int i = 0; i < months; i++)
            {
                 current = new DateTime(ActivationDate.AddMonths(1).AddMonths(i).Year, ActivationDate.AddMonths(1).AddMonths(i).Month, ServiceStartDate.Day);
                k4_4gpackcost = New4GCost;
                k4_associatedplancost = NewVsatCost ;

                CreateBillingInvoice(service,
                        Account, current,
                       new Money(k4_installationfee), new Money(k4_baseplancost),
            new Money(k4_hardwarecost), new Money(k4_associatedplancost),
            new Money(k4_4gpackcost), new Money(k4_voipfee), new Money(k4_activationfee),
            new Money(k4_installationfee + k4_baseplancost + k4_hardwarecost + k4_associatedplancost + k4_4gpackcost + k4_voipfee + k4_activationfee
            + k4_4gactivationfee), 0, days,
            current.ToUniversalTime(), current.AddMonths( 1).AddDays(-1).ToUniversalTime()
            , new Money(k4_4gactivationfee),
              new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_newvsatoverageprice), new Money(k4_new4goverageprice)
              , new Money(k4_voiprate)
              );

            }



            //Last payment-For overage
            CreateBillingInvoice(service,
                  Account, BaseDate,
                 new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
      new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
      new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
      new Money(Convert.ToDecimal("0.0")), months, days,
        BaseDate.AddMonths(months).ToUniversalTime(), BaseDate.AddMonths(months + 1).AddDays(-1).ToUniversalTime(),
        new Money(Convert.ToDecimal("0.0")),
              new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_newvsatoverageprice), new Money(k4_new4goverageprice)
              , new Money(k4_voiprate)
              );


        }
        public void CreateBillingInvoice(IOrganizationService service, EntityReference Account, DateTime ActivationDate,
             Money k4_installationfee, Money k4_baseplancost,
             Money k4_hardwarecost, Money k4_associatedplancost,
             Money k4_4gpackcost, Money k4_voipfee, Money k4_activationfee, Money amount, int month, int days,
             DateTime k4_periodstartdate, DateTime k4_periodenddate, Money k4_4gactivationfee,
             Money k4_vsatoverageprice, Money k4_4goverageprice, Money k4_newvsatoverageprice, Money k4_new4goverageprice, Money k4_voiprate
             )
        {
            Entity msdyn_payment = new Entity("msdyn_payment");
            msdyn_payment.Attributes["msdyn_account"] = Account;
            msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
            msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + ActivationDate.AddMonths(month).ToString("dd MMMM yyyy"));
            msdyn_payment.Attributes["msdyn_date"] = ActivationDate.AddMonths(month).ToUniversalTime();
            msdyn_payment.Attributes["k4_duedateforpayment"] = ActivationDate.AddMonths(month).AddDays(days).ToUniversalTime();
            msdyn_payment.Attributes["k4_periodstartdate"] = k4_periodstartdate;
            msdyn_payment.Attributes["k4_periodenddate"] = k4_periodenddate;
            msdyn_payment.Attributes["k4_installationfee"] = k4_installationfee;
            msdyn_payment.Attributes["k4_baseplancost"] = k4_baseplancost;
            msdyn_payment.Attributes["k4_hardwarecost"] = k4_hardwarecost;
            msdyn_payment.Attributes["k4_associatedplancost"] = k4_associatedplancost;
            msdyn_payment.Attributes["k4_4gpackcost"] = k4_4gpackcost;
            msdyn_payment.Attributes["k4_voipfee"] = k4_voipfee;
            msdyn_payment.Attributes["k4_activationfee"] = k4_activationfee;//VSAT activation fee
            msdyn_payment.Attributes["k4_4gactivationfee"] = k4_4gactivationfee;
            msdyn_payment.Attributes["k4_4goveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_vsatoveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_other"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["msdyn_amount"] = amount;

            msdyn_payment.Attributes["k4_vsatoverageprice"] = k4_vsatoverageprice;
            msdyn_payment.Attributes["k4_4goverageprice"] = k4_4goverageprice;
            msdyn_payment.Attributes["k4_newvsatoverageprice"] = k4_newvsatoverageprice;
            msdyn_payment.Attributes["k4_new4goverageprice"] = k4_new4goverageprice;
            msdyn_payment.Attributes["k4_voiprate"] = k4_voiprate;
            msdyn_payment.Attributes["k4_totalvoipcharges"] = new Money(Convert.ToDecimal("0.0"));
            service.Create(msdyn_payment);
        }

        private EntityCollection getAccAsset(IOrganizationService service, string accId)
        {
            string fetchQuery =
                "<fetch top='50' >" +
"  <entity name='msdyn_customerasset' alias='Asset' >" +
"    <attribute name='k4_extendedamount' />" +
"    <filter>" +
"      <condition attribute='msdyn_account' operator='eq' value='{" + accId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
" <condition attribute='k4_extendedamount' operator='not-null' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='msdyn_product' alias='Product' >" +
"      <attribute name='k4_productsubtype' />" +
"      <filter>" +
"        <condition attribute='k4_productsubtype' operator='in' >" +
"          <value>636130000</value>" +//Subscription
"          <value>636130001</value>" +//Top Up Plan-VSAT
"          <value>636130003</value>" +//Top Up Plan-4G
"        </condition>" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";


            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }

    }
}