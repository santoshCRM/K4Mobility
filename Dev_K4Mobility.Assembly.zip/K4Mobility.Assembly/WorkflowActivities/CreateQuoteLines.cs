using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class CreateQuoteLines : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[Input("ProductRef")]
		[ReferenceTarget("product")]
		public InArgument<EntityReference> ProductRef
		{
			get;
			set;
		}

		
		[Input("ProductName")]
		public InArgument<string> ProductName
		{
			get;
			set;
		}
        [Input("ispriceoverridden")]
        public InArgument<bool> ispriceoverridden
        {
            get;
            set;
        }

        [Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("Quote")]
		[ReferenceTarget("quote")]
		public InArgument<EntityReference> Quote
		{
			get;
			set;
		}

        [Input("CustomerAsset")]
        [ReferenceTarget("msdyn_customerasset")]
        public InArgument<EntityReference> CustomerAsset
        {
            get;
            set;
        }

        [Input("quantity")]
        public InArgument<Int32> quantity
        {
            get;
            set;
        }
        [Output("quoteLine")]
        [ReferenceTarget("quotedetail")]
        public OutArgument<EntityReference> quoteLine
        {
            get;
            set;
        }
        #endregion
        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
			{
				traceMessage = "Workflow started.";
				tracingService.Trace(traceMessage);
				if (Quote.Get<EntityReference>(executionContext) != null)
				{
                    if (ProductRef.Get<EntityReference>(executionContext) != null)
                    {
                        Entity MyProduct = service.Retrieve(ProductRef.Get<EntityReference>(executionContext).LogicalName,
                            ProductRef.Get<EntityReference>(executionContext).Id, new ColumnSet(new string[4]
                        {
                            "defaultuomid","k4_discountpercentage","k4_taxpercentage","k4_productsubtype"
                        }));
                        Entity quotedetail = new Entity("quotedetail");
                        quotedetail.Attributes["quoteid"] = Quote.Get<EntityReference>(executionContext);
                        quotedetail.Attributes["productid"] = ProductRef.Get<EntityReference>(executionContext);
                        if (quantity.Get<Int32>(executionContext) != 0)
                            quotedetail.Attributes["quantity"] = Convert.ToDecimal(quantity.Get<Int32>(executionContext));
                        else
                            quotedetail.Attributes["quantity"] = decimal.One;
                        traceMessage += "\n Step 1";
                        if (MyProduct.Attributes.Contains("k4_productsubtype"))
                        {
                            quotedetail.Attributes["k4_productsubtype"] = MyProduct.Attributes["k4_productsubtype"];
                        }
                        if (MyProduct.Attributes.Contains("k4_taxpercentage"))
                        {
                            quotedetail.Attributes["k4_taxpercentage"] = MyProduct.Attributes["k4_taxpercentage"];

                        }
                        if (MyProduct.Attributes.Contains("k4_discountpercentage"))
                        {
                            quotedetail.Attributes["k4_discountpercentage"] = MyProduct.Attributes["k4_discountpercentage"];
                        }

                        if (CustomerAsset.Get<EntityReference>(executionContext) != null)
                        {

                            ColumnSet colset = new ColumnSet("k4_productsubtype", "k4_discountpercentage", "k4_discountamount",
                                "k4_taxamount",
                                "k4_taxpercentage", "k4_productvendor");
                            Entity res = service.Retrieve(CustomerAsset.Get<EntityReference>(executionContext).LogicalName,
                                   CustomerAsset.Get<EntityReference>(executionContext).Id, colset);
                            if (res.Attributes.Contains("k4_taxpercentage"))
                                quotedetail.Attributes["k4_taxpercentage"] = res.Attributes["k4_taxpercentage"];

                            if (res.Attributes.Contains("k4_productsubtype"))
                                quotedetail.Attributes["k4_productsubtype"] = res.Attributes["k4_productsubtype"];

                            if (res.Attributes.Contains("k4_discountpercentage"))
                                quotedetail.Attributes["k4_discountpercentage"] = res.Attributes["k4_discountpercentage"];

                            if (res.Attributes.Contains("k4_discountamount"))
                                quotedetail.Attributes["manualdiscountamount"] = res.Attributes["k4_discountamount"];

                            if (res.Attributes.Contains("k4_taxamount"))
                                quotedetail.Attributes["tax"] = res.Attributes["k4_taxamount"];

                            if (res.Attributes.Contains("k4_productvendor"))
                                quotedetail.Attributes["k4_productvendor"] = res.Attributes["k4_productvendor"];


                        }
                        if (MyProduct.Attributes.Contains("defaultuomid"))
                        {
                            traceMessage += "\n Primary unit found";
                            quotedetail.Attributes["uomid"] = MyProduct.Attributes["defaultuomid"];
                            if (ispriceoverridden.Get<bool>(executionContext))
                            {
                                quotedetail.Attributes["ispriceoverridden"] = true;
                                quotedetail.Attributes["priceperunit"] = Amount.Get<Money>(executionContext);

                            }
                            Guid quotedetailId = service.Create(quotedetail);
                            quoteLine.Set(executionContext, new EntityReference("quotedetail", quotedetailId));
                            traceMessage += "\n Quote detail Created";
                        }
                    }
                    else// Write I product
                    {
                        traceMessage += "\n Step 1.1";
                        Entity quotedetail = new Entity("quotedetail");
                        quotedetail.Attributes["quoteid"] = Quote.Get<EntityReference>(executionContext);
                        quotedetail.Attributes["productdescription"] = ProductName.Get<string>(executionContext);
                        quotedetail.Attributes["quantity"] = decimal.One;
                        quotedetail.Attributes["isproductoverridden"] = true;
                        quotedetail.Attributes["priceperunit"] = Amount.Get<Money>(executionContext);
                        Guid quotedetailId =service.Create(quotedetail);
                        quoteLine.Set(executionContext, new EntityReference("quotedetail", quotedetailId));
                        traceMessage += "\n Quote detail Created";
                    }
				}
			}
			catch (Exception ex)
			{
				  tracingService.Trace(traceMessage);
				throw new InvalidPluginExecutionException("error occured in CreateQuoteLines workflow: " + ex.Message.ToString());
			}
		}
	}
}
