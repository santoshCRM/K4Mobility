﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
TRUNCATE TABLE StatusMap
GO
INSERT [dbo].[StatusMap] ([Status], [WebStatus]) VALUES (N'For Sale', 0)
GO 
INSERT [dbo].[StatusMap] ([Status], [WebStatus]) VALUES (N'For Lease', 0)
GO
INSERT [dbo].[StatusMap] ([Status], [WebStatus]) VALUES (N'Leased', 3)
GO
INSERT [dbo].[StatusMap] ([Status], [WebStatus]) VALUES (N'Sold', 2)
GO
INSERT [dbo].[StatusMap] ([Status], [WebStatus]) VALUES (N'Under Offer', 1)
GO
TRUNCATE TABLE AmenityMap
GO
INSERT [dbo].[AmenityMap] ([GW_Amenity], [WebAmenity]) VALUES (N'Bike Storage', N'BIP')
GO
INSERT [dbo].[AmenityMap] ([GW_Amenity], [WebAmenity]) VALUES (N'Bikerack', N'BIP')
GO
INSERT [dbo].[AmenityMap] ([GW_Amenity], [WebAmenity]) VALUES (N'Parking', N'Par')
GO
INSERT [dbo].[AmenityMap] ([GW_Amenity], [WebAmenity]) VALUES (N'Concierge', N'Rec')
GO
TRUNCATE TABLE PropertyTypeMap
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Car Park', NULL)
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Development', N'D')
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Health & Care', N'H')
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Hotels & Leisure', N'Ho')
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Industrial', N'I')
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Infrastructure', NULL)
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Land', N'D')
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Miscellaneous', NULL)
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Office', N'O')
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Residential', NULL)
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Retail', N'R')
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Rural', NULL)
GO
INSERT [dbo].[PropertyTypeMap] ([GatewayPropertyType], [WebsitePropertyType]) VALUES (N'Vacant Land', N'D')
GO
TRUNCATE TABLE DocumentTypeMap
GO
INSERT INTO DocumentTypeMap (DocumentType, WebDocumentType, WebFileNameInitial) VALUES ('Brochure', 3, 'B')
GO
TRUNCATE TABLE LogfileURLs
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', 'LastReceived', N'/monitoring/lastfeedreceivedstg.html', N'html')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'SuccessFolder', N'/monitoring/successfulstg.html', N'html')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'FailedFolder', N'/monitoring/failedstg.html', N'html')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'FileMonitor', N'/monitoring/stg-logs/fileMonitor.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'Supervisor', N'/monitoring/stg-logs/supervisor.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'PackageProcessor', N'/monitoring/stg-logs/packageProcessor.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'AssetProcessor', N'/monitoring/stg-logs/assetsProc.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'DatabaseImporter', N'/monitoring/stg-logs/databaseImporter.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'FileTransfer', N'/monitoring/stg-logs/fileTransfer.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'FeedError', N'/monitoring/stg-logs/feed.error.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'IndexerDebug', N'/monitoring/stg-logs/indexer.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Staging', N'ElasticDebug', N'/monitoring/stg-logs/elastic.debug.log', N'log')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Live', 'LastReceived', N'/monitoring/lastfeedreceived.html', N'html')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Live', N'SuccessFolder', N'/monitoring/successful.html', N'html')
GO
INSERT INTO LogFileUrls (Environment, LogType, LogfileURL, LogFileType) VALUES( N'Live', N'FailedFolder', N'/monitoring/failed.html', N'html')
GO
TRUNCATE TABLE FieldNameMap
GO
INSERT INTO FieldNameMap (FieldName, NewFieldName) VALUES ('SaleType', 'Sale Type')
GO
INSERT INTO FieldNameMap (FieldName, NewFieldName) VALUES ('LeaseType', 'Lease Type')
GO
INSERT INTO FieldNameMap (FieldName, NewFieldName) VALUES ('LastRefurbished', 'Last Refurbished')
GO
INSERT INTO FieldNameMap (FieldName, NewFieldName) VALUES ('YearBuilt', 'Year Built')
GO


IF NOT EXISTS (SELECT name FROM [sys].[database_principals] WHERE name = N'FPDSAVILLS\SSISProcHOSQL5')
BEGIN
    CREATE USER [FPDSAVILLS\SSISProcHOSQL5] FOR LOGIN[FPDSAVILLS\SSISProcHOSQL5] WITH DEFAULT_SCHEMA=[dbo]
END
GO
IF NOT EXISTS (SELECT name FROM [sys].[database_principals] WHERE name = N'db_execproc')
BEGIN
    CREATE ROLE db_execproc;
	GRANT EXECUTE ON SCHEMA::dbo TO db_execproc;	
END
GO
EXEC sp_addrolemember N'db_datareader', N'FPDSAVILLS\SSISProcHOSQL5'
GO
EXEC sp_addrolemember N'db_datawriter', N'FPDSAVILLS\SSISProcHOSQL5'
GO
EXEC sp_addrolemember N'db_execproc', N'FPDSAVILLS\SSISProcHOSQL5'
GO

