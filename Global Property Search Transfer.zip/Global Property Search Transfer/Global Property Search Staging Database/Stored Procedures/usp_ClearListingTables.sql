﻿CREATE PROCEDURE [dbo].[usp_ClearListingTables]
AS
BEGIN
	SET NOCOUNT ON;
	TRUNCATE TABLE ListingImages
	TRUNCATE TABLE ListingFloorplans
	TRUNCATE TABLE ListingDocuments
	TRUNCATE TABLE Bullets
	TRUNCATE TABLE AvailablePropertyLease
	TRUNCATE TABLE AvailablePropertySale
	TRUNCATE TABLE PropertyMarketing
	
END
