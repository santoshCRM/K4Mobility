﻿CREATE PROCEDURE [dbo].[usp_EmailNewListingsToMarketing] AS
BEGIN
	SET NOCOUNT ON
	DECLARE @Body NVarchar(2000),
            @query NVARCHAR(1000)
	CREATE TABLE ##ListingTable  (URLPath NVARCHAR(50), PropertyAddress NVARCHAR(100), DateAdded DATETIME)

	INSERT INTO ##ListingTable (URLPath, PropertyAddress, DateAdded)
	SELECT 'https://search.savills.com.au/' + L.ListingNumber, P.Address_1  + ' , ' + P.DivisionCode, DateAdded 
					 from dbo.PropertyLog L 
					      inner join PropertyMarketing p on L.ListingNumber = P.ListingNumber where L.DateAdded > (GetDate() - 7) 	
	SELECT @query = 'SELECT URLPath, PropertyAddress FROM ##ListingTable ORDER BY DateAdded Desc'
	EXEC msdb.dbo.sp_send_dbmail @profile_name = 'AdminSQL', @recipients = 'marketing@savills.com.au', @subject = 'Website listings for the past 7 days.', @query = @query
	DROP TABLE ##ListingTable
END

