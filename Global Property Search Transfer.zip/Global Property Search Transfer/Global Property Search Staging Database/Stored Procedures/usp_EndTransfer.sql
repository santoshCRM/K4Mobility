﻿CREATE PROCEDURE [dbo].[usp_EndTransfer] @TransferId INT
AS
BEGIN
	EXEC usp_TransferLog @TransferId = @TransferId, @LogType = 'End Transfer'
	UPDATE Transfers SET DateEnded = GETDATE(), DateEndedUTC = GETUTCDATE() WHERE Id = @TransferId
END
