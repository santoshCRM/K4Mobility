﻿CREATE PROCEDURE [dbo].[usp_GetAgentImages] AS
BEGIN
	SET NOCOUNT ON;
	SELECT	DISTINCT A.ImageId, A.AgentImageFileName, CONVERT(NVARCHAR(10), N'180') AS  Height, CONVERT(NVARCHAR(10), N'180') AS Width, CONVERT(NVARCHAR(100), N'StaffImage.ashx') as RelativePath
	FROM	vw_Agents A  
			INNER JOIN vw_PropertyMarketing L ON L.Agent1ID = A.AgentID OR L.Agent2ID = A.AgentID
			INNER JOIN vw_Offices O ON O.OfficeID = L.OfficeID
	ORDER BY 2, 1
END

