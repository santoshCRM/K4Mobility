﻿CREATE PROCEDURE [dbo].[usp_GetAgents]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT	DISTINCT A.AgentID + O.DivisionCode AS AgentID, O.OfficeId, NULL AS DepartmentPhoneNumber,  A.EmailAddress, A.AgentName,  A.AgentPhoneNumber, 	A.LicenceNumber, A.LicenseType,	A.AgentImageFileName, 
				A.AgentImageFileType, A.AgentImageAssetType, A.ImageId
	FROM	vw_Agents A  
			INNER JOIN vw_PropertyMarketing L ON L.Agent1ID = A.AgentID OR L.Agent2ID = A.AgentID
			INNER JOIN vw_Offices O ON O.OfficeID = L.OfficeID
	ORDER BY 2, 1
END
