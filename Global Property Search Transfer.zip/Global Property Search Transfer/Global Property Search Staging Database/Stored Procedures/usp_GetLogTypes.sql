﻿CREATE PROCEDURE [dbo].[usp_GetLogTypes] @Environment NVARCHAR(20) AS
BEGIN
	SET NOCOUNT ON;
	SELECT LogType, LogFileURL, LogFileType FROM LogFileUrls WHERE Environment = @Environment
END
