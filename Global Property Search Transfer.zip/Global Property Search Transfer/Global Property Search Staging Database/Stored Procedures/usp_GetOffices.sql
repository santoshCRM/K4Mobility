﻿CREATE PROCEDURE [dbo].[usp_GetOffices] AS
BEGIN
	SET NOCOUNT ON;
	SELECT	DISTINCT O.OfficeID as OfficeID, O.OfficeName, O.OfficePhoneNumber, O.OfficeEmail as OfficeEmail, O.OfficeUrl, O.LicenceNumber,  
			O.LicenceType, O.Address1, O.Address2, O.Address3, O.CityTown, O.PostCode as PostCode, O.Country, O.Region, O.Latitude, O.Longitude
	FROM vw_Offices O INNER JOIN vw_OfficeFilter L ON L.OfficeID = O.OfficeID 
	ORDER BY 1
END
