﻿CREATE PROCEDURE [dbo].[usp_GetPropertyAmenities] (@ListingNumber NVARCHAR(20) = 'FULL')

AS
BEGIN
	SELECT PropertyID, Amenity 
	FROM vw_PropertyMarketingAmenities L
	WHERE (@ListingNumber= 'FULL' OR L.ListingNumber = @ListingNumber)
END
