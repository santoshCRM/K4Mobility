﻿CREATE PROCEDURE [dbo].[usp_GetPropertyAssets] (@ListingNumber NVARCHAR(20) = 'FULL')

AS
BEGIN
	SELECT PropertyId, AssetType, FileName, Caption, Order_, FileURL, SourceSite
	FROM vw_PropertyMarketingAssets L
	WHERE (@ListingNumber= 'FULL' OR L.ListingNumber = @ListingNumber)
	ORDER BY PropertyId, Order_
END
