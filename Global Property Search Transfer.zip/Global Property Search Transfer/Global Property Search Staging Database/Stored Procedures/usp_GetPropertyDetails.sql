﻿CREATE PROCEDURE [dbo].[usp_GetPropertyDetails] (@ListingNumber NVARCHAR(20) = 'FULL')

AS
BEGIN
	SELECT	L.PropertyID, L.PreviousPropertyID, L.ParentPropertyID, L.OfficeID, L.Agent1ID + L.DivisionCode AS Agent1ID, L.Agent2ID + L.DivisionCode AS Agent2ID,  L.Action,  L.PropertyCreateDate, L.PropertyModifyDate, 
			L.Latitude as Latitude, L.Longitude as Longitude, L.AddressLine1, L.AddressLine2, L.BuildingName, L.PropertyTitle, L.AvailableUnit, L.EnergyText, L.Description, L.Location, L.LongDescription, l.AreaGuide, L.QuoteText, L.QuoteContact, 
			L.Tenure, L.Flag, L.BaseCurrency, L.GuidePriceText, L.PriceUpperBound, L.Price, L.PriceDisclaimer, L.BuyOrRent, L.RentUnit, L.RentBasis, L.Yield, L.NumberOfPeople, L.BuildingAge, L.OfficeGrade, L.Bedrooms, L.PropertyStatus, 
			L.VideoUrl, CASE WHEN L.VideoUrl IS NULL THEN NULL ELSE 'Video' END AS VideoUrlCaption,	L.ExternalUrl, CASE WHEN L.ExternalUrl IS NULL THEN NULL ELSE 'Website' END AS ExternalUrlCaption, 
			L.Video360, L.ShowFacebook,  L.IsConfidential, L.IsHidden, L.SizeMin, L.SizeMax, L.AvailableSizeMin, L.AvailableSizeMax, L.ListingNumber
	FROM	vw_PropertyMarketing L 

	WHERE (@ListingNumber= 'FULL' OR L.ListingNumber = @ListingNumber)
	ORDER BY L.PropertyID
END