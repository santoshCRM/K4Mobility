﻿CREATE PROCEDURE [dbo].[usp_GetPropertyOverrides] (@ListingNumber NVARCHAR(20) = 'FULL')
AS 
BEGIN
	SELECT PropertyID, OverrideAgentID, OverridesNumber 
	FROM vw_PropertyMarketingOverrides L
	WHERE (@ListingNumber= 'FULL' OR L.ListingNumber = @ListingNumber)
END