﻿CREATE PROCEDURE [dbo].[usp_GetPropertyTypes] (@ListingNumber NVARCHAR(20) = 'FULL')
AS
BEGIN 
	SELECT PropertyId, PropertyType
	FROM vw_PropertyMarketingPropertyTypes L
	WHERE (@ListingNumber= 'FULL' OR L.ListingNumber = @ListingNumber)
	ORDER BY L.PropertyId, L.SortOrder
END
