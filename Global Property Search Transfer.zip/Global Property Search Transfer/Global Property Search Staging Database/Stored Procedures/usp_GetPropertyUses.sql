﻿CREATE PROCEDURE [dbo].[usp_GetPropertyUses](@ListingNumber NVARCHAR(20) = 'FULL')
AS
BEGIN
	SELECT PropertyID, PropertyUse 
	FROM vw_PropertyMarketingPropertyUses L
	WHERE (@ListingNumber= 'FULL' OR L.ListingNumber = @ListingNumber)
	
END
