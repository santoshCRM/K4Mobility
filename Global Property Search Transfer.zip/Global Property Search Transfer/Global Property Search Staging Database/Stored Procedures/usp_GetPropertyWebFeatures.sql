﻿CREATE PROCEDURE [dbo].[usp_GetPropertyWebFeatures] (@ListingNumber NVARCHAR(20) = 'FULL')
AS
BEGIN
	SELECT PropertyId, WebFeature 
	FROM vw_PropertyMarketingWebFeature L
	WHERE (@ListingNumber= 'FULL' OR L.ListingNumber = @ListingNumber)
	ORDER BY PropertyId, RowNum
END
