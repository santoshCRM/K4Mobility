﻿CREATE PROCEDURE [dbo].[usp_GetSingleFeedProperties] AS
BEGIN
	SET NOCOUNT ON;
	SELECT P.ListingNumber FROM vw_PropertyMarketing P where P.PropertyModifyDate > COALESCE(P.LastModified, '2017-01-01') 
END
