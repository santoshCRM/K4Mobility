﻿CREATE PROCEDURE [dbo].[usp_LogProperty] @ListingNumber NVARCHAR(20), @TransferId INT, @ModifiedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Date DATETIME, @DateUTC DATETIME 
	SELECT @Date =  DateStarted, @DateUTC = DateStartedUTC FROM Transfers WHERE Id = @TransferId
	IF EXISTS(SELECT 1 FROM PropertyLog WHERE Listingnumber = @ListingNumber)
	BEGIN
		UPDATE PropertyLog SET LastModified = @Date, LastModifiedUTC = @DateUTC, PropertyModifiedUTC = @ModifiedOn WHERE ListingNumber = @ListingNumber
	END
	ELSE
	BEGIN
		INSERT INTO PropertyLog (ListingNumber, DateAdded, DateAddedUTC, LastModified, LastModifiedUTC, PropertyCreatedUTC, PropertyModifiedUTC)
		SELECT @ListingNumber, @Date, @DateUTC, @Date, @DateUTC, @ModifiedOn, @ModifiedOn
	END

END