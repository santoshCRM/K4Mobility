﻿CREATE PROCEDURE [dbo].[usp_StartTransfer] @IsFullTransfer BIT
AS
BEGIN
	DECLARE @TransferId INT
	
	INSERT INTO Transfers (DateStarted, DateStartedUTC, Fulltransfer)
	SELECT GETDATE(), GETUTCDATE(), @IsFullTransfer

	SELECT @TransferId = IDENT_CURRENT('Transfers')

	EXEC usp_TransferLog @TransferId = @TransferId, @LogType = 'Start Transfer'

	RETURN @TransferId

END

