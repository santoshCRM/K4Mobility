﻿CREATE PROCEDURE [dbo].[usp_TransferLog] @TransferId INT, @ListingNumber NVARCHAR(20) = NULL, @LogType NVARCHAR(50), @LogMessage NTEXT = NULL
AS
BEGIN 
	INSERT INTO TransferLog (TransferId, ListingNumber, LogDate, LogDateUTC, LogType, LogMessage)
	SELECT @TransferId, @ListingNumber, GETDATE(), GETUTCDATE(), @LogType, @LogMessage
END
	