﻿CREATE PROCEDURE [dbo].[usp_UpdatePropertyMarketing]
AS
	BEGIN
	SET NOCOUNT ON;
	UPDATE PropertyMarketing SET AvailableUnit = NULL

	DECLARE @MasterId UNIQUEIDENTIFIER,
			@ListingNumber NVARCHAR(20), 
			@PropertyType NVARCHAR(30),
			@LastRefurbishment NVARCHAR(20),
			@Tenure NVARCHAR(50),
			@ListingType NVARCHAR(50),
			@AvailableUnit NVARCHAR(MAX),
			@NABERS NVARCHAR(100),
			@Fieldname NVARCHAR(50), 
			@NewFieldName NVARCHAR(50)
	
	DECLARE curMaster CURSOR FOR SELECT ListingNumber, COALESCE(PropertyType, '') AS PropertyType, ListingType, COALESCE(TenureName,'') As Tenure  FROM PropertyMarketing ORDER BY 1
	OPEN curMaster 
	FETCH curMaster INTO @ListingNumber, @PropertyType, @ListingType, @Tenure
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @AvailableUnit = NULL, @NABERS  = NULL
		IF @ListingType = 'Sale'
		BEGIN 
			SELECT @NABERS =  MAX(BuildingNABERS) FROM AvailablePropertySale WHERE ListingNumber = @ListingNumber
			IF @PropertyType = 'Industrial'
			BEGIN 
				-- Industrial Sale
				SELECT @AvailableUnit = dbo.FlattenedJSON((SELECT Tenancy, SaleType, Price, AreaSqm as Area, Status_ AS "Status"  FROM vw_AvailablePropertySale WHERE ListingNumber = @ListingNumber FOR XML PATH, Root))
			END
			ELSE
			BEGIN 
				IF @Tenure = 'Strata Building' 
				BEGIN
				-- Strata Sale
					SELECT @AvailableUnit = dbo.FlattenedJSON((SELECT FloorNumber AS "Level", Tenancy as Suite, YearBuilt, LastRefurbished, Price, SaleType, AreaSqm as Area, Status_ AS "Status" FROM vw_AvailablePropertySale WHERE ListingNumber = @ListingNumber FOR XML PATH, Root))
				END
				ELSE
				BEGIN
					-- Other Sale
					SELECT @AvailableUnit = dbo.FlattenedJSON((SELECT FloorNumber AS "Level", Tenancy, SaleType, Price, AreaSqm, Status_ AS "Status" FROM vw_AvailablePropertySale WHERE ListingNumber = @ListingNumber FOR XML PATH, Root))
				END
			END
		END
		ELSE
		BEGIN
			SELECT @NABERS =  MAX(BuildingNABERS) FROM AvailablePropertyLease WHERE ListingNumber = @ListingNumber
			IF @PropertyType = 'Industrial'
			BEGIN 
				-- Industrial Lease
				SELECT @AvailableUnit = dbo.FlattenedJSON((SELECT	Tenancy, AreaSqm as Area, Rent, LeaseType, Availability as Available, TableStatus as "Status" FROM vw_AvailablePropertyLease WHERE ListingNumber = @ListingNumber FOR XML PATH, Root))
			END
			ELSE
			BEGIN 
				-- Other Lease
				SELECT @AvailableUnit = dbo.FlattenedJSON((SELECT	Tenancy, AreaSqm as Area, Rent, LeaseType, Availability as Available, Fitout, TableStatus as "Status" FROM vw_AvailablePropertyLease WHERE ListingNumber = @ListingNumber FOR XML PATH, Root))
			END
		END
		UPDATE PropertyMarketing SET AvailableUnit = @AvailableUnit, EnergyText = 'NABERS Rating: ' + @NABERS WHERE ListingNumber = @ListingNumber
		FETCH curMaster INTO @ListingNumber, @PropertyType, @ListingType, @Tenure
	END

	CLOSE curMaster
	DEALLOCATE curMaster

		
	DECLARE curFieldnames CURSOR FOR SELECT FieldName, NewFieldName FROM FieldNameMap 
	OPEN curFieldNames
	FETCH curFieldNames INTO @FieldName, @NewFieldName
	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE PropertyMarketing SET AvailableUnit = REPLACE(AvailableUnit, @FieldName, @NewFieldName)
		FETCH curFieldNames INTO @FieldName, @NewFieldName
	END
	CLOSE curFieldNames
	DEALLOCATE curFieldNames
END

