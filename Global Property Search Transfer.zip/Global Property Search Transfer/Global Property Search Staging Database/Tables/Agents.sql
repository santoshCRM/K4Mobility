﻿CREATE TABLE [dbo].[Agents](
	[EmpNumber] [nvarchar](50) NOT NULL,
	[Email] [nvarchar](100) NULL,
	[EmpPhone] [nvarchar](50) NULL,
	[DivisionCode] [nvarchar](100) NULL,
	[DivPhone] [nvarchar](100) NULL,
	[OfficePhone] [nvarchar](100) NULL,
	[EmpName] [nvarchar](40) NULL,
	[AgentId] [nvarchar](20) NULL,
 CONSTRAINT [PK_Agents_1] PRIMARY KEY CLUSTERED 
(
	[EmpNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
