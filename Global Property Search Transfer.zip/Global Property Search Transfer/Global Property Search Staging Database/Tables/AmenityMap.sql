﻿CREATE TABLE [dbo].[AmenityMap]
(
	[GW_Amenity] [nvarchar](50) NOT NULL,
	[WebAmenity] [nvarchar](50) NULL, 
    CONSTRAINT [PK_AmenityMap] PRIMARY KEY ([GW_Amenity])
) ON [PRIMARY]
