﻿CREATE TABLE [dbo].[AvailablePropertyLease]
(
	[mcs_alistingid] [uniqueidentifier] NOT NULL,
	[ListingNumber] [nvarchar](20) NOT NULL,
	[LeasingStatus] [nvarchar](255) NULL,
	[AreaAvailable] [float] NULL,
	[RentPSM] [money] NULL,
	[RentType] [nvarchar](255) NULL,
	[LeaseType] [nvarchar](255) NULL,
	[DisplayRent] [nvarchar](100) NULL,
	[AvailabilityOption] [int] NULL,
	[AvailabilityName] [nvarchar](255) NULL,
	[AvailabilityOther] [nvarchar](400) NULL,
	[ListDate] [datetime] NULL,
	[Fitout] [nvarchar](255) NULL,
	[BuildingArea] [float] NULL,
	[BuildingName] [nvarchar](400) NULL,
	[BuildingYearBuilt] [nvarchar](100) NULL,
	[BuildingNABERS] [nvarchar](255) NULL,
	[FloorName] [nvarchar](300) NULL,
	[UnitName] [nvarchar](999) NULL,
	[UnitSort] [int] NULL,
	[UnitFloor] [nvarchar](300) NULL,
	[ModifiedOn] [datetime] NULL,
	[UnitModifiedOn] [datetime] NULL,
	[FloorModifiedOn] [datetime] NULL,
	[BuildingModifiedOn] [datetime] NULL,
 CONSTRAINT [PK_AvailablePropertyLease] PRIMARY KEY CLUSTERED 
(
	[mcs_alistingid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
