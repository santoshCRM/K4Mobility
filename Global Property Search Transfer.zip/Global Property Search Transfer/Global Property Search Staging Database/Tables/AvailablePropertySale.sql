﻿CREATE TABLE [dbo].[AvailablePropertySale]
(
	[mcs_alistingid] [uniqueidentifier] NOT NULL,
	[ListingNumber] [nvarchar](20) NOT NULL,
	[SaleStatus] [nvarchar](255) NULL,
	[SalesType] [nvarchar](255) NULL,
	[AreaAvailable] [float] NULL,
	[AvailabilityOption] [int] NULL,
	[AvailabilityName] [nvarchar](255) NULL,
	[AvailabilityOther] [nvarchar](400) NULL,
	[SalesPrice] [money] NULL,
	[SalesPriceMin] [money] NULL,
	[SalesPriceMax] [money] NULL,
	[AskingPrice] [nvarchar](300) NULL,
	[ListDate] [datetime] NULL,
	[Fitout] [nvarchar](255) NULL,
	[BuildingArea] [float] NULL,
	[BuildingName] [nvarchar](400) NULL,
	[BuildingYearBuilt] [nvarchar](100) NULL,
	[BuildingNABERS] [nvarchar](255) NULL,
	[FloorName] [nvarchar](300) NULL,
	[UnitName] [nvarchar](999) NULL,
	[UnitSort] [int] NULL,
	[UnitFloor] [nvarchar](300) NULL,
	[ModifiedOn] [datetime] NULL,
	[UnitModifiedon] [datetime] NULL,
	[FloorModifiedOn] [datetime] NULL,
	[BuildingModifiedOn] [datetime] NULL,
	[LastRefurbishment] [nvarchar](20) NULL,
 CONSTRAINT [PK_AvailablePropertySale] PRIMARY KEY CLUSTERED 
(
	[mcs_alistingid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
