﻿CREATE TABLE [dbo].[Bullets]
(
	[BulletId] [uniqueidentifier] NOT NULL,
	[LeaseListingNumber] [nvarchar](20) NULL,
	[SalesListingNumber] [nvarchar](20) NULL,
	[Bullet] [ntext] NULL,
	[ModifiedOn] [datetime] NULL,
 CONSTRAINT [PK_Bullets] PRIMARY KEY CLUSTERED 
(
	[BulletId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]