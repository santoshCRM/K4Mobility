﻿CREATE TABLE [dbo].[DocumentTypeMap]
(
	[DocumentType] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [WebDocumentType] INT NULL, 
    [WebFileNameInitial] NVARCHAR(10) NULL
)
