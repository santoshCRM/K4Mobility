﻿CREATE TABLE [dbo].[FieldNameMap]
(
	[FieldName] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [NewFieldName] NVARCHAR(50) NULL
)
