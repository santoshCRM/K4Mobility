﻿CREATE TABLE [dbo].[ListingDocuments]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[LeaseListingNumber] [nvarchar](20) NULL,
	[SalesListingNumber] [nvarchar](20) NULL,
	[PropertyMarketingId] [uniqueidentifier] NULL,
	[DocumentType] NVARCHAR(50) NULL, 
	[SortOrder] [int] NULL,
	[SharepointFolderName] [nvarchar](255) NULL,
	[FileName] [nvarchar](400) NULL,
	[ModifiedOn] [datetime] NULL,
    [Caption] NVARCHAR(100) NULL, 
    CONSTRAINT [PK_ListingDocuments] PRIMARY KEY ([Id])
)
