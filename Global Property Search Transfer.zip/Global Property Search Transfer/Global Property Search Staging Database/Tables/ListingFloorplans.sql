﻿CREATE TABLE [dbo].[ListingFloorplans]
(
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[LeaseListingNumber] [nvarchar](20) NULL,
	[SalesListingNumber] [nvarchar](20) NULL,
	[PropertyMarketingId] [uniqueidentifier] NULL,
	[SortOrder] [int] NULL,
	[SharepointImageFolderName] [nvarchar](100) NULL,
	[ImageName] [nvarchar](400) NULL,
	[ModifiedOn] [datetime] NULL,
 [Caption] NVARCHAR(100) NULL, 
    CONSTRAINT [PK_ListingFloorplans] PRIMARY KEY ([Id]), 
)
