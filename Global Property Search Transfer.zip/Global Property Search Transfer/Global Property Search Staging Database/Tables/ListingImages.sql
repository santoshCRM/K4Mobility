﻿CREATE TABLE [dbo].[ListingImages]
(
	[ImageId] [uniqueidentifier] NOT NULL,
	[LeaseListingNumber] [nvarchar](20) NULL,
	[SalesListingNumber] [nvarchar](20) NULL,
	[PropertyMarketingId] [uniqueidentifier] NULL,
	[IsHeroImage] [bit] NULL,
	[SortOrder] [int] NULL,
	[SharepointImageFolderName] [nvarchar](100) NULL,
	[ImageName] [nvarchar](400) NULL,
	[ModifiedOn] [datetime] NULL,
 [Caption] NVARCHAR(100) NULL, 
    CONSTRAINT [PK_ListingImages] PRIMARY KEY CLUSTERED 
(
	[ImageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]