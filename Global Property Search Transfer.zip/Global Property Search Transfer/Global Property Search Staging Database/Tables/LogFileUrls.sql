﻿CREATE TABLE [dbo].[LogFileUrls]
(
	[Environment] NCHAR(10) NOT NULL, 
	[LogType] NVARCHAR(50) NOT NULL , 
    [LogfileURL] NVARCHAR(200) NULL, 
    [LogFileType] NCHAR(10) NULL, 
    PRIMARY KEY ( [Environment], [LogType])
)
