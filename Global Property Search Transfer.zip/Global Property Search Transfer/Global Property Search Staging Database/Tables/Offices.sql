﻿
CREATE TABLE [dbo].[Offices](
	[OfficeId] [nvarchar](6) NOT NULL,
	[OfficeGuid] [uniqueidentifier] NOT NULL,
	[DivisionCode] [nvarchar](10) NOT NULL,
	[OfficeName] [nvarchar](200) NULL,
	[OfficeEmail] [nvarchar](50) NULL,
	[OfficeURL] [nvarchar](255) NULL,
	[OfficePhone] [nvarchar](25) NULL,
	[Longitude] [float] NULL,
	[Latitude] [float] NULL,
	[Address1] [nvarchar](50) NULL,
	[Address2] [nvarchar](50) NULL,
	[Country] [nvarchar](50) NULL,
	[Region] [nvarchar](255) NULL,
	[Postcode] [nvarchar](15) NULL,
	[Suburb] [nvarchar](25) NULL,
	[Licence] [nvarchar](25) NULL,
 CONSTRAINT [PK_Offices] PRIMARY KEY CLUSTERED 
(
	[OfficeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO