﻿CREATE TABLE [dbo].[PropertyLog]
(
	[ListingNumber] NVARCHAR(20) NOT NULL PRIMARY KEY, 
    [DateAddedUTC] DATETIME NULL, 
    [DateAdded] DATETIME NULL, 
    [LastModifiedUTC] DATETIME NULL, 
    [LastModified] DATETIME NULL, 
    [PropertyCreatedUTC] DATETIME NULL, 
    [PropertyModifiedUTC] DATETIME NULL
)
