﻿CREATE TABLE [dbo].[PropertyTypeMap]
(
	[GatewayPropertyType] [nvarchar](50) NOT NULL,
	[WebsitePropertyType] [nvarchar](10) NULL, 
    CONSTRAINT [PK_PropertyTypeMap] PRIMARY KEY ([GatewayPropertyType])
) ON [PRIMARY]