﻿CREATE TABLE [dbo].[TransferLog]
(
	[Id] INT IDENTITY (1,1) NOT NULL PRIMARY KEY, 
    [TransferId] INT NOT NULL, 
    [LogDate] DATETIME NOT NULL, 
	[ListingNumber] NVARCHAR(20),
    [LogType] NVARCHAR(50) NOT NULL, 
    [LogMessage] NTEXT NULL, 
    [LogDateUTC] DATETIME NULL

)
