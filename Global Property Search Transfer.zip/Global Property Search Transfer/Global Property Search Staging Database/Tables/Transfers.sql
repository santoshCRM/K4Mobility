﻿CREATE TABLE [dbo].[Transfers]
(
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, 
    [DateStarted] DATETIME NULL, 
    [Fulltransfer] BIT NULL, 
    [DateEnded] DATETIME NULL, 
    [DateStartedUTC] DATETIME NULL, 
    [DateEndedUTC] DATETIME NULL
)
