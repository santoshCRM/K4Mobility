﻿CREATE VIEW [dbo].[vw_Agents] 	AS 
SELECT DISTINCT A.AgentID AS AgentID, O.OfficeId,  CONVERT(NVARCHAR(25), A.DivPhone) AS DepartmentPhoneNumber,  A.Email AS EmailAddress, A.EmpNumber as EmpNumber, A.EmpName as AgentName,  
				COALESCE(A.EmpPhone,A.DivPhone, A.OfficePhone) AS AgentPhoneNumber, 	CONVERT(NVARCHAR(25), NULL) AS LicenceNumber, 
				CONVERT(INT,NULL) AS LicenseType, A.AgentID + '.jpg' as AgentImageFileName, 'jpg' As AgentImageFileType, CONVERT(INT, 5)  AS AgentImageAssetType, A.EmpNumber as ImageId, A.DivisionCode AS DivisionCode
FROM Agents A INNER JOIN Offices O ON O.DivisionCode = A.DivisionCode
