﻿CREATE VIEW [dbo].[vw_AvailablePropertyFilter]
	AS SELECT DISTINCT  ListingNumber FROM
(SELECT ListingNumber AS ListingNumber FROM vw_AvailablePropertySale WHERE COALESCE(Area, 0) > 0  AND COALESCE(SalesPriceValue, 0) > 0 ANd SaleStatus IN ('For Sale', 'Under Offer', 'Sold')
UNION
SELECT ListingNumber FROM vw_AvailablePropertyLease WHERE COALESCE(AreaAvailable, 0) > 0  AND COALESCE(RentPSM, 0) > 0 
) A
