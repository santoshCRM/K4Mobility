﻿CREATE VIEW [dbo].[vw_AvailablePropertyLease]
	AS SELECT ListingNumber, REPLACE(COALESCE(CASE WHEN UnitName IS NULL THEN (CASE WHEN FloorName IS NOT NULL THEN FloorName ELSE COALESCE(BuildingName, '') END) ELSE UnitName END, ''), '/', ' ') as Tenancy, 
		COALESCE(CONVERT(NVARCHAR(10), CONVERT(MONEY,AreaAvailable), 1) + 'sq m','') AS AreaSqm, 	COALESCE(A.Fitout, 'No') AS Fitout,		
		CASE WHEN DisplayRent IS NOT NULL THEN DisplayRent WHEN COALESCE(RentPSM,0) = 0 THEN 'POA' ELSE '$' + CONVERT(NVARCHAR(10), RentPSM) + ' /sq m' END AS Rent, 	COALESCE(LeaseType,'') AS LeaseType, 
		COALESCE(CASE WHEN COALESCE(LeasingStatus,'')  = 'For Lease'  THEN (CASE WHEN COALESCE(AvailabilityName,'') = 'Other' THEN AvailabilityOther ELSE AvailabilityName END)  ELSE LeasingStatus END ,'') AS Availability,
		CASE WHEN COALESCE(LeasingStatus,'') = 'Leased' THEN LeasingStatus ELSE (CASE WHEN DATEADD("dd",21,ListDate) > GETDATE() THEN 'New Listing' ELSE '' END) END as TableStatus, M.WebStatus, A.AreaAvailable,  A.RentPSM
FROM AvailablePropertyLease A INNER JOIN StatusMap M ON M.Status = A.LeasingStatus
