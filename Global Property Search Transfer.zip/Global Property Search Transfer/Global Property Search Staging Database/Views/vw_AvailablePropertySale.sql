﻿CREATE VIEW [dbo].[vw_AvailablePropertySale]
	AS SELECT   ListingNumber, COALESCE(FloorName,'') as FloorNumber,  REPLACE(COALESCE(CASE WHEN UnitName IS NULL THEN 'n/a' ELSE UnitName END, ''), '/', ' ') AS Tenancy,	COALESCE(SalesType,'') As SaleType,	
		 COALESCE(AskingPrice,'') As Price, SalesPrice, SalesPriceMin, SalesPriceMax, COALESCE(SalesPrice, SalesPriceMin, SalesPriceMax) as SalesPriceValue,
		 COALESCE(CONVERT(NVARCHAR(10), CONVERT(MONEY, COALESCE(AreaAvailable, BuildingArea), 1)) + 'sq m','') AS AreaSqm, COALESCE(AreaAvailable, BuildingArea, 0) as Area,	COALESCE(BuildingYearBuilt,'') as YearBuilt, 
		 COALESCE(LastRefurbishment,'') as LastRefurbished, SaleStatus, CASE WHEN COALESCE(SaleStatus,'') = 'Sold' THEN SaleStatus ELSE (CASE WHEN DATEADD("dd",21,ListDate) > GETDATE() THEN 'New Listing' ELSE '' END) END as Status_
FROM AvailablePropertySale
