﻿CREATE VIEW [dbo].[vw_Bullets]
	AS SELECT P.ListingNumber, P.PropertyID, ROW_NUMBER() OVER(PARTITION BY P.PropertyID ORDER BY B.BulletID) as RowNum, B.Bullet, B.ModifiedOn
FROM Bullets B 
	INNER JOIN (SELECT BulletID, LeaseListingNumber AS ListingNumber FROM Bullets WHERE LeaseListingNumber IS NOT NULL UNION SELECT BulletId, SalesListingNumber AS ListingNumber FROM Bullets WHERE SalesListingNumber IS NOT NULL) F ON F.BulletID = B.BulletID
	INNER JOIN vw_PropertyMarketing P ON P.ListingNumber = F.ListingNumber
