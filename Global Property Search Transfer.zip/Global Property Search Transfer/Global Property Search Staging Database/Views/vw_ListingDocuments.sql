﻿CREATE VIEW [dbo].[vw_ListingDocuments] AS 
SELECT ListingNumber, PropertyID, PropertyID + '_' + WebFileNameInitial +  '_'+ RIGHT('00' + CONVERT(NVARCHAR(2),  RowNum),2) + '.jpg' as FileName,  RowNum as SortOrder, SourcePath, Caption, WebDocumentType, 'Document' As SourceSite  FROM
	(SELECT M.ListingNumber, M.PropertyID,  ROW_NUMBER() OVER (PARTITION BY M.PropertyID ORDER BY D.SortOrder) as RowNum, 
	'\master listing\' + D.SharePointFolderName + '\' + D.FileName as SourcePath, D.ModifiedOn, D.Caption, 'Document' As SourceSite, T.WebDocumentType, T.WebFileNameInitial
	FROM ListingDocuments D 
		INNER JOIN (SELECT  Id, LeaseListingNumber AS ListingNumber  FROM ListingDocuments WHERE LeaseListingNumber IS NOT NULL 
					 UNION SELECT  Id, SalesListingNumber AS ListingNumber  FROM ListingDocuments WHERE SalesListingNumber IS NOT NULL) F ON F.Id = D.Id
		INNER JOIN vw_PropertyMarketing M ON M.ListingNumber = F.ListingNumber
		INNER JOIN DocumentTypeMap T ON T.DocumentType = D.DocumentType
		) X
