﻿CREATE VIEW [dbo].[vw_ListingFloorplans] AS SELECT ListingNumber, PropertyID, PropertyID + '_F_' + RIGHT('00' + CONVERT(NVARCHAR(2),  RowNum),2) + '.jpg' as FileName,  RowNum as SortOrder, SourcePath, Caption,  N'Image' As SourceSite  FROM
	(SELECT M.ListingNumber, M.PropertyID,  ROW_NUMBER() OVER (PARTITION BY M.PropertyID ORDER BY I.SortOrder) as RowNum, 
			'\Basic Listing\' + I.SharePointImageFolderName + '\' + I.ImageName as SourcePath, I.ModifiedOn, I.Caption
	FROM ListingFloorplans I 
		INNER JOIN (SELECT  Id, LeaseListingNumber AS ListingNumber  FROM ListingFloorPlans WHERE LeaseListingNumber IS NOT NULL 
					UNION 
					SELECT  Id, SalesListingNumber AS ListingNumber  FROM ListingFloorPlans WHERE SalesListingNumber IS NOT NULL) F ON F.Id = I.Id
		INNER JOIN vw_PropertyMarketing M ON M.ListingNumber = F.ListingNumber) X
