﻿CREATE VIEW [dbo].[vw_ListingImages]
	AS SELECT ListingNumber, PropertyID, PropertyID + '_I_' + RIGHT('00' + CONVERT(NVARCHAR(2),  RowNum),2) + '.jpg' as FileName,  RowNum as SortOrder, SourcePath, Caption, 'Image' As SourceSite FROM
	(SELECT M.ListingNumber, M.PropertyID,  ROW_NUMBER() OVER (PARTITION BY M.PropertyID ORDER BY I.IsHeroImage DESC, I.SortOrder) as RowNum, 
			'\master listing\' + M.SharePointImageFolder + '\' + I.ImageName as SourcePath, I.ModifiedOn, I.Caption
	FROM ListingImages I 
		INNER JOIN (SELECT  ImageId, LeaseListingNumber AS ListingNumber  FROM ListingImages WHERE LeaseListingNumber IS NOT NULL UNION SELECT  ImageId, SalesListingNumber AS ListingNumber  FROM ListingImages WHERE SalesListingNumber IS NOT NULL) F ON F.ImageId = I.ImageId
		INNER JOIN vw_PropertyMarketing M ON M.ListingNumber = F.ListingNumber) X
