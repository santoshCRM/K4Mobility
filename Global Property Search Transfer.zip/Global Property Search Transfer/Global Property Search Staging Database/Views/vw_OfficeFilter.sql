﻿CREATE VIEW [dbo].[vw_OfficeFilter]
	AS SELECT DISTINCT OfficeID FROM vw_PropertyMarketing 

