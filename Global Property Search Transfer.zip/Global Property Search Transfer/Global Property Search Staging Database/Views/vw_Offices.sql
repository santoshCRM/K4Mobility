﻿	CREATE VIEW [dbo].[vw_Offices] AS 
	SELECT	O.OfficeID as OfficeID, O.OfficeName, O.OfficePhone AS OfficePhoneNumber, O.OfficeEmail as OfficeEmail, O.OfficeURL, CONVERT(NVARCHAR(25), CASE WHEN COALESCE(O.Licence, '') <> '' THEN 'RLA: ' + O.Licence ELSE NULL END) AS LicenceNumber,  
			CONVERT(INT, CASE WHEN COALESCE(O.Licence, '') <> '' THEN 1 ELSE NULL END) AS LicenceType, O.Address1, O.Address2, CONVERT(NVARCHAR(50), NULL) AS Address3, O.Suburb AS CityTown, O.Postcode as PostCode, O.Country, O.Region, O.Latitude, O.Longitude, O.DivisionCode
	FROM Offices O 
