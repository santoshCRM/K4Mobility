﻿CREATE VIEW [dbo].[vw_PropertyLastModified]
	AS SELECT ListingNumber, MAX(ModifiedOn) ModifiedOn  FROM (
    SELECT ListingNumber, ModifiedOn FROM PropertyMarketing
    UNION
    SELECT ListingNumber, PropertyModifiedOn FROM PropertyMarketing
    UNION
    SELECT ListingNumber, ModifiedOn  FROM AvailablePropertyLease
    UNION
    SELECT ListingNumber, UnitModifiedOn  FROM AvailablePropertyLease
    UNION
    SELECT ListingNumber, BuildingModifiedOn FROM AvailablePropertyLease
    UNION
    SELECT ListingNumber, FloorModifiedOn FROM AvailablePropertyLease
    UNION
    SELECT ListingNumber, ModifiedOn FROM AvailablePropertySale
    UNION
    SELECT ListingNumber, UnitModifiedOn FROM AvailablePropertySale
    UNION
    SELECT ListingNumber, BuildingModifiedOn FROM AvailablePropertySale
    UNION
    SELECT ListingNumber, FloorModifiedOn FROM AvailablePropertySale
    UNION
    SELECT LeaseListingNumber, ModifiedOn FROM Bullets WHERE LeaseListingNumber IS NOT NULL
    UNION
    SELECT SalesListingNumber, ModifiedOn  FROM Bullets WHERE SalesListingNumber IS NOT NULL
    UNION
    SELECT LeaseListingNumber, ModifiedOn FROM ListingImages WHERE LeaseListingNumber IS NOT NULL
    UNION
    SELECT SalesListingNumber, ModifiedOn FROM ListingImages WHERE SalesListingNumber IS NOT NULL
	UNION
	SELECT LeaseListingNumber, ModifiedOn FROM ListingFloorplans WHERE LeaseListingNumber IS NOT NULL
    UNION
    SELECT SalesListingNumber, ModifiedOn FROM ListingFloorplans WHERE SalesListingNumber IS NOT NULL
	UNION
	SELECT LeaseListingNumber, ModifiedOn FROM ListingDocuments WHERE LeaseListingNumber IS NOT NULL
    UNION
    SELECT SalesListingNumber, ModifiedOn FROM ListingDocuments WHERE SalesListingNumber IS NOT NULL
	) X GROUP BY ListingNumber

