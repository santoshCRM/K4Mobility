﻿CREATE VIEW [dbo].[vw_PropertyMarketing]
	AS SELECT	O.OfficeID +  P.ListingNumber as PropertyID, CONVERT(NVARCHAR(10), NULL) AS PreviousPropertyID,  CONVERT(NVARCHAR(10), NULL) AS ParentPropertyID,  O.OfficeID as OfficeID, A1.AgentID As Agent1ID, 
				A2.AgentID AS Agent2ID, CONVERT(INT, 0) as Action, ISNULL(PL.PropertyCreatedUTC, M.ModifiedOn) as PropertyCreateDate, M.ModifiedOn as PropertyModifyDate, P.Latitude as Latitude, P.Longitude as Longitude, 
				LEFT(P.Address_1, 70) as AddressLine1, 	LEFT(P.City, 70) as AddressLine2, LEFT(P.PropertyName, 70) as BuildingName, LEFT(P.AdvertisingHeadline, 200) as PropertyTitle, P.AvailableUnit as AvailableUnit, 
				ISNULL(P.EnergyText,'') As EnergyText, CONVERT(NVARCHAR(500), REPLACE(CONVERT(NVARCHAR(MAX),ISNULL( P.AdvertisingHeadline, '')), '"', ' ')) AS Description, P.MarketingLocation as Location, 
				REPLACE(CONVERT(NVARCHAR(MAX), ISNULL(P.LongDescription, P.ShortDescription)), CHAR(10), '<br/>') as LongDescription, CONVERT(NVARCHAR(2000), NULL) AS AreaGuide, CONVERT(NVARCHAR(350), NULL) AS QuoteText, 
				CONVERT(NVARCHAR(20), NULL) AS QuoteContact,  P.TenureOption - 804120000  as Tenure, CONVERT(INT, NULL) AS Flag, P.Currency as BaseCurrency, CONVERT(INT, 0) as GuidePriceText, CONVERT(MONEY, S.MaxPrice) as PriceUpperBound, 
				CONVERT(INT, S.MinPrice) As Price, CONVERT(NVARCHAR(100), '') AS PriceDisclaimer, CONVERT(INT, CASE WHEN P.ListingType = 'Sale' THEN 0 ELSE 1 END) As BuyOrRent,  
				CONVERT(INT, CASE WHEN P.ListingType = 'Lease' THEN 1 ELSE NULL END) AS RentUnit, CONVERT(INT, NULL) AS RentBasis, CONVERT(MONEY, NULL) AS Yield, CONVERT(INT, NULL) AS NumberOfPeople, 
				CONVERT(INT, NULL) As BuildingAge, CONVERT(INT, NULL) AS OfficeGrade, CONVERT(INT, NULL) AS Bedrooms, CONVERT(INT, S.Status) As PropertyStatus, P.Video as VideoUrl , P.www ExternalUrl, 
				CONVERT(NVARCHAR(400), NULL) AS Video360, CONVERT(INT, NULL) AS ShowFacebook, CONVERT(INT, NULL) AS IsConfidential, CONVERT(INT, NULL) AS IsHidden,  S.MinArea AS SizeMin, S.MaxArea as SizeMax, 
				S.MinArea As AvailableSizeMin, S.MaxArea as AvailableSizeMax, P.PropertyType, P.Retail,  P.Industrial, P.Commercial, P.Land, P.Hospitality, P.Hotel, P.Rural, P.ListingNumber, P.TenureName, P.ListingType,	
				P.mcs_alistingcampaignid AS ListingCampaignID, P.SharePointImageFolder, PL.PropertyModifiedUTC as LastModified, O.DivisionCode
		FROM	PropertyMarketing P 
				INNER JOIN vw_Agents A1 ON A1.EmpNumber = P.Agent1EmpNo
				INNER JOIN vw_Offices O ON O.DivisionCode = ISNULL(P.DivisionCode, A1.DivisionCode)
				LEFT JOIN vw_Agents A2 ON A2.EmpNumber = P.Agent2EmpNo
				INNER JOIN  vw_AvailablePropertyFilter F ON F.ListingNumber = P.ListingNumber
				INNER JOIN vw_PropertyMarketingListingSummary S ON S.ListingNumber = P.ListingNumber
				INNER JOIN (SELECT  LeaseListingNumber AS ListingNumber  FROM ListingImages WHERE LeaseListingNumber IS NOT NULL 
							UNION SELECT SalesListingNumber AS ListingNumber  FROM ListingImages WHERE SalesListingNumber IS NOT NULL) I ON I.ListingNumber = P.ListingNumber
				LEFT JOIN vw_PropertyLastModified M ON M.ListingNumber = P.ListingNumber 
				LEFT JOIN PropertyLog PL ON PL.ListingNumber = P.ListingNumber
		WHERE P.Latitude IS NOT NULL AND P.Longitude Is NOT NULL
