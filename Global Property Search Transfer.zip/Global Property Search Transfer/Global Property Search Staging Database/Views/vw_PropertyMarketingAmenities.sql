﻿CREATE VIEW [dbo].[vw_PropertyMarketingAmenities]
	AS SELECT PropertyID, NULL AS Amenity, ListingNumber FROM vw_PropertyMarketing WHERE  1 = 0

