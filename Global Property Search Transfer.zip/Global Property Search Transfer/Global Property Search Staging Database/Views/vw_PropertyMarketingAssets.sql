﻿CREATE VIEW [dbo].[vw_PropertyMarketingAssets] AS 
SELECT ListingNumber, PropertyId, 1 AS AssetType, FileName AS FileName, LEFT(Caption,20) AS Caption, SortOrder AS Order_, SourcePath AS FileURL, SourceSite FROM vw_ListingImages
UNION
SELECT ListingNumber, PropertyID, 2 AS AssetType, FileName, LEFT(Caption,20) AS Caption,  SortOrder, SourcePath, SourceSite   FROM vw_ListingFloorplans
UNION
SELECT ListingNumber, PropertyID, WebDocumentType as AssetType, FileName, LEFT(Caption,20) As Caption, SortOrder, SourcePath, SourceSite FROM vw_ListingDocuments