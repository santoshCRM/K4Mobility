﻿CREATE VIEW [dbo].[vw_PropertyMarketingListingSummary]
	AS SELECT ListingNumber, MinArea, CASE WHEN NumListings = 1 THEN NULL ELSE MaxArea END AS MaxArea, MinPrice, CASE WHEN NumListings = 1 THEN NULL ELSE MaxPrice END AS MaxPrice, MinStatus as Status
		   FROM
(SELECT ListingNumber, COUNT(*) AS NumListings, MIN(AreaAvailable) as MinArea, MAX(AreaAvailable) AS MaxArea, MIN(RentPSM) as MinPrice, MAX(RentPSM) as MAXPrice,  MIN(WebStatus) AS MinStatus 
	FROM vw_AvailablePropertyLease GROUP BY ListingNumber
UNION
SELECT ListingNumber, COUNT(*) AS NumListings, MIN(Area) as MinArea, MAX(Area) AS MaxArea, MIN(COALESCE(SalesPriceMin, SalesPrice)) AS MinPrice,  
		MAX(SalesPriceMax) AS MaxPrice, MIN(M.WebStatus) AS MinStatus
FROM  vw_AvailablePropertySale L INNER JOIN StatusMap M ON L.SaleStatus = M.Status GROUP BY ListingNumber) X
