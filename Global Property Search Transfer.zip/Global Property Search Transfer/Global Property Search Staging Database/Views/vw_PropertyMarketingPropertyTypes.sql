﻿CREATE VIEW [dbo].[vw_PropertyMarketingPropertyTypes] AS 
SELECT DISTINCT A.PropertyId, ListingNumber, M.WebsitePropertyType AS PropertyType, MIN(SortOrder) as SortOrder FROM (
	SELECT PropertyId, ListingNumber, PropertyType, 1 AS SortOrder FROM vw_PropertyMarketing WHERE PropertyType IS NOT NULL
	UNION 
	SELECT PropertyID, ListingNumber, 'Retail', 2 AS SortOrder FROM vw_PropertyMarketing  WHERE Retail = 1
	UNION 
	SELECT PropertyID, ListingNumber, 'Industrial', 2 AS SortOrder FROM vw_PropertyMarketing  WHERE Industrial = 1
	UNION 
	SELECT PropertyID, ListingNumber, 'Office', 2 AS SortOrder FROM vw_PropertyMarketing  WHERE Commercial = 1 
	UNION 
	SELECT PropertyID, ListingNumber, 'Land', 2 AS SortOrder FROM vw_PropertyMarketing  WHERE Land = 1
	UNION 
	SELECT PropertyID, ListingNumber, 'Hotels & Leisure', 2 AS SortOrder FROM vw_PropertyMarketing  WHERE Hospitality = 1
	UNION 
	SELECT PropertyID, ListingNumber, 'Hotels & Leisure', 2 AS SortOrder FROM vw_PropertyMarketing  WHERE Hotel = 1
	UNION 
	SELECT PropertyID, ListingNumber, 'Rural', 2 AS SortOrder FROM vw_PropertyMarketing  WHERE Rural = 1
) A INNER JOIN PropertyTypeMap M ON M.GatewayPropertyType = A.PropertyType AND M.WebsitePropertyType IS NOT NULL
GROUP BY A.PropertyId, ListingNumber, M.WebsitePropertyType
