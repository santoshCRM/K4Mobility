﻿CREATE VIEW [dbo].[vw_PropertyMarketingPropertyUses]
	AS SELECT PropertyID, ListingNumber,  NULL AS PropertyUse 
	FROM vw_PropertyMarketing WHERE  1 = 0
