﻿CREATE VIEW [dbo].[vw_PropertyMarketingWebFeature]
	AS SELECT ListingNumber, PropertyID, Bullet as WebFeature, RowNum FROm vw_Bullets WHERE RowNum < 11