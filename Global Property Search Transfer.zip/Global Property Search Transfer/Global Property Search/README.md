# Introduction
SSIS Packages to extract Listings & associated data from Gateway, upload them into a Staging databse and then create an XML extract for FTP to the UK Global Property Search Website.

# Installation
Developed using Visual Studio 2017 for SQL Server 2012.


# Deployment
Deployed on HOSQL5. 
Requires KingswaySoft Dynamics CRM Connector & SSIS Productivity Pack
The Staging database is called Global_Property_Search_Live & is installed on HOSQL6.
XML files are created at \\HOSQL5\SSIS_DATA\UK_Commercial_Portal\

# Project Parameters
## DataFolder
Location for staging the XML & image files & creating the Zip file
## FullTransfer
Boolean flag to indicate whether this is a Full feed (True) or Single Property Feed.

# Connections
## Gateway
KingswaySoft Dynamics Connector to Gateway
## Global_Property_Search_Staging
OLEDB SQL Connector to Global Property Search Staginhg Database
## GlobalSearchFTP
KingswaySoft FTP Connector to UK FTP site used for file transfer
## GatewayImagesSPSite
KingswaySoft HTTP connector to Sharepoint Site containing Gateway Images & Floorplans. Used for downloading Listing Images & Floorplans
## GatewayDocumentsSPSite
KingswaySoft HTTP connector to Sharepoint Site containing Gateway Documents. Used for downloading Listing Documents
## StaffImagesSPSite
KingswaySoft Sharepoint connecter to Sharepoint site containing Staff Mugshot images.
## GlobalSearchLogWebsite
KingswaySoft HTTP connector to UK Website containing log files.

# Packages
## MainCommercialProcess ##
### Description
Master Package for the process whole process of extracting data from Gateway through to sending data to UK FTP. This is the starting point for all transfers. 
###Calls Sub Packages
GetOfficeAgentFromGateway (Full Feed Only)
GetListingsFromGateway
CreateExtractanTransfer
## CreateExtractandTransfer 
###Description
Main Package that calls the sub packages to create XML files. This package zips folder, transfers the file via FTP & moves the zip file to the done folder 
### Calls Sub Packages
CreateOfficeXML
CreatePropertyXML
## GetListingsFromGateway
###Description
Package that downloads Listing details from Gateway into Staging Database
## GetOfficeAgentFromGateway
###Description
Package that downloads Office & Agent details from Gateway into Staging Database
## CreateOfficeXML
###Description
Package that creates the Office XML file from the data in the Staging database & downloads the Staff Image files & populates the Agents folder
### Calls Sub Packages
FixXMLNameSpace
## CreatePropertyXML
###Description
Package that creates the Property XML file from the data in the Staging database. Downloads the Property Image & Property Documents to populate the Properties folder
### Calls Sub Packages
FixXMLNameSpace
## FixXMLNameSpace
###Description
Package to Add namespace to XML files because the KingswaySoft XML task doesn't handle namespaces correctly
## DownloadLogs
###Description
Package that downloads the log files, not strictly part of the transfer process
## StartStaging
###Description
Package that calls the webpage to start the staging environment, not strictly part of the transfer process

	




