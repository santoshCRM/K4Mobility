﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.IO;
using System.Net;
using System.Text;

namespace K4MobWorkflows
{
    public class DeleteOpportunityRelatedRecords : CodeActivity
    {
        #region variable used
        [Input("Account")]
        [RequiredArgument]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account { get; set; }

        [Input("VesselName")]
        [RequiredArgument]
        [ReferenceTarget("account")]
        public InArgument<string> VesselName { get; set; }

        #endregion
        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Account.Get<EntityReference>(executionContext) != null)
                {
                    #region Deleting Opportunity Related Records
                    var AccountId = Account.Get<EntityReference>(executionContext).Id.ToString();
                    var K4_Vesselname = Convert.ToString(VesselName.Get<string>(executionContext).ToString(), null);

                    #region///****Delete Invoice *****///
                    EntityCollection GetinvoiceDetails = GetInvoice(service, K4_Vesselname);
                    foreach (var invoice in GetinvoiceDetails.Entities)
                    {
                        if (invoice.Attributes.Contains("invoiceid"))
                        {
                            service.Delete("invoice", invoice.Id);
                        }
                        else
                        {
                            var Output="No Invoice Details Found";
                        }
                        
                    }
                    #endregion
                    #region///****Delete Order *****///
                    EntityCollection GetsaleoderDetails = GetSaleOrder(service, K4_Vesselname);
                    foreach (var saleorder in GetsaleoderDetails.Entities)
                    {
                        if (saleorder.Attributes.Contains("salesorderid"))
                        {
                            service.Delete("salesorder", saleorder.Id);
                        }
                        else
                        {
                            var Output = "No Orders Details Found";
                        }

                    }
                    #endregion
                    #region ///****Delete Quote *****///
                    EntityCollection GetQuoteDetails = GetQuote(service, K4_Vesselname);
                    foreach (var quote in GetQuoteDetails.Entities)
                    {
                        if (quote.Attributes.Contains("quoteid"))
                        {
                            service.Delete("quote", quote.Id);
                        }
                        else
                        {
                            var Output = "No Quote Details Found";
                        }

                    }
                    #endregion
                    #region///****Delete Opportunity *****///
                    EntityCollection GetOpportunityDetails = GetOpportunity(service, K4_Vesselname);
                    foreach (var opportunity in GetOpportunityDetails.Entities)
                    {
                        if (opportunity.Attributes.Contains("opportunityid"))
                        {
                            service.Delete("opportunity", opportunity.Id);
                        }
                        else
                        {
                            var Output = "No Opportunity Details Found";
                        }

                    }
                    #endregion
                    #region///****Delete Workorder Related Records *****///
                    EntityCollection GetWorkOrderDetails = GetWorkOrder(service, K4_Vesselname);
                    foreach (var workorder in GetWorkOrderDetails.Entities)
                    {
                        var Workordernumber = workorder.Attributes["msdyn_name"].ToString();
                        ///****Delete Resource *****///
                        EntityCollection GetResourceDetails = GetResource(service, Workordernumber);
                        foreach (var Resource in GetResourceDetails.Entities)
                        {
                            if (Resource.Attributes.Contains("msdyn_resourcerequirementid"))
                            {
                                service.Delete("msdyn_resourcerequirement", Resource.Id);
                            }
                            else
                            {
                                var output = "No Resource Requirement found";
                            }
                            
                        }
                        ///****Delete Booking *****///
                        EntityCollection GetBookingDetails = GetBooking(service, Workordernumber);
                        foreach (var booking in GetBookingDetails.Entities)
                        {
                            if (booking.Attributes.Contains("bookableresourcebookingid"))
                            {
                                service.Delete("bookableresourcebooking", booking.Id);
                            }
                            else
                            {
                                var output = "No Booking Details found";
                            }
                        }
                        ///****Delete Workorder *****///
                        if (workorder.Attributes.Contains("msdyn_workorderid"))
                        {
                            service.Delete("msdyn_workorder", workorder.Id);
                        }
                        else
                        {
                            var Output = "No WorkOrders Details Found";
                        }
                    }
                    #endregion
                    #region///****Delete Lead *****///
                    EntityCollection GetLeadDetails = GetLead(service, K4_Vesselname);
                    foreach (var Lead in GetLeadDetails.Entities)
                    {
                        if (Lead.Attributes.Contains("leadid"))
                        {
                            service.Delete("lead", Lead.Id);
                        }
                        else
                        {
                            var Output = "No Lead Details Found";
                        }

                    }
                    #endregion
                    #region///****Delete Assets *****///
                    EntityCollection GetAssetsDetails = GetAssets(service, AccountId);
                    foreach (var Assets in GetAssetsDetails.Entities)
                    {
                        if (Assets.Attributes.Contains("msdyn_customerassetid"))
                        {
                            service.Delete("msdyn_customerasset", Assets.Id);
                        }
                        else
                        {
                            var Output = "No Asset Details Found";
                        }

                    }
                    #endregion
                    #region///****Delete Account *****///
                    EntityCollection GetAccountDetails = GetAccount(service, AccountId);
                    foreach (var account in GetAccountDetails.Entities)
                    {
                        if (account.Attributes.Contains("accountid"))
                        {
                            service.Delete("account", account.Id);
                        }
                        else
                        {
                            var Output = "No Account Details Found";
                        }

                    }
                    #endregion
                    #region///****Delete Billing Account *****///
                    EntityCollection GetBillingAccountDetails = GetBillingAccount(service, K4_Vesselname);
                    foreach (var Billingaccount in GetBillingAccountDetails.Entities)
                    {
                        if (Billingaccount.Attributes.Contains("accountid"))
                        {
                            service.Delete("account", Billingaccount.Id);
                        }
                        else
                        {
                            var Output = "No BillingAccount Details Found";
                        }

                    }
                    #endregion
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in Deleting Records Workflow: " + ex.Message.ToString());
            }
        }
        #endregion

        #region Getting opportunity Related Records
        private static EntityCollection GetInvoice(IOrganizationService service, string K4_Vesselname)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='invoice'>
                                <attribute name='name' />
                                <attribute name='invoiceid' />
                                <order attribute='name' descending='false' />
                                <filter type='and'>
                                <condition attribute='name' operator='eq' value='" + K4_Vesselname + @"' />
                                </filter>
                                </entity>
                                </fetch>";



            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetSaleOrder(IOrganizationService service, string K4_Vesselname)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                               <entity name='salesorder'>
                               <attribute name='name' />
                               <attribute name='customerid' />
                               <attribute name='statuscode' />
                               <attribute name='totalamount' />
                               <attribute name='salesorderid' />
                               <order attribute='name' descending='false' />
                               <filter type='and'>
                               <condition attribute='name' operator='eq' value='" + K4_Vesselname + @"' />
                               </filter>
                               </entity>
                               </fetch>";
                       
            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetQuote(IOrganizationService service, string K4_Vesselname)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='quote'>
                                <attribute name='name' />
                                <attribute name='customerid' />
                                <attribute name='quoteid' />
                                <order attribute='name' descending='false' />
                                <filter type='and'>
                                <condition attribute='name' operator='eq' value='" + K4_Vesselname + @"' />
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetOpportunity(IOrganizationService service, string K4_Vesselname)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='opportunity'>
                                <attribute name='name' />
                                <attribute name='customerid' />
                                <attribute name='estimatedvalue' />
                                <attribute name='statuscode' />
                                <attribute name='new_k4_quote' />
                                <attribute name='k4_invoice' />
                                <attribute name='opportunityid' />
                                <order attribute='name' descending='false' />
                                <filter type='and'>
                                <condition attribute='k4_vesselname' operator='eq' value='" + K4_Vesselname + @"' />
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetWorkOrder(IOrganizationService service, string K4_Vesselname)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='msdyn_workorder'>
                                <attribute name='msdyn_name' />
                                <attribute name='createdon' />
                                <attribute name='msdyn_serviceaccount' />
                                <attribute name='msdyn_workorderid' />
                                <order attribute='msdyn_name' descending='false' />
                                <link-entity name='account' from='accountid' to='msdyn_billingaccount' link-type='inner' alias='ad'>
                                <filter type='and'>
                                <condition attribute='k4_vesselname' operator='eq' value='" + K4_Vesselname + @"' />
                                </filter>
                                </link-entity>
                                </entity>
                                </fetch>";

            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetBooking(IOrganizationService service, string Workordernumber)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='bookableresourcebooking'>
                                <attribute name='createdon' />
                                <attribute name='starttime' />
                                <attribute name='resource' />
                                <attribute name='endtime' />
                                <attribute name='duration' />
                                <attribute name='bookingtype' />
                                <attribute name='bookingstatus' />
                                <attribute name='bookableresourcebookingid' />
                                <order attribute='starttime' descending='true' />
                                <filter type='and'>
                                <condition attribute='name' operator='eq' value='" + Workordernumber + @"' />
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetResource(IOrganizationService service, string Workordernumber)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='msdyn_resourcerequirement'>
                                <attribute name='msdyn_resourcerequirementid' />
                                <attribute name='msdyn_name' />
                                <attribute name='createdon' />
                                <order attribute='msdyn_name' descending='false' />
                                <filter type='and'>
                                <condition attribute='msdyn_name' operator='eq' value='" + Workordernumber + @"' />
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetLead(IOrganizationService service, string K4_Vesselname)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='lead'>
                                <attribute name='fullname' />
                                <attribute name='companyname' />
                                <attribute name='telephone1' />
                                <attribute name='leadid' />
                                <order attribute='fullname' descending='false' />
                                <filter type='and'>
                                <condition attribute='k4_vesselname' operator='eq' value='" + K4_Vesselname + @"' />
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetAccount(IOrganizationService service, string AccountId)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='account'>
                                <attribute name='name' />
                                <attribute name='primarycontactid' />
                                <attribute name='accountid' />
                                <order attribute='name' descending='false' />
                                <filter type='and'>
                                <condition attribute='accountid' operator='eq' value='{" + AccountId + @"}' />
                                </filter>
                                </entity>
                                </fetch>";



            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetAssets(IOrganizationService service, string AccountId)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='msdyn_customerasset'>
                                <attribute name='createdon' />
                                <attribute name='msdyn_product' />
                                <attribute name='msdyn_parentasset' />
                                <attribute name='msdyn_masterasset' />
                                <attribute name='msdyn_account' />
                                <attribute name='msdyn_name' />
                                <attribute name='msdyn_customerassetid' />
                                <order attribute='createdon' descending='true' />
                                <filter type='and'>
                                <condition attribute='msdyn_account' operator='eq' value='{" + AccountId + @"}' />
                                </filter>
                                </entity>
                                </fetch>";



            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        private static EntityCollection GetBillingAccount(IOrganizationService service, string K4_Vesselname)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='account'>
                                <attribute name='name' />
                                <attribute name='primarycontactid' />
                                <attribute name='accountid' />
                                <order attribute='name' descending='false' />
                                <filter type='and'>
                                <condition attribute='customertypecode' operator='eq' value='13' />
                                <condition attribute='k4_isparentaccount' operator='eq' value='1' />
                                <condition attribute='k4_vesselname' operator='eq' value='" + K4_Vesselname + @"' />
                                </filter>
                                </entity>
                                </fetch>";

            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        #endregion
    }
}

