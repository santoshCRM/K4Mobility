﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;
using System.Xml.Linq;
using Microsoft.Xrm.Sdk.Query;
using System.IO;
using Newtonsoft.Json;
using DocuSign.eSign.Api;
using DocuSign.eSign.Model;
using DocuSign.eSign.Client;
using System.Collections.Generic;


namespace K4MobWorkflows
{
   public class Docusign : CodeActivity
    {
        private string traceMessage;
        #region variable used
        [Input("invoiceid")]
        [RequiredArgument]
        [ReferenceTarget("invoice")]
        public InArgument<EntityReference> invoice { get; set; }

        [Input("Opportunityid")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> Opportunity { get; set; }


        private const string accessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjY4MTg1ZmYxLTRlNTEtNGNlOS1hZjFjLTY4OTgxMjIwMzMxNyJ9.eyJUb2tlblR5cGUiOjUsIklzc3VlSW5zdGFudCI6MTU3MjYwNjIxOCwiZXhwIjoxNTcyNjM1MDE4LCJVc2VySWQiOiJjMDVmYzU2My03ZDMyLTQwNDEtYWQ5MC1iZGJiYmU3ZGMwYzkiLCJzaXRlaWQiOjEsInNjcCI6WyJzaWduYXR1cmUiLCJjbGljay5tYW5hZ2UiLCJvcmdhbml6YXRpb25fcmVhZCIsImdyb3VwX3JlYWQiLCJwZXJtaXNzaW9uX3JlYWQiLCJ1c2VyX3JlYWQiLCJ1c2VyX3dyaXRlIiwiYWNjb3VudF9yZWFkIiwiZG9tYWluX3JlYWQiLCJpZGVudGl0eV9wcm92aWRlcl9yZWFkIiwiZHRyLnJvb21zLnJlYWQiLCJkdHIucm9vbXMud3JpdGUiLCJkdHIuZG9jdW1lbnRzLnJlYWQiLCJkdHIuZG9jdW1lbnRzLndyaXRlIiwiZHRyLnByb2ZpbGUucmVhZCIsImR0ci5wcm9maWxlLndyaXRlIiwiZHRyLmNvbXBhbnkucmVhZCIsImR0ci5jb21wYW55LndyaXRlIl0sImF1ZCI6ImYwZjI3ZjBlLTg1N2QtNGE3MS1hNGRhLTMyY2VjYWUzYTk3OCIsImlzcyI6Imh0dHBzOi8vYWNjb3VudC1kLmRvY3VzaWduLmNvbS8iLCJzdWIiOiJjMDVmYzU2My03ZDMyLTQwNDEtYWQ5MC1iZGJiYmU3ZGMwYzkiLCJhbXIiOlsiaW50ZXJhY3RpdmUiXSwiYXV0aF90aW1lIjoxNTcyNjA2MjE0LCJwd2lkIjoiYTQxMDEzOGUtNGRmMi00MjU2LWJkMmEtZGYzNjljNGE4ZTQzIn0.AcxT7fprdx8ZXLSiWx2Gz61NvylF6tn78NpbpO6Y9p_WiqJIot95IPB_V7yyrL4eMBxf0D2-v3MySFBYIohEJWS023Hxum_ldjBJm-I-2-9YE7GxF49PKEf8VsGOaBNPc_mh_LVYw-vVeh12_zL_RsiB53VHDE0hO0ayBZ_VZ95zD65E-08bolBJ3UI49v5svhXf8iGNOGZl21swKeHCq_jtrQts4JsSpltIb3UtbrJ7ku-RC1YxIJy2873iaEM0eLicR-umDn8o5MmbH9vhSta5vmESHrcrS8VuQLxueFR5F3GWpu61un8_LdOGC5UXBtMgEuYAq5CIbIRTBnTwbA";
        private const string accountId = "9203445";
        private const string signerName = "K4 Mobility";
        private const string signerEmail = "k4mobilityadm@gmail.com";
        private const string docName = "World_Wide_Corp_lorem.pdf";
        // Additional constants
        private const string signerClientId = "1000";
        private const string basePath = "https://demo.docusign.net/restapi";

        // Change the port number in the Properties / launchSettings.json file:
        //     "iisExpress": {
        //        "applicationUrl": "http://localhost:5050",
        private const string returnUrl = "http://localhost:5050/DSReturn";
        #endregion
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                EntityCollection EmailBody = getemailbody(service, Opportunity.Get<EntityReference>(executionContext).Id.ToString());
                Document document = new Document
                {
                    DocumentBase64 = Convert.ToBase64String(ReadContent(docName)),
                    Name = "Lorem Ipsum",
                    FileExtension = "pdf",
                    DocumentId = "1"
                };
                Document[] documents = new Document[] { document };

                // Create the signer recipient object 
                Signer signer = new Signer
                {
                    Email = signerEmail,
                    Name = signerName,
                    ClientUserId = signerClientId,
                    RecipientId = "1",
                    RoutingOrder = "1"
                };
                SignHere signHereTab = new SignHere
                {
                    DocumentId = "1",
                    PageNumber = "1",
                    RecipientId = "1",
                    TabLabel = "Sign Here Tab",
                    XPosition = "195",
                    YPosition = "147"
                };
                SignHere[] signHereTabs = new SignHere[] { signHereTab };

                // Add the sign here tab array to the signer object.
                signer.Tabs = new Tabs { SignHereTabs = new List<SignHere>(signHereTabs) };
                // Create array of signer objects
                Signer[] signers = new Signer[] { signer };
                // Create recipients object
                Recipients recipients = new Recipients { Signers = new List<Signer>(signers) };
                // Bring the objects together in the EnvelopeDefinition
                EnvelopeDefinition envelopeDefinition = new EnvelopeDefinition
                {
                    EmailSubject = "Please sign the document",
                    Documents = new List<Document>(documents),
                    Recipients = recipients,
                    Status = "sent"
                };
                // 2. Use the SDK to create and send the envelope
                ApiClient apiClient = new ApiClient(basePath);
                apiClient.Configuration.AddDefaultHeader("Authorization", "Bearer " + accessToken);
                EnvelopesApi envelopesApi = new EnvelopesApi(apiClient.Configuration);
                EnvelopeSummary results = envelopesApi.CreateEnvelope(accountId, envelopeDefinition);

                // 3. Create Envelope Recipient View request obj
                string envelopeId = results.EnvelopeId;
                RecipientViewRequest viewOptions = new RecipientViewRequest
                {
                    ReturnUrl = returnUrl,
                    ClientUserId = signerClientId,
                    AuthenticationMethod = "none",
                    UserName = signerName,
                    Email = signerEmail
                };

                // 4. Use the SDK to obtain a Recipient View URL
                ViewUrl viewUrl = envelopesApi.CreateRecipientView(accountId, envelopeId, viewOptions);

                // 5. Redirect the user's browser to the URL
                //return Redirect(viewUrl.Url);
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in OnCreatingLead workflow: " + ex.Message.ToString());
            }
        }

        internal static byte[] ReadContent(string fileName)
        {
            byte[] buff = null;
            string path = Path.Combine(Directory.GetCurrentDirectory(), "Resources", fileName);
            using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                using (BinaryReader br = new BinaryReader(stream))
                {
                    long numBytes = new FileInfo(path).Length;
                    buff = br.ReadBytes((int)numBytes);
                }
            }

            return buff;
        }
        private EntityCollection getemailbody(IOrganizationService service, string oppId)
        {
            string fetchQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                                "<entity name='email'>" +
                                "<attribute name='activityid' />" +
                                "<order attribute='subject' descending='false' />" +
                                "<filter type='and'>" +
                                "<condition attribute='regardingobjectid' operator='eq' value='{' + oppId + '}' />" +
                                "</filter>" +
                                "<link-entity name='activitymimeattachment' from='objectid' to='activityid' link-type='inner' alias='az'>" +
                                "< attribute name ='filename' /> " +
                                "<attribute name='body' />" +
                                "<attribute name='mimetype' />" +
                                "<filter type='and'>" +
                                "<condition attribute='filename' operator='eq' value='Terms and Conditions.pdf' />" +
                                "</filter>" +
                                "</link-entity>" +
                                "</entity>" +
                                "</fetch>";
                                                                              
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
     
    }
}



