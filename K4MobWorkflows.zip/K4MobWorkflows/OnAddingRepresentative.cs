﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.IO;
using System.Net;
using System.Text;


namespace K4MobWorkflows
{
    public class OnAddingRepresentative : CodeActivity
    {
        #region variable used
        [Input("EmployeeId")]
        [RequiredArgument]
        [ReferenceTarget("k4_employee")]
        public InArgument<EntityReference> Employee { get; set; }

        [Input("Emailaddress")]
        [RequiredArgument]
        [ReferenceTarget("k4_employee")]
        public InArgument<string> Emailaddress { get; set; }

        [Input("Name")]
        [RequiredArgument]
        [ReferenceTarget("k4_employee")]
        public InArgument<string> name { get; set; }

        [Input("Category")]
        [RequiredArgument]
        [ReferenceTarget("k4_employee")]
        public InArgument<string> Category { get; set; }

        [Input("MobileNumber")]
        [RequiredArgument]
        [ReferenceTarget("k4_employee")]
        public InArgument<string> MobileNumber { get; set; }

        [Input("Status")]
        [RequiredArgument]
        [ReferenceTarget("k4_employee")]
        public InArgument<string> status { get; set; }

        


        #endregion
        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Employee.Get<EntityReference>(executionContext) != null)
                {

                    var EmployeeId = Employee.Get<EntityReference>(executionContext).Id.ToString();
                    var EmailAddress = Convert.ToString(Emailaddress.Get<string>(executionContext).ToString());
                    var Name = Convert.ToString(name.Get<string>(executionContext).ToString());
                    var k4_Category = Convert.ToString(Category.Get<string>(executionContext).ToString());
                    var k4_MobileNumber = Convert.ToString(MobileNumber.Get<string>(executionContext).ToString());
                    var Status = Convert.ToString(status.Get<string>(executionContext).ToString());
                    //var K4_Imo = Convert.ToString(Imo.Get<string>(executionContext).ToString(), null);

                    #region 
                    string jsondata = "";
                    string jsonResult = "";
                    ///Dev Link
                    //HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://dev.k4mobility.co/newdev/crm_emp_update");
                    ///Prod Link
                    HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://webapp.k4mobility.com:5021/api/crm_emp_update");
                    jsondata = "{ \"K4_employeeid\":\"" + EmployeeId + "\",\"k4_name\":\"" + Name + "\",\"k4_emailaddress\":\"" + EmailAddress + "\",\"k4_category\":\"" + k4_Category + "\",\"k4_mobilenumber\":\"" + k4_MobileNumber + "\",\"k4_Status\":\"" + Status + "\"}";
                    Encoding encoding = new UTF8Encoding();
                    byte[] data = encoding.GetBytes(jsondata);
                    httpWReq.ProtocolVersion = HttpVersion.Version11;
                    httpWReq.Method = "POST";
                    httpWReq.KeepAlive = true;
                    httpWReq.ContentType = "application/json";
                    httpWReq.ContentLength = data.Length;
                    Stream stream = httpWReq.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                    string s = response.ToString();
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        jsonResult = reader.ReadToEnd();
                        reader.Close();
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in OnAddingEmployee workflow: " + ex.Message.ToString());
            }
        }
        #endregion

    }
}
