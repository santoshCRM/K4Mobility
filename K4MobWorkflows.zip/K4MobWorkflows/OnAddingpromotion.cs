﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.IO;
using System.Net;
using System.Text;

namespace K4MobWorkflows
{
    public class OnAddingpromotion : CodeActivity
    {
        #region variable used
        [Input("PromotionId")]
        [RequiredArgument]
        [ReferenceTarget("k4_promotion")]
        public InArgument<EntityReference> Promotion { get; set; }

        [Input("Status")]
        [RequiredArgument]
        [ReferenceTarget("k4_promotion")]
        public InArgument<string> status { get; set; }

        #endregion
        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Promotion.Get<EntityReference>(executionContext) != null)
                {
                    var PromotionId = Promotion.Get<EntityReference>(executionContext).Id.ToString();
                    var Status = Convert.ToString(status.Get<string>(executionContext).ToString());

                    #region 
                    string jsondata = "";
                    string jsonResult = "";
                    HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://dev.k4mobility.co/newdev/crm_emp_update");
                    jsondata = "{ \"promotionid\":\"" + PromotionId + "\",\"k4_Status\":\"" + Status + "\"}";
                    Encoding encoding = new UTF8Encoding();
                    byte[] data = encoding.GetBytes(jsondata);
                    httpWReq.ProtocolVersion = HttpVersion.Version11;
                    httpWReq.Method = "POST";
                    httpWReq.KeepAlive = true;
                    httpWReq.ContentType = "application/json";
                    httpWReq.ContentLength = data.Length;
                    Stream stream = httpWReq.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                    string s = response.ToString();
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        jsonResult = reader.ReadToEnd();
                        reader.Close();
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in OnCreatingLead workflow: " + ex.Message.ToString());
            }
        }
        #endregion

    }
}
