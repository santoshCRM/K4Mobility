﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Linq;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;

namespace K4MobWorkflows.WorkflowActivities
{
    public class OnCaseStatusChange : CodeActivity
    {
        #region variable used
        [Input("CaseId")]
        [RequiredArgument]
        [ReferenceTarget("incident")]
        public InArgument<EntityReference> Case { get; set; }

        
        [Input("Imo")]
        [RequiredArgument]
        [ReferenceTarget("incident")]
        public InArgument<string> Imo { get; set; }

        
        #endregion
        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Case.Get<EntityReference>(executionContext) != null)
                {

                    var IncidentId = Case.Get<EntityReference>(executionContext).Id.ToString();
                    var K4_Imo = Convert.ToString(Imo.Get<string>(executionContext).ToString(), null);
        
                    #region 
                    string jsondata = "";
                    string jsonResult = "";
                    HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://dev.k4mobility.co/newdev/crm_case_update");
                    jsondata = "{ \"opportunityid\":\"" + IncidentId + "\",\"k4_imo\":\"" + K4_Imo + "\"}";
                    Encoding encoding = new UTF8Encoding();
                    byte[] data = encoding.GetBytes(jsondata);
                    httpWReq.ProtocolVersion = HttpVersion.Version11;
                    httpWReq.Method = "POST";
                    httpWReq.KeepAlive = true;
                    httpWReq.ContentType = "application/json";
                    httpWReq.ContentLength = data.Length;
                    Stream stream = httpWReq.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                    string s = response.ToString();
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        jsonResult = reader.ReadToEnd();
                        reader.Close();
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in OnCreatingLead workflow: " + ex.Message.ToString());
            }
        }
        #endregion

    }
}


