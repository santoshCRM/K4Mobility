﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.IO;
using System.Net;
using System.Text;

namespace K4MobWorkflows.WorkflowActivities
{
    public class OnLeadCreation : CodeActivity
    {
        #region variable used
        [Input("Lead")]
        [RequiredArgument]
        [ReferenceTarget("lead")]
        public InArgument<EntityReference> Lead { get; set; }

        #endregion
        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Lead.Get<EntityReference>(executionContext) != null)
                {
                    var Leadid = Lead.Get<EntityReference>(executionContext).Id.ToString();
                    #region 
                    string jsondata = "";
                    string jsonResult = "";
                    ////Dev Link
                    //HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://dev.k4mobility.co/newdev/crm_lead");
                    ///Prod link
                    HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://webapp.k4mobility.com:5021/api/crm_lead");
                    jsondata = "{ \"leadid\":\"" + Leadid + "\"}";
                    Encoding encoding = new UTF8Encoding();
                    byte[] data = encoding.GetBytes(jsondata);
                    httpWReq.ProtocolVersion = HttpVersion.Version11;
                    httpWReq.Method = "POST";
                    httpWReq.KeepAlive = true;
                    httpWReq.Timeout = 15000;
                    httpWReq.ReadWriteTimeout = 32000;
                    httpWReq.ContentType = "application/json";
                    httpWReq.ContentLength = data.Length;
                    Stream stream = httpWReq.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                    string s = response.ToString();
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        jsonResult = reader.ReadToEnd();
                        reader.Close();
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in OnCreatingLead workflow: " + ex.Message.ToString());
            }
        }
       #endregion
    }
}



