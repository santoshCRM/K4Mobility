﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Linq;
using System;
using System.Activities;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;

namespace K4MobWorkflows.WorkflowActivities
{
    public class OnPortalStatusChange : CodeActivity
    {
        #region variable used
        [Input("Opportunity")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> Opportunity { get; set; }

        [Input("Portalstatus")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        //[AttributeTarget("opportunity", "k4_portalstatus")]
        public InArgument<string> PortalStatus { get; set; }

        [Input("Paylatercheck")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> Paylater { get; set; }

        [Input("PaymentStatus")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> PaymentStatus { get; set; }

        [Input("Imo")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> Imo { get; set; }

        [Input("VesselName")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> VesselName { get; set; }

        [Input("4gQuotaingb")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> Quotaingb { get; set; }

        [Input("VsatQuotaingb")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> VsatQuotaingb { get; set; }

        [Input("MIR")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> Mir { get; set; }

        [Input("CIR")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> Cir { get; set; }

        [Input("VsatRegion")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> VsatRegion { get; set; }

        [Input("4GRegion")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> Region { get; set; }

        [Input("4GOverageQuota")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> OverageQuota { get; set; }

        [Input("VstaOverageQuota")]
        [RequiredArgument]
        [ReferenceTarget("opportunity")]
        public InArgument<string> VsatOverageQuota { get; set; }

        //[Input("Activation Date")]
        //[RequiredArgument]
        //[ReferenceTarget("opportunity")]
        //public InArgument<DateTime> ActivationDate { get; set; }


        #endregion
        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Opportunity.Get<EntityReference>(executionContext) != null)
                {
                    
                    var OpportunityId = Opportunity.Get<EntityReference>(executionContext).Id.ToString();
                    var Portalstatus = Convert.ToString(PortalStatus.Get<string>(executionContext).ToString());
                    var PayLater = Convert.ToString(Paylater.Get<string>(executionContext).ToString(),null);
                    var Paymentstatus = Convert.ToString(PaymentStatus.Get<string>(executionContext).ToString(),null);
                    var K4_Imo = Convert.ToString(Imo.Get<string>(executionContext).ToString(),null);
                    var K4_VesselName = Convert.ToString(VesselName.Get<string>(executionContext).ToString(), null);
                    var K4_4GQuota = Convert.ToString(Quotaingb.Get<string>(executionContext),null);
                    var K4_VsatQuota = Convert.ToString(VsatQuotaingb.Get<string>(executionContext),null);
                    var K4_Mir = Convert.ToString(Mir.Get<string>(executionContext),null);
                    var K4_Cir = Convert.ToString(Cir.Get<string>(executionContext),null);
                    var K4_VsatRegion = Convert.ToString(VsatRegion.Get<string>(executionContext),null);
                    var K4_4gRegion =Convert.ToString(Region.Get<string>(executionContext),null); 
                    var K4_4gOverageQuota =Convert.ToString(OverageQuota.Get<string>(executionContext),null);
                    var K4_VsatOverageQuota = Convert.ToString(VsatOverageQuota.Get<string>(executionContext),null);
                    //DateTime K4_Activationdate = ActivationDate.Get<DateTime>(executionContext);

                    #region 
                    string jsondata = "";
                    string jsonResult = "";
                    //Dev Link
                    HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://dev.k4mobility.co/newdev/crm_update");
                    //Prodlink
                    //HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("https://webapp.k4mobility.com:5021/api/crm_update");
                    jsondata = "{ \"opportunityid\":\"" + OpportunityId + "\",\"k4_portalstatus\":\"" + Portalstatus + "\",\"k4_paylatercheck\":\"" + PayLater + "\"" + ",\"k4_paymentstatus\":\"" + Paymentstatus + "\",\"K4_vesselname\":\"" + K4_VesselName + "\",\"k4_imo\":\"" + K4_Imo + "\",\"k4_4gquotaingb\":\"" + K4_4GQuota + "\"" +",\"k4_vsatquotaingb\":\"" + K4_VsatQuota + "\"" + ",\"k4_mir\":\"" + K4_Mir + "\"" + ",\"k4_cir\":\"" + K4_Cir + "\"" + ",\"k4_4gregion\":\"" + K4_4gRegion + "\",\"k4_4goveragequotagb\":\"" + K4_4gOverageQuota + "\",\"k4_vsatoveragequotagb\":\"" + K4_VsatOverageQuota + "\",\"k4_vsatregion\":\"" + K4_VsatRegion + "\"}";
                    Encoding encoding = new UTF8Encoding();
                    byte[] data = encoding.GetBytes(jsondata);
                    httpWReq.ProtocolVersion = HttpVersion.Version11;
                    httpWReq.Method = "POST";
                    httpWReq.KeepAlive = true;
                    httpWReq.ContentType = "application/json";
                    httpWReq.ContentLength = data.Length;
                    Stream stream = httpWReq.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
                    string s = response.ToString();
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        jsonResult = reader.ReadToEnd();
                        reader.Close();
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in OnCreatingLead workflow: " + ex.Message.ToString());
            }
        }
        #endregion
       
    }
}
