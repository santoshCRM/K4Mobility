﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.IO;
using System.Net;
using System.Text;

namespace K4MobWorkflows
{
    public class UpdatePaymentstatus : CodeActivity
    {
        
        [Input("Account")]
        [RequiredArgument]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account { get; set; }

        [Input("VesselName")]
        [RequiredArgument]
        [ReferenceTarget("account")]
        public InArgument<string> VesselName { get; set; }



        string traceMessage = string.Empty;
        #region Execute
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Account.Get<EntityReference>(executionContext) != null)
                {
                    #region Deleting Opportunity Related Records
                    var AccountId = Account.Get<EntityReference>(executionContext).Id.ToString();
                    var K4_Vesselname = Convert.ToString(VesselName.Get<string>(executionContext).ToString(), null);
                    DateTime Periodstartdate;
                    EntityCollection GetPaymentDetails = GetAccount(service, AccountId);
                    foreach (var Payment in GetPaymentDetails.Entities)
                    {
                        if (Payment.Attributes.Contains("msdyn_date"))
                        {
                            Periodstartdate =(DateTime)Payment.Attributes["msdyn_date"];
                            if(Periodstartdate==DateTime.Today)
                            {

                            }
                        }
                        else
                        {
                            var Output = "No Account Details Found";
                        }

                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in Deleting Records Workflow: " + ex.Message.ToString());
            }
        }
        #endregion

        #region Getting opportunity Related Records
        private static EntityCollection GetAccount(IOrganizationService service, string AccountId)
        {
            string FormatXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                <entity name='msdyn_payment'>
                                <attribute name='createdon' />
                                <attribute name='msdyn_unappliedamount' />
                                <attribute name='msdyn_paymenttype' />
                                <attribute name='msdyn_paymentmethod' />
                                <attribute name='msdyn_date' />
                                <attribute name='msdyn_amount' />
                                <attribute name='msdyn_account' />
                                <attribute name='msdyn_paymentid' />
                                <order attribute='msdyn_date' descending='true' />
                                <filter type='and'>
                                <condition attribute='msdyn_account' operator='eq' value='{" + AccountId + @"}' />
                                <condition attribute='k4_periodstartdate' operator='next-month' />
                                </filter>
                                </entity>
                                </fetch>";


            EntityCollection result = service.RetrieveMultiple(new FetchExpression(FormatXML));
            return result;
        }
        #endregion
    }
}
