using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;

namespace K4Mobility.Assembly.Plugin
{
	public class Opportunity_OnPortalStatusChange : IPlugin
	{
		public void Execute(IServiceProvider serviceProvider)
		{
            IPluginExecutionContext executionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService((Guid?)executionContext.UserId);
            if (executionContext.Depth == 1 && executionContext.InputParameters.Contains("Target") &&
                executionContext.InputParameters["Target"] is Entity)
			{
                Entity Opportunity = executionContext.InputParameters["Target"] as Entity;
				try
				{
					if (Opportunity.GetAttributeValue<OptionSetValue>("k4_portalstatus") != null)
					{
						OptionSetValue k4_portalstatus =(OptionSetValue) Opportunity.Attributes["k4_portalstatus"];
						if (k4_portalstatus.Value == 636130001 || k4_portalstatus.Value == 636130002 || k4_portalstatus.Value == 636130004 ||
                            k4_portalstatus.Value == 636130009 || k4_portalstatus.Value == 636130006 || k4_portalstatus.Value == 636130007 ||
                            k4_portalstatus.Value == 636130003)
						{
                            ExecuteWorkflowRequest workflowRequest = new ExecuteWorkflowRequest();
                            workflowRequest.WorkflowId = new Guid("8916985C-6359-4733-9C5E-3A012A6E8A55");
                            workflowRequest.EntityId = Opportunity.Id;
                            service.Execute(workflowRequest);
						}
					}
				}
				catch (Exception ex)
				{
					throw new InvalidPluginExecutionException(ex.Message.ToString());
				}
			}
		}
	}
}
