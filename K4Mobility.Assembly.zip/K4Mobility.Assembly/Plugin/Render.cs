﻿using System;
using K4Mobility.Assembly.Plugin.Base;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Extensions;
namespace K4Mobility.Assembly.Plugin
{
    public class Render : K4Mobility.Assembly.Plugin.Base.Plugin
    {
        public Render(string unsecure, string secure) : base(unsecure, secure) { }

        public override void OnExecute(IPluginProvider provider)
        {
            // Get configuration values
            var resource = SecureConfig.GetValue("resource");
            var username = SecureConfig.GetValue("username");
            var password = SecureConfig.GetValue("password");

            var renderer = new Renderer(resource, username, password);

            var service = provider.OrganizationService;
            var context = provider.ExecutionContext;
            var trace = provider.LoggingService;
            var target = provider.Target;
            
              // Render the report
              var output = string.Empty;
            switch (target.LogicalName)
            {
                case "report":
                    var reportColumns = new ColumnSet("name","reportnameonsrs", "languagecode", "defaultfilter");
                    var report = service.Retrieve(target.LogicalName, target.Id, reportColumns);
                    var format = context.InputParameterOrDefault<string>("Format");
                    var email = context.InputParameterOrDefault<EntityReference>("Email");
                    var Quote = context.InputParameterOrDefault<EntityReference>("Quote");
                    var Order = context.InputParameterOrDefault<EntityReference>("Order");
                    var Invoice = context.InputParameterOrDefault<EntityReference>("Invoice");
                    var parameters = context.InputParameterOrDefault<string>("Parameters");
                    //parameter Example:-  P1:<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='quote'><all-attributes/><filter type='and'><condition attribute='quoteid' operator='eq' value='ReplaceRecordID'/></filter></entity></fetch>
                    if (parameters!=null)
                    {

                        if (parameters.Contains("ReplaceRecordID"))
                        {
                            if (Quote != null)
                                parameters = parameters.Replace("ReplaceRecordID", Quote.Id.ToString());
                            if (Order != null)
                                parameters = parameters.Replace("ReplaceRecordID", Order.Id.ToString());
                            if (Invoice != null)
                                parameters = parameters.Replace("ReplaceRecordID", Invoice.Id.ToString());
                        }
                    }
                    //trace.Write(parameters);
                     var rendered = renderer.RenderReport(report, format, parameters,  trace);
                    output = Convert.ToBase64String(rendered);
                    if (email!=null)//CreateEmailAttachment
                    {
                        Microsoft.Xrm.Sdk.Entity ActivityMimeAttachment = new Microsoft.Xrm.Sdk.Entity("activitymimeattachment");
                        ActivityMimeAttachment["subject"] = report.GetAttributeValue<string>("name");
                        ActivityMimeAttachment["filename"] = report.GetAttributeValue<string>("name") +".pdf";
                        ActivityMimeAttachment["body"] = output;
                        ActivityMimeAttachment["attachmentnumber"] = 1;
                        ActivityMimeAttachment["objectid"] = email;
                        ActivityMimeAttachment["objecttypecode"] = "email";
                        service.Create(ActivityMimeAttachment);
                    }

                        break;
                case "documenttemplate":
                    var templateColumns = new ColumnSet("documenttype", "associatedentitytypecode");
                    var template = service.Retrieve(target.LogicalName, target.Id, templateColumns);

                    switch (template.GetAttributeValue<OptionSetValue>("documenttype")?.Value)
                    {
                        case 1:
                            var savedView = Guid.Parse(context.InputParameterOrDefault<string>("ViewId"));
                            output = renderer.RenderExcelTemplate(template.Id, savedView);
                            break;
                        case 2:
                            var typeCode = template.GetAttributeValue<string>("associatedentitytypecode");
                            var metadata = service.GetEntityMetadata(typeCode);
                            var recordId = Guid.Parse(context.InputParameterOrDefault<string>("RecordId"));
                            output = renderer.RenderWordTemplate(template.Id, recordId, metadata.ObjectTypeCode ?? 0);
                            break;
                        default:
                            throw new Exception("Invalid document template type.");
                    }
                    break;
                default:
                    throw new Exception("Invalid input target.");
            }
            // Return as Base-64
            provider.ExecutionContext.OutputParameters["Output"] = output;
        }
    }
}
