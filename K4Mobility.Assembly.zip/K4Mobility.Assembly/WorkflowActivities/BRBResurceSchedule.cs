using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.ObjectModel;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class BRBResurceSchedule : CodeActivity
    {
        [RequiredArgument]
        [Input("ResourceId")]
        [ReferenceTarget("bookableresource")]
        public InArgument<EntityReference> ResourceId { get; set; }
        [Input("InstallationDate")]
        public InArgument<DateTime> InstallationDate { get; set; }

        [Output("StartTime")]
        public OutArgument<DateTime> StartTime { get; set; }

        [Output("EndTime")]
        public OutArgument<DateTime> EndTime { get; set; }
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            Guid userId = Guid.Empty;
            // DateTime instDate=;
            EntityReference resource = ResourceId.Get(executionContext);
            InstallationDate.Get(executionContext);
            if (resource != null && InstallationDate.Get(executionContext) != null)
            {
                userId = resource.Id;
                tracingService.Trace("GetHashCode Resource Id{0}", userId);
                String fetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
             "<entity name='bookableresourcebooking'>" +
               "<attribute name='createdon' />" +
               "<attribute name='starttime' />" +
               "<attribute name='endtime' />" +
               "<attribute name='duration' />" +
               "<attribute name='bookableresourcebookingid' />" +
               "<order attribute='endtime' descending='true' />" +
               "<filter type='and'>" +
                 "<condition attribute='resource' operator='eq' value='" + userId + "' />" +
                 "<condition attribute ='bookingstatus' operator='not-in'>" +
                 "<value uiname='Canceled'>0ADBF4E6-86CC-4DB0-9DBB-51B7D1ED4020</value>" +
                 "<value uiname='Completed'>C33410B9-1ABE-4631-B4E9-6E4A1113AF34</value>" +
                 "</condition>" +
                 "<condition attribute='endtime' operator='on-or-after' value='" + InstallationDate.Get(executionContext) + "' />" +
               "</filter>" +
               "</entity>" +
               "</fetch>";
                tracingService.Trace("Result {0}", fetch);
                EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetch));

                if (result.Entities.Count > 0)
                {
                    StartTime.Set(executionContext, result.Entities[0].Attributes["endtime"]);
                    EndTime.Set(executionContext, ((DateTime)result.Entities[0].Attributes["endtime"]).AddHours(2));
                    tracingService.Trace("Default value set in Start time{0} and Endtime{1}", StartTime, EndTime);
                }
                else
                {
                    StartTime.Set(executionContext, (DateTime)InstallationDate.Get(executionContext));
                    EndTime.Set(executionContext, ((DateTime)InstallationDate.Get(executionContext)).AddHours(2));
                    tracingService.Trace("Default value set in Start time{0} and Endtime{1}", (DateTime)InstallationDate.Get(executionContext), ((DateTime)InstallationDate.Get(executionContext)).AddHours(2));
                }

            }
        }
    }
}
