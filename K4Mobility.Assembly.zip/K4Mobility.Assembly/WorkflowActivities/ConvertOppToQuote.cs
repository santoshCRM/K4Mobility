﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class ConvertOppToQuote : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Opportunity")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> Opportunity { get; set; }

        [RequiredArgument]
        [Output("Quote")]
        [ReferenceTarget("quote")]
        public OutArgument<EntityReference> Quote { get; set; }
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Opportunity.Get<EntityReference>(executionContext) != null)
                {
                    var genQuoteFromOppRequest = new GenerateQuoteFromOpportunityRequest
                    {
                        OpportunityId = Opportunity.Get(executionContext).Id,
                        ColumnSet = new ColumnSet("quoteid", "name")
                    };

                    GenerateQuoteFromOpportunityResponse genQuoteFromOppResponse = (GenerateQuoteFromOpportunityResponse)
                        service.Execute(genQuoteFromOppRequest);
                    Quote.Set(executionContext, new EntityReference(genQuoteFromOppResponse.Entity.LogicalName,
                        genQuoteFromOppResponse.Entity.Id));
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in ConvertOppToQuote workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
