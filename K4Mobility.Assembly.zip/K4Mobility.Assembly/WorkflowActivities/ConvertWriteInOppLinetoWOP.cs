﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class ConvertWriteInOppLinetoWOP : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("msdyn_Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> msdyn_Product { get; set; }
        [RequiredArgument]
        [Input("msdyn_Unit")]
        [ReferenceTarget("uom")]
        public InArgument<EntityReference> msdyn_Unit { get; set; }
        [RequiredArgument]
        [Input("msdyn_WorkOrder")]
        [ReferenceTarget("msdyn_workorder")]
        public InArgument<EntityReference> msdyn_WorkOrder { get; set; }
        [RequiredArgument]
        [Input("msdyn_PriceList")]
        [ReferenceTarget("pricelevel")]
        public InArgument<EntityReference> msdyn_PriceList { get; set; }

        [RequiredArgument]
        [Input("Opportunity")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> Opportunity { get; set; }


        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
              

                if (Opportunity.Get<EntityReference>(executionContext) != null &&
                    msdyn_Product.Get<EntityReference>(executionContext) != null)
                {
                    // Get Write In Opportunity line.
                    EntityCollection opportunityproduct = getoppInfo(service, 
                        Opportunity.Get<EntityReference>(executionContext).Id.ToString());
                    Entity productType = service.Retrieve(msdyn_Product.Get<EntityReference>(executionContext).LogicalName, msdyn_Product.Get<EntityReference>(executionContext).Id, new ColumnSet("k4_productsubtype"));
                    foreach (Entity opline in opportunityproduct.Entities)
                    {
                        traceMessage += "In for each ";
                        Entity msdyn_workorderproduct = new Entity("msdyn_workorderproduct");
                        if (msdyn_Product.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_product"] = msdyn_Product.Get<EntityReference>(executionContext);
                        if (msdyn_Unit.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_unit"] = msdyn_Unit.Get<EntityReference>(executionContext);
                        if (msdyn_WorkOrder.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_workorder"] = msdyn_WorkOrder.Get<EntityReference>(executionContext);
                        if (msdyn_PriceList.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_pricelist"] = msdyn_PriceList.Get<EntityReference>(executionContext);
                        if (opline.Contains("OppProduct.quantity"))
                        {

                            int val = Convert.ToInt32(((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.quantity"]).Value);
                            msdyn_workorderproduct["msdyn_estimatequantity"] = (double)(val);
                            msdyn_workorderproduct["msdyn_quantity"] = (double)(val);
                            msdyn_workorderproduct["msdyn_qtytobill"] = (double)(val);
                        }
                        if (opline.Contains("OppProduct.manualdiscountamount"))
                        {

                            msdyn_workorderproduct["msdyn_estimatediscountamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.manualdiscountamount"]).Value;
                            msdyn_workorderproduct["msdyn_discountamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.manualdiscountamount"]).Value;
                        }
                        if (opline.Contains("OppProduct.baseamount"))
                        {
                            msdyn_workorderproduct["msdyn_estimateunitamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.baseamount"]).Value;
                            msdyn_workorderproduct["msdyn_unitamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.baseamount"]).Value;
                        }
                        if (opline.Contains("OppProduct.opportunityproductname"))
                            msdyn_workorderproduct["k4_writeinproductname"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.opportunityproductname"]).Value;

                        if (productType.Contains("k4_productsubtype"))
                            msdyn_workorderproduct["k4_productsubtype"] = productType.Attributes["k4_productsubtype"];
                        if (opline.Contains("OppProduct.k4_discountpercentage"))
                        {
                            msdyn_workorderproduct["msdyn_discountpercent"] = Convert.ToDouble(((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_discountpercentage"]).Value);
                            msdyn_workorderproduct["msdyn_estimatediscountpercent"] = Convert.ToDouble(((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_discountpercentage"]).Value);
                        }


                        if (opline.Contains("OppProduct.k4_taxpercentage"))
                            msdyn_workorderproduct["k4_taxpercentage"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_taxpercentage"]).Value;
                        if (opline.Contains("OppProduct.tax"))
                            msdyn_workorderproduct["k4_taxamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.tax"]).Value;
                        if (opline.Contains("OppProduct.k4_productvendor"))
                            msdyn_workorderproduct["k4_productvendor"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_productvendor"]).Value;
                        msdyn_workorderproduct["k4_opportunityproduct"] = new EntityReference("opportunityproduct", new Guid(((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.opportunityproductid"]).Value.ToString()));
                        service.Create(msdyn_workorderproduct);
                        traceMessage += "\n CreateWorkorderproduct Created";
                    }
                  
                   
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreateWorkorderproduct workflow: " + ex.Message.ToString());
            }

        }
        #endregion
        private EntityCollection getoppInfo(IOrganizationService service, string oppId)
        {
            string fetchQuery = "<fetch >" +
"  <entity name='opportunity' >" +
"    <filter>" +
"      <condition attribute='opportunityid' operator='eq' value='{" + oppId + "}' />" +
"    </filter>" +
"    <link-entity name='opportunityproduct' from='opportunityid' to='opportunityid' link-type='inner' alias='OppProduct' >" +

"      <attribute name='opportunityproductid' />" +
"      <attribute name='baseamount' />" +
"      <attribute name='extendedamount' />" +
"      <attribute name='opportunityproductname' />" +
"      <attribute name='k4_productsubtype' />" +
"      <attribute name='manualdiscountamount' />" +
"      <attribute name='k4_discountpercentage' />" +
"      <attribute name='k4_taxpercentage' />" +
"      <attribute name='tax' />" +
"      <attribute name='quantity' />" +
"      <filter>" +
"        <condition attribute='isproductoverridden' operator='eq' value='1' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
