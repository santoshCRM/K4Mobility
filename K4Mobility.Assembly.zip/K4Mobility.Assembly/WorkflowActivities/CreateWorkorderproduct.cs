﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreateWorkorderproduct : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("msdyn_Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> msdyn_Product { get; set; }
        [Input("Warehouse")]
        [ReferenceTarget("msdyn_warehouse")]
        public InArgument<EntityReference> Warehouse
        {
            get;
            set;
        }
        [RequiredArgument]
        [Input("msdyn_Unit")]
        [ReferenceTarget("uom")]
        public InArgument<EntityReference> msdyn_Unit { get; set; }
        [RequiredArgument]
        [Input("msdyn_WorkOrder")]
        [ReferenceTarget("msdyn_workorder")]
        public InArgument<EntityReference> msdyn_WorkOrder { get; set; }

        [RequiredArgument]
        [Input("msdyn_PriceList")]
        [ReferenceTarget("pricelevel")]
        public InArgument<EntityReference> msdyn_PriceList { get; set; }

        [RequiredArgument]
        [Input("msdyn_EstimateDiscountAmount")]
        public InArgument<Money> msdyn_EstimateDiscountAmount { get; set; }

        [RequiredArgument]
        [Input("msdyn_DiscountAmount")]
        public InArgument<Money> msdyn_DiscountAmount { get; set; }

        [RequiredArgument]
        [Input("msdyn_EstimateUnitAmount")]
        public InArgument<Money> msdyn_EstimateUnitAmount { get; set; }

        [RequiredArgument]
        [Input("msdyn_EstimateQuantity")]
        public InArgument<decimal> msdyn_EstimateQuantity { get; set; }

        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
              
                if (msdyn_Product.Get<EntityReference>(executionContext) != null)
                {
                    int val = Convert.ToInt32( msdyn_EstimateQuantity.Get(executionContext).ToString());
                   // throw new InvalidPluginExecutionException("test"+val.ToString());
                    for (int x = 1; x < val; x++)
                    {
                        traceMessage += "count"+x.ToString();
                        Entity msdyn_workorderproduct = new Entity("msdyn_workorderproduct");
                        if (msdyn_Product.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_product"] = msdyn_Product.Get<EntityReference>(executionContext);
                        if (msdyn_Unit.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_unit"] = msdyn_Unit.Get<EntityReference>(executionContext);
                        if (msdyn_WorkOrder.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_workorder"] = msdyn_WorkOrder.Get<EntityReference>(executionContext);
                        if (msdyn_PriceList.Get<EntityReference>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_pricelist"] = msdyn_PriceList.Get<EntityReference>(executionContext);
                        msdyn_workorderproduct["msdyn_estimatequantity"] = (double)(1);
                        msdyn_workorderproduct["msdyn_quantity"] = (double)(1);
                        msdyn_workorderproduct["msdyn_qtytobill"] = (double)(1);

                        if (msdyn_EstimateDiscountAmount.Get<Money>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_estimatediscountamount"] = msdyn_EstimateDiscountAmount.Get<Money>(executionContext);
                        if (msdyn_DiscountAmount.Get<Money>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_discountamount"] = msdyn_DiscountAmount.Get<Money>(executionContext);
                        if (msdyn_EstimateUnitAmount.Get<Money>(executionContext) != null)
                            msdyn_workorderproduct["msdyn_estimateunitamount"] = msdyn_EstimateUnitAmount.Get<Money>(executionContext);
                        if (Warehouse.Get<EntityReference>(executionContext) != null)
                        {
                            msdyn_workorderproduct.Attributes["msdyn_warehouse"] = Warehouse.Get<EntityReference>(executionContext);
                        }
                        service.Create(msdyn_workorderproduct);
                        traceMessage += "\n CreateWorkorderproduct Created";
                    }
                   
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreateWorkorderproduct workflow: " + ex.Message.ToString());
            }

        }
        #endregion
       
    }
}
