using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class GetOppLine : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[Input("ProductRef")]
		[ReferenceTarget("product")]
		public InArgument<EntityReference> ProductRef
		{
			get;
			set;
		}
        [Input("opportunity")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> opportunity
        {
            get;
            set;
        }

        [Output("opportunityproduct")]
        [ReferenceTarget("opportunityproduct")]
        public OutArgument<EntityReference> opportunityproduct
        {
            get;
            set;
        }


      
        #endregion
        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
			{
				traceMessage = "Workflow started.";
				tracingService.Trace(traceMessage);
				if (ProductRef.Get<EntityReference>(executionContext) != null && opportunity.Get<EntityReference>(executionContext) != null)
                {
                    string fetchQuery= "<fetch top='50' >" +
"  <entity name='opportunityproduct' >" +
"    <attribute name='opportunityproductid' />" +
"    <filter>" +
"      <condition attribute='productid' operator='eq' value='{" + ProductRef.Get<EntityReference>(executionContext) .Id+ "}' />" +
"      <condition attribute='opportunityid' operator='eq' value='{" + opportunity.Get<EntityReference>(executionContext).Id + "}' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
                    EntityCollection coll= service.RetrieveMultiple(new FetchExpression(fetchQuery));
                    if(coll.Entities.Count>0)
                    {
                        opportunityproduct.Set(executionContext, new EntityReference(coll.Entities[0].LogicalName, coll.Entities[0].Id));
                    }

				}
			}
			catch (Exception ex)
			{
				  tracingService.Trace(traceMessage);
				throw new InvalidPluginExecutionException("error occured in GetOppLine workflow: " + ex.Message.ToString());
			}
		}
	}
}
