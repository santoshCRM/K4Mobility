using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class GetRecordIDFromURL : CodeActivity
	{

        #region variable used
        private string traceMessage = string.Empty;

		[RequiredArgument]
		[Input("RecordURL")]
		public InArgument<string> RecordURL
		{
			get;
			set;
		}

		[RequiredArgument]
		[Output("RecordId")]
		public OutArgument<string> RecordId
		{
			get;
			set;
		}
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (RecordURL.Get<string>(executionContext) != null)
			{
				RecordId.Set(executionContext, RecordURL.Get<string>(executionContext).Substring(RecordURL.Get<string>(executionContext).IndexOf("&id=") + 4, 36));
			}
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in GetRecordIDFromURL workflow: " + ex.Message.ToString());
            }
        }
        #endregion
    }
}
