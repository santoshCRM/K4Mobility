using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.ObjectModel;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class UpdateCustomerAsset : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[RequiredArgument]
		[Input("Opportunity")]
		[ReferenceTarget("opportunity")]
		public InArgument<EntityReference> Opportunity
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("Originating Lead")]
		[ReferenceTarget("lead")]
		public InArgument<EntityReference> Lead
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("Account")]
		[ReferenceTarget("account")]
		public InArgument<EntityReference> Account
		{
			get;
			set;
		}
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Lead.Get<EntityReference>(executionContext) != null)
				{
					EntityReference MyLead = Lead.Get<EntityReference>(executionContext);
					string fetchQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>  <entity name='msdyn_customerasset'>    <attribute name='msdyn_customerassetid' />    <order attribute='createdon' descending='true' />    <filter type='and'>      <condition attribute='k4_lead' operator='eq'  uitype='lead' value='{" + MyLead.Id + "}'  />    </filter>  </entity></fetch>";
					traceMessage += "\n Fetching  Customer Asset.";
					EntityCollection msdyn_customerassets = service.RetrieveMultiple(new FetchExpression(fetchQuery));
					foreach (Entity msdyn_customerasset in msdyn_customerassets.Entities)
					{
						if (Opportunity.Get<EntityReference>(executionContext) != null)
						{
                            msdyn_customerasset.Attributes["k4_opportunity"]=Opportunity.Get<EntityReference>(executionContext);
						}
						if (Account.Get<EntityReference>(executionContext) != null)
						{
                            msdyn_customerasset.Attributes["msdyn_account"]=Account.Get<EntityReference>(executionContext);
						}
                        service.Update(msdyn_customerasset);
					}
				}
			}
			catch (Exception ex)
			{
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in UpdateCustomerAsset workflow: " + ex.Message.ToString());
			}
		}
        #endregion
    }
}
