using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class UpdateWorkOrderProduct : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[RequiredArgument]
		[Input("msdyn_workorderproduct")]
		[ReferenceTarget("msdyn_workorderproduct")]
		public InArgument<EntityReference> msdyn_workorderproduct
        {
			get;
			set;
		}

        [RequiredArgument]
        [Input("msdyn_Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> msdyn_Product { get; set; }

        [Input("Warehouse")]
        [ReferenceTarget("msdyn_warehouse")]
        public InArgument<EntityReference> Warehouse
        {
            get;
            set;
        }

        [Input("TaxPercentage")]
        public InArgument<string> PTaxPercentage
        {
            get;
            set;
        }
      
        [Input("DicountPercentage")]
        public InArgument<string> PDicountPercentage
        {
            get;
            set;
        }
		[Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}
        #endregion
        #region Execute  function

        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (msdyn_workorderproduct.Get<EntityReference>(executionContext) != null)
                {
                    Entity Mymsdyn_workorderproduct = new Entity(msdyn_workorderproduct.Get<EntityReference>(executionContext).LogicalName,
                        msdyn_workorderproduct.Get<EntityReference>(executionContext).Id);
                    decimal numD = Convert.ToDecimal("0.00");
                    decimal numT = Convert.ToDecimal("0.00");
                    Mymsdyn_workorderproduct.Attributes["msdyn_estimatediscountamount"] = new Money(numD);
                    Mymsdyn_workorderproduct.Attributes["msdyn_discountamount"] = new Money(numD);
                    Mymsdyn_workorderproduct.Attributes["k4_taxamount"] = new Money(numT);
                    if (Amount.Get<Money>(executionContext) != null)
                    {
                        traceMessage += "/n1";
                        if (PDicountPercentage.Get<string>(executionContext) != null)
                        {
                            numD = Convert.ToDecimal(PDicountPercentage.Get<string>(executionContext));
                            Mymsdyn_workorderproduct.Attributes["msdyn_discountpercent"] = numD;
                            Mymsdyn_workorderproduct.Attributes["msdyn_estimatediscountpercent"] = numD;
                            traceMessage += "/n2";
                        }
                        traceMessage += numD.ToString();
                        decimal num1 = Amount.Get<Money>(executionContext).Value * numD / 100m;
                        Mymsdyn_workorderproduct.Attributes["msdyn_estimatediscountamount"] = new Money(num1);
                        Mymsdyn_workorderproduct.Attributes["msdyn_discountamount"] = new Money(num1);
                        //Tax
                        if (PTaxPercentage.Get<string>(executionContext) != null)
                        {
                            traceMessage += "/n4";

                            numT = Convert.ToDecimal(PTaxPercentage.Get<string>(executionContext));
                            Mymsdyn_workorderproduct.Attributes["k4_taxpercentage"] = numT;
                        }

                        traceMessage += numT.ToString();
                        decimal num2 = (Amount.Get<Money>(executionContext).Value - num1) * numT / 100m;
                        Mymsdyn_workorderproduct.Attributes["k4_taxamount"] = new Money(num2);
                    }
                    if (Warehouse.Get<EntityReference>(executionContext) != null)
                    {
                        Mymsdyn_workorderproduct.Attributes["msdyn_warehouse"] = Warehouse.Get<EntityReference>(executionContext);
                    }

                        service.Update(Mymsdyn_workorderproduct);
                }
            }
			
			catch (Exception ex)
			{
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in UpdateWorkOrderProduct workflow: " + ex.Message.ToString());
			}
		}
        #endregion
    }
}
