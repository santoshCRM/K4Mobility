using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;

namespace K4Mobility.Assembly.Plugin
{
	public class Invoice_OnStatusReasonChange : IPlugin
	{
		public void Execute(IServiceProvider serviceProvider)
		{
			IPluginExecutionContext executionContext =(IPluginExecutionContext) serviceProvider.GetService(typeof(IPluginExecutionContext));
			IOrganizationServiceFactory serviceFactory =(IOrganizationServiceFactory) serviceProvider.GetService(typeof(IOrganizationServiceFactory));
			IOrganizationService service = serviceFactory.CreateOrganizationService((Guid?)executionContext.UserId);
			if (executionContext.Depth == 6 && executionContext.InputParameters.Contains("Target") && 
                executionContext.InputParameters["Target"] is Entity)
			{
				Entity Invoice = executionContext.InputParameters["Target"] as Entity;
				try
				{
					if (Invoice.GetAttributeValue<OptionSetValue>("statuscode") != null)
					{
						OptionSetValue statuscode = (OptionSetValue)Invoice.Attributes["statuscode"];
						if (statuscode.Value == 4)
						{
							ExecuteWorkflowRequest workflowRequest = new ExecuteWorkflowRequest();
                            workflowRequest.WorkflowId=new Guid("130D0E92-BC8D-E911-A95D-000D3AF2CB54");
                            workflowRequest.EntityId=Invoice.Id;
							service.Execute(workflowRequest);
						}
					}
				}
				catch (Exception ex)
				{
					throw new InvalidPluginExecutionException(ex.Message.ToString());
				}
			}
		}
	}
}
