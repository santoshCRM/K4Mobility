using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class GetOppLinetotalamount : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;

        [RequiredArgument]
        [Input("Opportunity")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> Opportunity
        {
            get;
            set;
        }

        [RequiredArgument]
        [Output("TotalExtendedAmount")]
        public OutArgument<decimal> TotalExtendedAmount
        {
            get;
            set;
        }
        #endregion
        #region Execute  function

        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Opportunity.Get<EntityReference>(executionContext) != null)
                {
                    decimal TotalAmount = 0.0m;
                    String fetch =
                        "<fetch top='50' aggregate='true' >" +
"  <entity name='opportunityproduct' >" +
"    <attribute name='extendedamount' alias='total' aggregate='sum' />" +
"    <filter>" +
"      <condition attribute='opportunityid' operator='eq' value='" + Opportunity.Get<EntityReference>(executionContext).Id + "' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
                    tracingService.Trace("Result {0}", fetch);
                    EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetch));
                    if (result.Entities.Count > 0)
                    {
                        TotalAmount = ((Microsoft.Xrm.Sdk.Money)((Microsoft.Xrm.Sdk.AliasedValue)result.Entities[0].Attributes["total"]).Value).Value;
                    }
                    TotalExtendedAmount.Set(executionContext, TotalAmount);

                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in GetOppLinetotalamount workflow: " + ex.Message.ToString());
            }
        }
        #endregion
    }
}
