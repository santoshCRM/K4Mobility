using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class GetTaxDiscountFromProduct : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		

        [Input("TaxPercentage")]
        public InArgument<string> TaxPercentage
        {
            get;
            set;
        }
        [Output("TaxAmount")]
        public OutArgument<Money> TaxAmount
        {
            get;
            set;
        }
        [Input("DicountPercentage")]
        public InArgument<string> DicountPercentage
        {
            get;
            set;
        }
        [Output("DicountAmount")]
        public OutArgument<Money> DicountAmount
        {
            get;
            set;
        }
        [RequiredArgument]
		[Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}
        [Output("ExtendedAmount")]
        public OutArgument<Money> ExtendedAmount
        {
            get;
            set;
        }
        #endregion
        #region Execute  function

        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
               
                    decimal numD = Convert.ToDecimal("0.00");
                    decimal numT = Convert.ToDecimal("0.00");
                decimal numA = Convert.ToDecimal("0.00");
                DicountAmount.Set(executionContext, new Money(0));
                TaxAmount.Set(executionContext, new Money(0));
                ExtendedAmount.Set(executionContext, new Money(0));
                if (Amount.Get<Money>(executionContext) != null)
                {
                    traceMessage += "/n1";
                    if (DicountPercentage.Get<string>(executionContext) != null)
                    {
                        numD = Convert.ToDecimal(DicountPercentage.Get<string>(executionContext));
                        traceMessage += "/n2";
                    }
                    traceMessage += numD.ToString();
                    decimal numDiscount = Amount.Get<Money>(executionContext).Value * numD / 100m;
                    DicountAmount.Set(executionContext, new Money(numDiscount));
                    //Tax
                    if (TaxPercentage.Get<string>(executionContext) != null)
                    {
                        traceMessage += "/n4";
                        numT = Convert.ToDecimal(TaxPercentage.Get<string>(executionContext));
                    }

                    traceMessage += numT.ToString();
                    decimal numTax = (Amount.Get<Money>(executionContext).Value - numDiscount) * numT / 100m;
                    TaxAmount.Set(executionContext, new Money(numTax));
                    ExtendedAmount.Set(executionContext, new Money(Amount.Get<Money>(executionContext).Value - numDiscount + numTax));
                }
                

            }
			
			catch (Exception ex)
			{
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in UpdateOpportunityLine workflow: " + ex.Message.ToString());
			}
		}
        #endregion
    }
}
