using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class PermanentSuspension : CodeActivity
    {
        #region variable used
        private string traceMessage = string.Empty;
        [RequiredArgument]
        [Input("Vessel Account")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account
        {
            get;
            set;
        }

        [RequiredArgument]
        [Input("Suspension Date")]
        public InArgument<DateTime> SuspensionDate
        {
            get;
            set;
        }
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Account.Get<EntityReference>(executionContext) != null && SuspensionDate.Get<DateTime>(executionContext) != null
                    )
                {
                    EntityCollection paymentInfo = getPaymentInfo(service, Account.Get<EntityReference>(executionContext).Id.ToString(),
                        SuspensionDate.Get<DateTime>(executionContext));

                    if (paymentInfo.Entities.Count > 0)
                    {
                        foreach (Entity payment in paymentInfo.Entities)//Deactivate future payments
                        {
                            payment["statecode"] = new OptionSetValue(1);//Status
                            payment["statuscode"] = new OptionSetValue(2);//Status Reason
                            service.Update(payment);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreatePayments workflow: " + ex.Message.ToString());
            }
        }
        #endregion
        private EntityCollection getPaymentInfo(IOrganizationService service, string AccId,DateTime suspensionDate)
        {
            string fetchQuery = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"  <entity name='msdyn_payment'>" +
"  " +
"    <attribute name='msdyn_paymentid' />" +
"   " +
"    <filter type='and'>" +
"      <condition attribute='msdyn_account' operator='eq'  value='{"+AccId+"}' />" +
"      <condition attribute='msdyn_date' operator='on-or-after' value='"+ suspensionDate.ToString("yyyy-MM-dd") +"' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }

    }
}
