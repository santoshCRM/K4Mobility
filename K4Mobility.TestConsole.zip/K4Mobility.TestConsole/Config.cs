﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using Microsoft.Xrm.Sdk;
namespace TestConsole
{
    public class Config
    {
        OrganizationServiceProxy serviceproxy = null;
     //  public string OrganizationUrl = "https://k4mobilitydev.api.crm8.dynamics.com/XRMServices/2011/Organization.svc";
        public string OrganizationUrl = "https://k4mobilityltdsb.api.crm8.dynamics.com/XRMServices/2011/Organization.svc";//Dev
        //public string OrganizationUrl = "https://tpp.crmcloud2011.com/XRMServices/2011/Organization.svc";
        //public string OrganizationUrl = "https://theparentpractice.api.crm11.dynamics.com/XRMServices/2011/Organization.svc";
        public ClientCredentials Credentials = null;
        public void CreateConnection()
        {
          


            Credentials = new ClientCredentials();
            Credentials.UserName.UserName = "admin@k4mobilityltd.onmicrosoft.com";
            Credentials.UserName.Password = "Abcd1436@#";
          
            //Credentials.UserName.UserName = "Admin1@theparentpractice.co.uk";
            //Credentials.UserName.Password = "Pa55w0rd1365";
            //Credentials.UserName.UserName = "john@theparentpractice.onmicrosoft.com";
            //Credentials.UserName.Password = "bU7u5e-r";
            try
            {
                decimal OverageRate = 40;
                decimal OverageSlabGB = 5;
                decimal DataSpentasOverageGB = 19;
                decimal TotalOverageCost = 0;
                TotalOverageCost = Math.Ceiling(DataSpentasOverageGB / OverageSlabGB) * OverageRate;
                Console.WriteLine("");
                //decimal baseamount = 2299;
                //decimal totalamount = 0;
                //int ContractDays = 55;
                //DateTime ActivationDate = new DateTime(2020, 2, 12);
                //DateTime DeActivationDate = new DateTime(2020, 4, 3);
                //int days = (DeActivationDate - ActivationDate).Days + 1;
                //totalamount = (days * baseamount) / DateTime.DaysInMonth(ActivationDate.Year,
                //            ActivationDate.Month);

                //int month = GetMonthDifference(ActivationDate, DeActivationDate);

                //if(month==0)//samemonth
                //{
                //    totalamount = (baseamount *days)/ DateTime.DaysInMonth(ActivationDate.Year, ActivationDate.Month);
                //}
                //else
                //{
                //    for(int x=0; x<month;x++)
                //    {
                //        if(x==month-1)//lastmonth
                //        {
                //            days = (DeActivationDate - new DateTime(DeActivationDate.Year, DeActivationDate.Month, 1)).Days;
                //            totalamount += (baseamount * days) / DateTime.DaysInMonth(ActivationDate.Year, ActivationDate.Month);
                //        }
                //        else if(x==0)//first month
                //        {
                //            days = (DateTime.DaysInMonth(ActivationDate.Year, ActivationDate.Month) -
                //                 ActivationDate.Day);
                //            totalamount += (baseamount * days) / DateTime.DaysInMonth(ActivationDate.Year, ActivationDate.Month);

                //        }
                //        else
                //        {
                //            days = DateTime.DaysInMonth(ActivationDate.AddMonths(x).Year, ActivationDate.AddMonths(x).Month);
                //            totalamount += (baseamount * days) / DateTime.DaysInMonth(ActivationDate.AddMonths(x).Year, ActivationDate.AddMonths(x).Month);
                //        }


                //    }

                //}
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ////  ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                //serviceproxy = new OrganizationServiceProxy(new Uri(OrganizationUrl), null, Credentials, null);
                //Guid orgId = ((WhoAmIResponse)serviceproxy.Execute(new WhoAmIRequest())).OrganizationId;
                ////Console.Write("connection success !!");
                //GetOppLinetotalamount GetOppLinetotalamount = new GetOppLinetotalamount();
                //GetOppLinetotalamount.Execute(serviceproxy);
                //CreatePaymentSchedule3 CreatePaymentSchedule3 = new CreatePaymentSchedule3();
                //CreatePaymentSchedule3.Execute(serviceproxy);
                //CreateMonthlyBilling CreateMonthlyBilling = new CreateMonthlyBilling();
                //CreateMonthlyBilling.Execute(serviceproxy);

                //ConvertWriteInOppLinetoWOP ConvertWriteInOppLinetoWOP = new ConvertWriteInOppLinetoWOP();
                //ConvertWriteInOppLinetoWOP.Execute(serviceproxy);
                //CreateQuoteLines CreateQuoteLines = new CreateQuoteLines();
                //CreateQuoteLines.Execute(serviceproxy);
                //CreateCase createCase = new CreateCase();
                //createCase.Execute(serviceproxy);
                //serviceproxy.Delete("activitymimeattachment", new Guid("BC73ED89-03BC-E611-94A9-001DD8B71D3B"));
                //Entity payment = new Entity("msdyn_payment", new Guid("e041bc17-b4c0-e911-a988-000d3af2c308"));
                //payment["statecode"] = new OptionSetValue(1);//Status
                //payment["statuscode"] = new OptionSetValue(2);//Status Reason
                //serviceproxy.Update(payment);
                // serviceproxy.Execute(setStateRequest);

                //DateTime current = new DateTime(2019, 8, 16);
                //int months = (int)3;
                //DateTime firstafterOneMonth = current.AddMonths(1).AddDays(1 - current.Day);
                //int Currentday = current.Day;
                //int Endday = DateTime.DaysInMonth(current.Year, current.Month); ;

                //decimal firstmonth_k4baseplancost = (0 * (Endday - Currentday)) / Endday;
                //decimal firstmonth_k4_associatedplancost = (10999 * (Endday - Currentday)) / Endday;
                //decimal firstmonth_k4_4gpackcost = (999 * (Endday - Currentday)) / Endday;
                //decimal firstmonth_k4_servicefee = (0 * (Endday - (Currentday - 1))) / Endday;
                //decimal Secondlastmonth_k4baseplancost = (0 * (Currentday - 1)) / Endday;
                //decimal Secondlastmonth_k4_associatedplancost = (10999 * (Currentday - 1)) / Endday;
                //decimal Secondlastmonth_k4_4gpackcost = (999 * (Currentday - 1)) / Endday;
                //decimal Secondlastmonth_k4_servicefee = (0 * (Currentday - 1)) / Endday;

                //int Start = 1;
                //int End = months - 2;
                //int days = 7;


                // CreatePayment cPayment = new CreatePayment();
                //cPayment.Execute(serviceproxy);
                //  StatusChangePayments updatePayment = new StatusChangePayments();
                //updatePayment.Execute(serviceproxy);
                //CreateContactProductPlan CreateContactProductPlan = new CreateContactProductPlan();
                //CreateContactProductPlan.Execute(serviceproxy);

                //CreatePaymentPlanChange3 CreatePaymentPlanChange3 = new CreatePaymentPlanChange3();
                //CreatePaymentPlanChange3.Execute(serviceproxy);
                //CreatePaymentSchedule CreatePaymentSchedule = new CreatePaymentSchedule();
                //CreatePaymentSchedule.Execute(serviceproxy);
                //PermanentSuspension PermanentSuspension = new PermanentSuspension();
                //PermanentSuspension.Execute(serviceproxy);
                //CloneProductExtra CloneProductExtra = new CloneProductExtra();
                //CloneProductExtra.Execute(serviceproxy);

                // CreateOppLine opline = new CreateOppLine();
                //opline.Execute(serviceproxy);
                //ConvertOppToQuote ConvertOppToQuote = new ConvertOppToQuote();
                //ConvertOppToQuote.Execute(serviceproxy);
                //ConvertQuoteToSalesOrder ConvertQuoteToSalesOrder = new ConvertQuoteToSalesOrder();
                //ConvertQuoteToSalesOrder.Execute(serviceproxy);

                // ConvertSalesOrderToInvoice ConvertSalesOrderToInvoice = new ConvertSalesOrderToInvoice();
                //ConvertSalesOrderToInvoice.Execute(serviceproxy);


                //CreateOrderVendorLines CreateOrderVendorLines = new CreateOrderVendorLines();
                //CreateOrderVendorLines.Execute(serviceproxy);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public static int GetMonthDifference(DateTime startDate, DateTime endDate)
        {
            int numMonths = 0;
           
            while (startDate.Year != endDate.Year || startDate.Month != endDate.Month)
            {
                startDate = startDate.AddMonths(1);
                numMonths++;
            }
            if(startDate.Year == endDate.Year && startDate.Month == endDate.Month)
            {
                numMonths++;
            }
            return numMonths;
        }



    }
}
