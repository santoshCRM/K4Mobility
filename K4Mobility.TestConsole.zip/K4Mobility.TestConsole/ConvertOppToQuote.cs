﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class ConvertOppToQuote
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference Opportunity = new EntityReference("opportunity", new Guid("7574638F-B6BC-E911-A963-000D3AF2CA3F"));
            #endregion

            if (Opportunity != null)
            {
                try
                {
                    // Convert the opportunity to a quote
                    var genQuoteFromOppRequest = new GenerateQuoteFromOpportunityRequest
                    {
                        OpportunityId = Opportunity.Id,
                        ColumnSet = new ColumnSet("quoteid", "name")
                    };

                    var genQuoteFromOppResponse = (GenerateQuoteFromOpportunityResponse)
                        service.Execute(genQuoteFromOppRequest);

                    Entity quote = genQuoteFromOppResponse.Entity;
                    Guid _quoteId = quote.Id; 

                    Console.WriteLine("Quote generated from the Opportunity.");

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }

    }
}
