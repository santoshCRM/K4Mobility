﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class ConvertSalesOrderToInvoice
    {
        public void Execute(IOrganizationService service)
        {
            
            #region Variable to Update
            EntityReference SalesOrder = new EntityReference("salesorder", new Guid("13b6db1e-8663-e911-a95d-000d3af2c610"));
            #endregion

            if (SalesOrder != null)
            {
                try
                {
                    #region Convert SalesOrder to Invoice

                    // Define columns to be retrieved after creating the invoice
                    ColumnSet invoiceColumns =
                        new ColumnSet("invoiceid", "totalamount");

                    // Convert the order to an invoice
                    ConvertSalesOrderToInvoiceRequest convertOrderRequest =
                        new ConvertSalesOrderToInvoiceRequest()
                        {
                            SalesOrderId = SalesOrder.Id,
                            ColumnSet = invoiceColumns
                        };
                    ConvertSalesOrderToInvoiceResponse convertOrderResponse =
                        (ConvertSalesOrderToInvoiceResponse)service.Execute(convertOrderRequest);
                    Entity invoice =convertOrderResponse.Entity;
                    Guid _invoiceId = invoice.Id;

                    Console.WriteLine("Converted SalesOrder to Invoice.");

                    #endregion

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }

    }
}
