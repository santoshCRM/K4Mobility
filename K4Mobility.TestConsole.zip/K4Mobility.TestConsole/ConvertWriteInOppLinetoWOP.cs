﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class ConvertWriteInOppLinetoWOP
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference msdyn_Product = new EntityReference("product", new Guid("E8F02910-8FD3-E911-A812-000D3A0A8282"));
            EntityReference msdyn_WorkOrder = new EntityReference("msdyn_workorder", new Guid("0B712D20-ADD3-E911-A812-000D3A0A8279"));
            EntityReference Opportunity = new EntityReference("opportunity", new Guid("0456320E-1BC8-E911-A811-000D3A0A8303"));
            EntityReference msdyn_Unit = new EntityReference("uom", new Guid("FF0AF513-B254-4936-8D74-ACF5043CF152"));
            EntityReference msdyn_PriceList = new EntityReference("pricelevel", new Guid("997155C4-CE3F-E911-A959-000D3AF2C610"));
            #endregion


            try
            {
                EntityCollection opportunityproduct = getoppInfo(service, Opportunity.Id.ToString());

               Entity productType= service.Retrieve(msdyn_Product.LogicalName, msdyn_Product.Id, new ColumnSet("k4_productsubtype"));
                foreach (Entity opline in opportunityproduct.Entities)
                {
                    Entity msdyn_workorderproduct = new Entity("msdyn_workorderproduct");
                    if (msdyn_Product != null)
                        msdyn_workorderproduct["msdyn_product"] = msdyn_Product;
                    if (msdyn_Unit != null)
                        msdyn_workorderproduct["msdyn_unit"] = msdyn_Unit;
                    if (msdyn_WorkOrder != null)
                        msdyn_workorderproduct["msdyn_workorder"] = msdyn_WorkOrder;
                    if (msdyn_PriceList != null)
                        msdyn_workorderproduct["msdyn_pricelist"] = msdyn_PriceList;
                    if (opline.Contains("OppProduct.quantity"))
                    {
                        
                        int val = Convert.ToInt32(((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.quantity"]).Value);
                        msdyn_workorderproduct["msdyn_estimatequantity"] = (double)(val);
                        msdyn_workorderproduct["msdyn_quantity"] = (double)(val);
                        msdyn_workorderproduct["msdyn_qtytobill"] = (double)(val);
                    }
                    if (opline.Contains("OppProduct.manualdiscountamount"))
                    {
                        
                        msdyn_workorderproduct["msdyn_estimatediscountamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.manualdiscountamount"]).Value;
                        msdyn_workorderproduct["msdyn_discountamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.manualdiscountamount"]).Value;
                    }
                    if (opline.Contains("OppProduct.baseamount"))
                    {
                        msdyn_workorderproduct["msdyn_estimateunitamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.baseamount"]).Value;
                        msdyn_workorderproduct["msdyn_unitamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.baseamount"]).Value;
                    }
                    if (opline.Contains("OppProduct.opportunityproductname"))
                        msdyn_workorderproduct["k4_writeinproductname"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.opportunityproductname"]).Value;

                    if (productType.Contains("k4_productsubtype"))
                        msdyn_workorderproduct["k4_productsubtype"] = productType.Attributes["k4_productsubtype"];
                    if (opline.Contains("OppProduct.k4_discountpercentage"))
                    {
                        msdyn_workorderproduct["msdyn_discountpercent"] = Convert.ToDouble(((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_discountpercentage"]).Value);
                        msdyn_workorderproduct["msdyn_estimatediscountpercent"] = Convert.ToDouble(((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_discountpercentage"]).Value);
                    }
                       
          
                    if (opline.Contains("OppProduct.k4_taxpercentage"))
                        msdyn_workorderproduct["k4_taxpercentage"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_taxpercentage"]).Value;
                    if (opline.Contains("OppProduct.tax"))
                        msdyn_workorderproduct["k4_taxamount"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.tax"]).Value;
                    if (opline.Contains("OppProduct.k4_productvendor"))
                        msdyn_workorderproduct["k4_productvendor"] = ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.k4_productvendor"]).Value;
                    msdyn_workorderproduct["k4_opportunityproduct"] =new EntityReference("opportunityproduct",new Guid( ((Microsoft.Xrm.Sdk.AliasedValue)opline.Attributes["OppProduct.opportunityproductid"]).Value.ToString())); 
                    service.Create(msdyn_workorderproduct);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            
        }
        private EntityCollection getoppInfo(IOrganizationService service, string oppId)
        {
            string fetchQuery = "<fetch >" +
"  <entity name='opportunity' >" +
"    <filter>" +
"      <condition attribute='opportunityid' operator='eq' value='{" + oppId + "}' />" +
"    </filter>" +
"    <link-entity name='opportunityproduct' from='opportunityid' to='opportunityid' link-type='inner' alias='OppProduct' >" +

"      <attribute name='opportunityproductid' />" +
"      <attribute name='baseamount' />" +
"      <attribute name='extendedamount' />" +
"      <attribute name='opportunityproductname' />" +
"      <attribute name='k4_productsubtype' />" +
"      <attribute name='manualdiscountamount' />" +
"      <attribute name='k4_discountpercentage' />" +
"      <attribute name='k4_taxpercentage' />" +
"      <attribute name='tax' />" +
"      <attribute name='quantity' />" +
"      <filter>" +
"        <condition attribute='isproductoverridden' operator='eq' value='1' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }

    }
}
