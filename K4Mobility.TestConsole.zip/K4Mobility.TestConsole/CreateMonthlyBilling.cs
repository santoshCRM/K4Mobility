﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class CreateMonthlyBilling
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference Account = new EntityReference("account", new Guid("D4F4EB84-4AC0-E911-A961-000D3AF2CB54"));
            DateTime DateFrom = new DateTime(2019, 10, 24).AddDays(1);
            float PlanDuration = 1;
            int months = (int)PlanDuration;
            int days = 7;
            #endregion

            EntityCollection customerAsset = getAccAsset(service, Account.Id.ToString());
            decimal k4_baseplancost = 0.0m;
            decimal k4_associatedplancost = 0.0m;
            decimal k4_4gpackcost = 0.0m;
            decimal k4_voipfee = 0.0m;
            decimal k4_4gactivationfee = 0.0m;
            decimal k4_activationfee = 0.0m;
            decimal k4_installationfee = 0.0m;
            decimal k4_hardwarecost = 0.0m;
            if (customerAsset.Entities.Count > 0)
            {
                var details = from so in (IEnumerable<Entity>)customerAsset.Entities
                              group so by ((Microsoft.Xrm.Sdk.AliasedValue)so.Attributes["Product.k4_productsubtype"]).Value into TotaledOrders
                              select new
                              {
                                  CustomerId = TotaledOrders.Key,
                                  TotalValue = TotaledOrders.Sum((Entity s) => ((Money)(s.Attributes["k4_extendedamount"])).Value),
                                  Orders = TotaledOrders.ToList()
                              };
                foreach (var item in details)
                {
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130000)//Subscription
                    {
                        k4_baseplancost = item.TotalValue;

                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130001)//Top Up Plan-VSAT
                    {
                        k4_associatedplancost = item.TotalValue;
                    }

                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130003)//Top Up Plan-4G
                    {
                        k4_4gpackcost = item.TotalValue;
                    }
                }
                CreateBillingInvoice(service,
                           Account, DateFrom,
                          new Money(Convert.ToDecimal("0.0")), new Money(k4_baseplancost),
               new Money(Convert.ToDecimal("0.0")), new Money(k4_associatedplancost),
               new Money(k4_4gpackcost), new Money(k4_voipfee), new Money(Convert.ToDecimal("0.0")),
               new Money(k4_baseplancost + k4_associatedplancost + k4_4gpackcost + k4_voipfee), 0, days,
                DateFrom.AddMonths(0).ToUniversalTime(), DateFrom.AddMonths(months).AddDays(-1).ToUniversalTime()
       , new Money(k4_4gactivationfee));

                    //Last payment-For overage
                    CreateBillingInvoice(service,
                   Account, DateFrom,
                  new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
       new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
       new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
       new Money(Convert.ToDecimal("0.0")), months, days,
         DateFrom.AddMonths(months).ToUniversalTime(), DateFrom.AddMonths(months).AddDays(-1).ToUniversalTime(),
         new Money(Convert.ToDecimal("0.0")));


                }
           

        }
        public void CreateBillingInvoice(IOrganizationService service,  EntityReference Account, DateTime ActivationDate,
            Money k4_installationfee, Money k4_baseplancost,
            Money k4_hardwarecost, Money k4_associatedplancost,
            Money k4_4gpackcost, Money k4_voipfee, Money k4_activationfee, Money amount, int month, int days,
            DateTime k4_periodstartdate, DateTime k4_periodenddate, Money k4_4gactivationfee)
        {
            Entity msdyn_payment = new Entity("msdyn_payment");
            msdyn_payment.Attributes["msdyn_account"] = Account;
            msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
            msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + ActivationDate.AddMonths(month).ToString("dd MMMM yyyy"));
            msdyn_payment.Attributes["msdyn_date"] = ActivationDate.AddMonths(month).ToUniversalTime();
            msdyn_payment.Attributes["k4_duedateforpayment"] = ActivationDate.AddMonths(month).AddDays(days).ToUniversalTime();
            msdyn_payment.Attributes["k4_periodstartdate"] = k4_periodstartdate;
            msdyn_payment.Attributes["k4_periodenddate"] = k4_periodenddate;
            msdyn_payment.Attributes["k4_installationfee"] = k4_installationfee;
            msdyn_payment.Attributes["k4_baseplancost"] = k4_baseplancost;
            msdyn_payment.Attributes["k4_hardwarecost"] = k4_hardwarecost;
            msdyn_payment.Attributes["k4_associatedplancost"] = k4_associatedplancost;
            msdyn_payment.Attributes["k4_4gpackcost"] = k4_4gpackcost;
            msdyn_payment.Attributes["k4_voipfee"] = k4_voipfee;
            msdyn_payment.Attributes["k4_activationfee"] = k4_activationfee;//VSAT activation fee
            msdyn_payment.Attributes["k4_4gactivationfee"] = k4_4gactivationfee;
            msdyn_payment.Attributes["k4_4goveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_vsatoveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_other"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["msdyn_amount"] = amount;
            service.Create(msdyn_payment);
        }
        private EntityCollection getAccAsset(IOrganizationService service, string accId)
        {
            string fetchQuery =
                "<fetch top='50' >" +
"  <entity name='msdyn_customerasset' alias='Asset' >" +
"    <attribute name='k4_extendedamount' />" +
"    <filter>" +
"      <condition attribute='msdyn_account' operator='eq' value='{" + accId + "}' />" +
" <condition attribute='k4_extendedamount' operator='not-null' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='msdyn_product' alias='Product' >" +
"      <attribute name='k4_productsubtype' />" +
"      <attribute name='productnumber' />" +
"      <filter>" +
"        <condition attribute='k4_productsubtype' operator='in' >" +
"          <value>636130000</value>" +
"          <value>636130001</value>" +
"          <value>636130003</value>" +
"        </condition>" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";


            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
