﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class CreateOrderVendorLines
    {
        public void Execute(IOrganizationService service)
        {

            #region Variable to Update
            EntityReference SalesOrder = new EntityReference("salesorder", new Guid("13C19ED7-DA65-E911-A96B-000D3AF2C6B2"));
            #endregion

            if (SalesOrder != null)
            {
                try
                {
                    //create order vendor lines

                    string fetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='salesorderdetail' >" +
"    <attribute name='salesorderdetailid' />" +
"    <order attribute='productid' descending='false' />" +
"    <filter type='and' >" +
"      <condition attribute='salesorderid' operator='eq' value='{" + SalesOrder.Id + "}' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='MyProduct' >" +
"      <attribute name='msdyn_defaultvendor' />" +
"      <filter type='and' >" +
"        <condition attribute='k4_productsubtype' operator='null' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";

                    EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetch));
                    var details = from r in result.Entities.AsEnumerable()
                                  group r by new
                                  {
                                      msdyn_defaultvendor = (((Microsoft.Xrm.Sdk.EntityReference)
                                      ((Microsoft.Xrm.Sdk.AliasedValue)r.Attributes["MyProduct.msdyn_defaultvendor"]).Value).Id)
                                  }
                                  into g
                                  select new
                                  {
                                      VendorId = g.Key.msdyn_defaultvendor
                                  };
                    foreach (var detail in details)
                    {
                        Entity k4_ordervendormapping = new Entity("k4_ordervendormapping");
                        k4_ordervendormapping.Attributes["k4_name"] = detail.VendorId.ToString();
                        k4_ordervendormapping.Attributes["k4_order"] = new EntityReference("salesorder",
                            SalesOrder.Id);
                        k4_ordervendormapping.Attributes["k4_vendor"] = new EntityReference("account",
                         detail.VendorId);
                     Guid k4_ordervendormappingId=  service.Create(k4_ordervendormapping);
                        var res = result.Entities.Where(e => (((Microsoft.Xrm.Sdk.EntityReference)
                                      ((Microsoft.Xrm.Sdk.AliasedValue)e.Attributes["MyProduct.msdyn_defaultvendor"]).Value).Id) == detail.VendorId);
                        foreach (var ent in res)
                        {
                            Entity salesorderdetail = new Entity("salesorderdetail", ent.Id);
                            salesorderdetail.Attributes["k4_ordervendormapping"] = new EntityReference("k4_ordervendormapping", k4_ordervendormappingId);
                            service.Update(salesorderdetail);
                        }

                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }

    }
}
