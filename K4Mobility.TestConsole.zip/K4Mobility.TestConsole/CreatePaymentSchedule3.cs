﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class CreatePaymentSchedule3
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference Opportunity = new EntityReference("opportunity", new Guid("E2D5E929-13EC-E911-A812-000D3AF2457D"));
            EntityReference Account = new EntityReference("account", new Guid("E1D5E929-13EC-E911-A812-000D3AF2457D"));
            DateTime ActivationDate = new DateTime(2019, 10, 11);
            float PlanDuration = 3;
            #endregion

            decimal k4_baseplancost = 0.0m;
            decimal k4_associatedplancost = 0.0m;
            decimal k4_4gpackcost = 0.0m;
            decimal k4_voipfee = 0.0m;
            decimal k4_4gactivationfee = 0.0m;
            decimal k4_activationfee = 0.0m;
            decimal k4_installationfee = 0.0m;
            decimal k4_hardwarecost = 0.0m;

            decimal k4_vsatoverageprice = 0.0m;
            decimal k4_4goverageprice = 0.0m;

            decimal k4_voiprate = 0.0m;

            decimal k4_Arrear = 0.0m;
            decimal k4_OldPlanAmount = 0.0m;
            decimal k4_NewPlanAmount = 0.0m;

            EntityReference k4_newvsatplan = null;
            EntityReference k4_new4gplan = null;
            EntityReference k4_newplan = null;

            EntityReference k4_vsat = null;
            EntityReference k4_4gplan = null;
            EntityReference k4_plan = null;


            EntityCollection customerAsset = getAccAsset(service, Account.Id.ToString());
            if (customerAsset.Entities.Count > 0)
            {
                foreach (Entity myasset in customerAsset.Entities)
                {
                    if (myasset.Attributes.Contains("k4_productsubtype") &&
                       ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130000)//Subscription
                    {
                        k4_baseplancost = ((Money)myasset.Attributes["k4_extendedamount"]).Value;
                        if (myasset.Contains("k4_voiprate"))
                        {
                            k4_voiprate = ((Money)myasset.Attributes["k4_voiprate"]).Value;
                        }
                        k4_plan = new EntityReference(myasset.LogicalName, myasset.Id);
                    }
                    if (myasset.Attributes.Contains("k4_productsubtype") &&
                       ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130001)//Top Up Plan-VSAT
                    {
                        k4_associatedplancost = ((Money)myasset.Attributes["k4_extendedamount"]).Value;
                        if (myasset.Contains("k4_vsatoverageprice"))
                        {
                            k4_vsatoverageprice =  ((Money)myasset.Attributes["k4_vsatoverageprice"]).Value;
                        }
                        k4_vsat = new EntityReference(myasset.LogicalName, myasset.Id);
                    }
                    if (myasset.Attributes.Contains("k4_productsubtype") &&
                       ((Microsoft.Xrm.Sdk.OptionSetValue)myasset.Attributes["k4_productsubtype"]).Value == 636130003)//Top Up Plan-4G
                    {
                        k4_4gpackcost = ((Money)myasset.Attributes["k4_extendedamount"]).Value;
                        if (myasset.Contains("k4_4goverageprice"))
                        {
                            k4_4goverageprice = ((Money)myasset.Attributes["k4_4goverageprice"]).Value;
                        }
                        k4_4gplan = new EntityReference(myasset.LogicalName, myasset.Id);
                    }
                }


                DateTime current = ActivationDate.ToUniversalTime().AddHours(5.5d);
                int months = (int)PlanDuration;
                int days = 7;
                for (int i = 1; i <= (months - 1); i++)
                {
                    CreateBillingInvoice(service, Opportunity,
                        Account, current,
                               new Money(Convert.ToDecimal("0.0")), new Money(k4_baseplancost),
                    new Money(Convert.ToDecimal("0.0")), new Money(k4_associatedplancost),
                    new Money(k4_4gpackcost), new Money(k4_voipfee), new Money(Convert.ToDecimal("0.0")),
                    new Money(k4_baseplancost + k4_associatedplancost + k4_4gpackcost + k4_voipfee), i, days,
                     current.AddMonths(i).ToUniversalTime(), current.AddMonths(i + 1).AddDays(-1).ToUniversalTime()
            , new Money(k4_4gactivationfee), new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_voiprate)
             , new Money(k4_Arrear), new Money(k4_OldPlanAmount), new Money(k4_NewPlanAmount)
            , k4_plan, k4_vsat, k4_4gplan,  k4_newplan,  k4_newvsatplan,  k4_new4gplan
            );

                }
                //Last payment-For overage
                CreateBillingInvoice(service, Opportunity,
                      Account, current,
                      new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
           new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
           new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")), new Money(Convert.ToDecimal("0.0")),
           new Money(Convert.ToDecimal("0.0")), months, days,
             current.AddMonths(months - 1).ToUniversalTime(), current.AddMonths(months).AddDays(-1).ToUniversalTime(),
             new Money(Convert.ToDecimal("0.0")), new Money(k4_vsatoverageprice), new Money(k4_4goverageprice), new Money(k4_voiprate)
              , new Money(k4_Arrear), new Money(k4_OldPlanAmount), new Money(k4_NewPlanAmount)
             , k4_plan, k4_vsat, k4_4gplan,  k4_newplan,  k4_newvsatplan,  k4_new4gplan
             );
            }

        }
        public void CreateBillingInvoice(IOrganizationService service, EntityReference Opportunity, EntityReference Account, DateTime ActivationDate,
              Money k4_installationfee, Money k4_baseplancost,
              Money k4_hardwarecost, Money k4_associatedplancost,
              Money k4_4gpackcost, Money k4_voipfee, Money k4_activationfee, Money amount, int month, int days,
              DateTime k4_periodstartdate, DateTime k4_periodenddate, Money k4_4gactivationfee,
               Money k4_vsatoverageprice, Money k4_4goverageprice, Money k4_voiprate
              , Money k4_arrear, Money k4_oldplanamount, Money k4_newplanamount
             , EntityReference k4_plan, EntityReference k4_vsat, EntityReference k4_4gplan
             , EntityReference k4_newplan, EntityReference k4_newvsatplan, EntityReference k4_new4gplan)
        {
            Entity msdyn_payment = new Entity("msdyn_payment");
            msdyn_payment.Attributes["msdyn_account"] = Account;
            msdyn_payment.Attributes["k4_opportunity"] = Opportunity;
            msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
            msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + ActivationDate.AddMonths(month).ToString("dd MMMM yyyy"));
            msdyn_payment.Attributes["msdyn_date"] = ActivationDate.AddMonths(month).ToUniversalTime();
            msdyn_payment.Attributes["k4_duedateforpayment"] = ActivationDate.AddMonths(month).AddDays(days).ToUniversalTime();
            msdyn_payment.Attributes["k4_periodstartdate"] = k4_periodstartdate;
            msdyn_payment.Attributes["k4_periodenddate"] = k4_periodenddate;
            msdyn_payment.Attributes["k4_installationfee"] = k4_installationfee;
            msdyn_payment.Attributes["k4_baseplancost"] = k4_baseplancost;
            msdyn_payment.Attributes["k4_hardwarecost"] = k4_hardwarecost;
            msdyn_payment.Attributes["k4_associatedplancost"] = k4_associatedplancost;
            msdyn_payment.Attributes["k4_4gpackcost"] = k4_4gpackcost;
            msdyn_payment.Attributes["k4_voipfee"] = k4_voipfee;
            msdyn_payment.Attributes["k4_activationfee"] = k4_activationfee;//VSAT activation fee
            msdyn_payment.Attributes["k4_4gactivationfee"] = k4_4gactivationfee;
            msdyn_payment.Attributes["k4_4goveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_vsatoveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_other"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["msdyn_amount"] = amount;

            msdyn_payment.Attributes["k4_vsatoverageprice"] = k4_vsatoverageprice;
            msdyn_payment.Attributes["k4_4goverageprice"] = k4_4goverageprice;
            msdyn_payment.Attributes["k4_voiprate"] = k4_voiprate;
            msdyn_payment.Attributes["k4_totalvoipcharges"] = new Money(Convert.ToDecimal("0.0"));


            msdyn_payment.Attributes["k4_arrear"] = k4_arrear;
            msdyn_payment.Attributes["k4_oldplanamount"] = k4_oldplanamount;
            msdyn_payment.Attributes["k4_newplanamount"] = k4_newplanamount;
            if (k4_plan != null)
                msdyn_payment.Attributes["k4_plan"] = k4_plan;
            if (k4_vsat != null)
                msdyn_payment.Attributes["k4_vsatplan"] = k4_vsat;
            if (k4_4gplan != null)
                msdyn_payment.Attributes["k4_4gplan"] = k4_4gplan;

            if (k4_newplan != null)
                msdyn_payment.Attributes["k4_newplan"] = k4_newplan;
            if (k4_newvsatplan != null)
                msdyn_payment.Attributes["k4_newvsatplan"] = k4_newvsatplan;
            if (k4_new4gplan != null)
                msdyn_payment.Attributes["k4_new4gplan"] = k4_new4gplan;

            service.Create(msdyn_payment);
        }


        private EntityCollection getAccAsset(IOrganizationService service, string accId)
        {
            string fetchQuery =
                "<fetch top='50' >" +
"  <entity name='msdyn_customerasset' alias='Asset' >" +
"    <attribute name='k4_extendedamount' />" +
"    <attribute name='k4_4goverageprice' />" +
"    <attribute name='k4_vsatoverageprice' />" +
"    <attribute name='k4_voiprate' />" +
"    <attribute name='k4_productsubtype' />" +
"    <filter>" +
"      <condition attribute='msdyn_account' operator='eq' value='{" + accId + "}' />" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
" <condition attribute='k4_extendedamount' operator='not-null' />" +
"        <condition attribute='k4_productsubtype' operator='in' >" +
"          <value>636130000</value>" +//Subscription
"          <value>636130001</value>" +//Top Up Plan-VSAT
"          <value>636130003</value>" +//Top Up Plan-4G
"        </condition>" +
"    </filter>" +
"  </entity>" +
"</fetch>";


            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
