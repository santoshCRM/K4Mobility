﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class CreateQuoteLines
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference ProductRef = new EntityReference("product", new Guid("645B1727-F181-E911-A95D-000D3AF2CB54"));
            EntityReference Quote = new EntityReference("quote", new Guid("0C7E89FD-BDCF-E911-A812-000D3A0A827E"));
            EntityReference CustomerAsset = new EntityReference("msdyn_customerasset", new Guid("864C008B-EEC7-E911-A811-000D3A0A830E"));
            #endregion

            if (ProductRef != null)
            {
                try
                {
                    Entity MyProduct = service.Retrieve(ProductRef.LogicalName,
                            ProductRef.Id, new ColumnSet(new string[1]
                        {
                            "defaultuomid"
                        }));
                    Entity quotedetail = new Entity("quotedetail");
                    quotedetail.Attributes["quoteid"] = Quote;
                    quotedetail.Attributes["productid"] = ProductRef;
                    quotedetail.Attributes["quantity"] = decimal.One;

                    if (CustomerAsset != null)
                    {
                        ColumnSet colset = new ColumnSet("k4_productsubtype", "k4_discountpercentage", "k4_discountamount",
                            "k4_taxamount",
                            "k4_taxpercentage", "k4_productvendor");
                        Entity res = service.Retrieve(CustomerAsset.LogicalName,
                               CustomerAsset.Id, colset);
                        if (res.Attributes.Contains("k4_taxpercentage"))
                            quotedetail.Attributes["k4_taxpercentage"] = res.Attributes["k4_taxpercentage"];

                        if (res.Attributes.Contains("k4_productsubtype"))
                            quotedetail.Attributes["k4_productsubtype"] = res.Attributes["k4_productsubtype"];

                        if (res.Attributes.Contains("k4_discountpercentage"))
                            quotedetail.Attributes["k4_discountpercentage"] = res.Attributes["k4_discountpercentage"];

                        if (res.Attributes.Contains("k4_discountamount"))
                            quotedetail.Attributes["manualdiscountamount"] = res.Attributes["k4_discountamount"];

                        if (res.Attributes.Contains("k4_taxamount"))
                            quotedetail.Attributes["tax"] = res.Attributes["k4_taxamount"];

                        if (res.Attributes.Contains("k4_productvendor"))
                            quotedetail.Attributes["k4_productvendor"] = res.Attributes["k4_productvendor"];


                    }
                    if (MyProduct.Attributes.Contains("defaultuomid"))
                    {
                        quotedetail.Attributes["uomid"] = MyProduct.Attributes["defaultuomid"];
                        Guid quotedetailId = service.Create(quotedetail);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }

    }
}
