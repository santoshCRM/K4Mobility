﻿function SetForm(executionContext) {
    debugger;
    var formContext = executionContext.getFormContext();
    var currentForm = formContext.ui.formSelector.getCurrentItem().getId();
    var Information;
    var cType;
    var forms;
    if (formContext.data.entity.attributes.get('customertypecode') != null
        && formContext.data.entity.attributes.get('customertypecode').getText() != null
    ) {
        cType = formContext.data.entity.attributes.get('customertypecode').getText().toLowerCase();
        forms = formContext.ui.formSelector.items.get();
        var i = 0;
        for (i = 0; i < forms.length; i++) {
            if (forms[i].getLabel().toLowerCase() == cType) {
                if (currentForm != forms[i].getId()) {
                    forms[i].navigate();
                }
                return;
            }
        }
    }
}