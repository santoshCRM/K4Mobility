﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreatePayments : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Contact")]
        [ReferenceTarget("contact")]
        public InArgument<EntityReference> Contact { get; set; }

        [RequiredArgument]
        [Input("StartDate")]
        public InArgument<DateTime> StartDate { get; set; }

        [Input("SubcriptionType")]
        [RequiredArgument]
        public InArgument<string> SubcriptionType { get; set; }


        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                if (Contact.Get<EntityReference>(executionContext) != null && StartDate.Get<DateTime>(executionContext) != null
                    && SubcriptionType.Get<string>(executionContext) != null
                    )
                {
                    if (SubcriptionType.Get<string>(executionContext) == "Monthly")
                    {
                        int paymentCount = 12 - StartDate.Get<DateTime>(executionContext).Month;

                        for (int x = 1; x <= paymentCount; x++)
                        {
                            Entity payment = new Entity("k4_paymentinformation");
                            payment.Attributes["k4_contact"] = Contact.Get<EntityReference>(executionContext);
                            payment.Attributes["k4_name"] = "Payment on - " + StartDate.Get<DateTime>(executionContext).AddMonths(x);
                            payment.Attributes["k4_paymentdate"] = StartDate.Get<DateTime>(executionContext).AddMonths(x).ToUniversalTime();
                            service.Create(payment);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreatePayments workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
