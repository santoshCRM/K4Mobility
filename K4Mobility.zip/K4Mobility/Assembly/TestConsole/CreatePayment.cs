﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class CreatePayment
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference order = new EntityReference("", new Guid(""));
            EntityReference Contact = new EntityReference("", new Guid(""));
           
            string SubcriptionType = "Monthly";
            DateTime StartDate=DateTime.Now;
            #endregion
            amount = getExdAmount(service, order.Id.ToString());
            if (SubcriptionType == "Monthly")
            {
                int paymentCount = 12 - StartDate.Month;

                for (int x = 1; x <= paymentCount; x++)
                {
                    Entity payment = new Entity("k4_paymentinformation");
                    payment.Attributes["k4_contact"] = Contact;
                    payment.Attributes["k4_order"] = order;
                    payment.Attributes["k4_name"] = "Payment on - " + StartDate.AddMonths(x);
                    payment.Attributes["k4_paymentdate"] = StartDate.AddMonths(x).ToUniversalTime();
                    payment.Attributes["k4_paymenttype"] = new OptionSetValue(636130003);
                    payment.Attributes["k4_amount"] = amount;
                    service.Create(payment);
                }
            }
            if (SubcriptionType == "Yearly")
            {
                Entity payment = new Entity("k4_paymentinformation");
                payment.Attributes["k4_contact"] = Contact;
                payment.Attributes["k4_order"] = order;
                payment.Attributes["k4_name"] = "Payment on - " + StartDate.AddYears(1);
                payment.Attributes["k4_paymentdate"] = StartDate.ToUniversalTime();
                payment.Attributes["k4_paymenttype"] = new OptionSetValue(636130003);
                payment.Attributes["k4_amount"] = amount;
                service.Create(payment);
            }
        }
        Money getExdAmount(IOrganizationService service, string salesorderid)
        {
            decimal damt = 0;
            Money amt = new Money(damt);
            string fetch = "<fetch top='1' >" +
"  <entity name='salesorderdetail' >" +
"    <attribute name='extendedamount' />" +
"    <attribute name='salesorderdetailid' />" +
"    <filter type='and' >" +
"      <condition attribute='salesorderid' operator='eq' value='{" + salesorderid + "}' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='a_5132182cc136e911a95a000d3af2c9f1' >" +
"      <filter type='and' >" +
"        <condition attribute='productstructure' operator='eq' value='3' />" +
"      </filter>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";

            var collection = service.RetrieveMultiple(new FetchExpression(fetch));
            if (collection.Entities.Count > 0)
            {
                if (collection.Entities[0].Attributes.Contains("extendedamount"))
                {
                    amt = (Microsoft.Xrm.Sdk.Money)collection.Entities[0].Attributes["extendedamount"];

                }

            }
            return amt;
        }

    }
}
