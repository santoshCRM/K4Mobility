using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class UpdateOpportunityLine : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[RequiredArgument]
		[Input("OpportunityLine")]
		[ReferenceTarget("opportunityproduct")]
		public InArgument<EntityReference> OpportunityLine
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("ProductSubType")]
		public InArgument<string> ProductSubType
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("TaxPercentage")]
		public InArgument<string> TaxPercentage
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("DicountPercentage")]
		public InArgument<string> DicountPercentage
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}
        #endregion
        #region Execute  function

        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (OpportunityLine.Get<EntityReference>(executionContext) != null)
				{
					Entity MyOpportunityLine = new Entity(OpportunityLine.Get<EntityReference>(executionContext).LogicalName,
                        OpportunityLine.Get<EntityReference>(executionContext).Id);
					if (ProductSubType.Get<string>(executionContext) != null)
					{
						if (ProductSubType.Get<string>(executionContext) == "Subscription")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130000);
						}
						else if (ProductSubType.Get<string>(executionContext) == "Top Up Plan-VSAT")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130001);
						}
						else if (ProductSubType.Get<string>(executionContext) == "HardWare")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130002);
						}
						else if (ProductSubType.Get<string>(executionContext) == "Top Up Plan-4G")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130003);
						}
						else if (ProductSubType.Get<string>(executionContext) == "Hardware Installation Fee")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130004);
						}
						else if (ProductSubType.Get<string>(executionContext) == "Activation Fee")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130005);
						}
						else if (ProductSubType.Get<string>(executionContext) == "Service Fee")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130006);
						}
						else if (ProductSubType.Get<string>(executionContext) == "Survey Fee")
						{
							MyOpportunityLine.Attributes["k4_productsubtype"]=new OptionSetValue(636130007);
						}
						traceMessage += ProductSubType.Get<string>(executionContext).ToString();
					}
					decimal num = Convert.ToDecimal("0.00");
					if (Amount.Get<Money>(executionContext) != null)
					{
						if (DicountPercentage.Get<string>(executionContext) != null)
						{
							traceMessage += DicountPercentage.Get<string>(executionContext).ToString();
							MyOpportunityLine.Attributes["k4_discountpercentage"]=Convert.ToDecimal(DicountPercentage.Get<string>(executionContext));
							num = Amount.Get<Money>(executionContext).Value *
                                Convert.ToDecimal(DicountPercentage.Get<string>(executionContext)) / 100m;
							MyOpportunityLine.Attributes["manualdiscountamount"]=new Money(num);
						}
						else
						{
							MyOpportunityLine.Attributes["k4_discountpercentage"]=num;
						}
						if (TaxPercentage.Get<string>(executionContext) != null)
						{
							traceMessage += TaxPercentage.Get<string>(executionContext).ToString();
							MyOpportunityLine.Attributes["k4_taxpercentage"]=Convert.ToDecimal(TaxPercentage.Get<string>(executionContext));
							decimal num2 = (Amount.Get<Money>(executionContext).Value - num) *
                                Convert.ToDecimal(TaxPercentage.Get<string>(executionContext)) / 100m;
							MyOpportunityLine.Attributes["tax"]=new Money(num2);
						}
						else
						{
							MyOpportunityLine.Attributes["k4_taxpercentage"]=Convert.ToDecimal("0.00");
						}
					}
					service.Update(MyOpportunityLine);
				}
			}
			catch (Exception ex)
			{
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in UpdateOpportunityLine workflow: " + ex.Message.ToString());
			}
		}
        #endregion
    }
}
