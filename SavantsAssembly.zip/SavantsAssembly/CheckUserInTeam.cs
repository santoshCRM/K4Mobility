﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SavantsAssembly
{
    public class CheckUserInTeam : CodeActivity
    {
        [Input("User")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> User { get; set; }

        [Input("Team")]
        [ReferenceTarget("team")]
        public InArgument<EntityReference> Team { get; set; }

        [Output("IsAvaliable")]
        [RequiredArgument]
        public OutArgument<bool> IsAvaliable { get; set; }


        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceservice = executionContext.GetExtension<ITracingService>();
            try
            {
                traceservice.Trace("Workflow started");
                IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                if (User.Get(executionContext) == null || Team.Get(executionContext) == null)
                {
                    IsAvaliable.Set(executionContext, false);
                }
                else  
                {
                    traceservice.Trace("Validate user team");
                    // get user team
                    EntityCollection teams = getTeam(Team.Get(executionContext).Id, User.Get(executionContext).Id, service);
                    if (teams.Entities.Count > 0)
                     IsAvaliable.Set(executionContext, true);
                    else
                        IsAvaliable.Set(executionContext, false);
                }
            }
            catch (Exception ex)
            {
                traceservice.Trace("Error occured: " + ex.ToString());
                throw new InvalidPluginExecutionException(ex.ToString());

            }


        }

        internal EntityCollection getTeam(Guid teamId, Guid systemUserId, IOrganizationService service)
        {
            string fetchXML =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='team'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='teamid' />"
    + "<attribute name='teamtype' />"
   + "    <filter>"+
"      <condition attribute='teamid' operator='eq'value='{" + teamId + "}'  />" +
"    </filter>"

    + "<order attribute='name' descending='false' />"
    + "<link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>"
      + "<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='ac'>"
        + "<filter type='and'>"
           + "<condition attribute='systemuserid' operator='eq' uitype='systemuser'  value='{" + systemUserId + "}' />"
        + "</filter>"
      + "</link-entity>"
    + "</link-entity>"
  + "</entity>"
+ "</fetch>";

            RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
            {
                Query = new FetchExpression(fetchXML)
            };

            EntityCollection returnCollection = ((RetrieveMultipleResponse)service.Execute(fetchRequest1)).EntityCollection;
            return returnCollection;


        }
    }
}
