﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SavantsAssembly
{
    public class GetUserTeam : IPlugin
    {
        [Input("User")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> User { get; set; }
       
        [Output("UserTeam")]
        [RequiredArgument]
        [ReferenceTarget("team")]
        public OutArgument<EntityCollection> UserTeam { get; set; }
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService traceservice = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceservice.Trace("Plugin started");
                EntityCollection teams=new EntityCollection();
                traceservice.Trace("get user team");

                if (context.InputParameters["User"] == null)
                    teams = getTeam(context.UserId, service, traceservice);
                else
                {
                    teams = getTeam(((EntityReference)context.InputParameters["User"]).Id, service, traceservice);

                }
                if (teams.Entities.Count > 0)
                    context.OutputParameters["UserTeam"] = teams;
                else
                    context.OutputParameters["UserTeam"] = null;
            }
            catch(Exception ex)
            {
                traceservice.Trace(ex.ToString());
                throw new InvalidPluginExecutionException(ex.ToString());
            }


            
        }



        internal EntityCollection getTeam(Guid systemUserId, IOrganizationService service, ITracingService traceservice)
        {
            string fetchXML =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='team'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='teamid' />"
    + "<attribute name='teamtype' />"
    + "<order attribute='name' descending='false' />"
    + "<link-entity name='teammembership' from='teamid' to='teamid' visible='false' intersect='true'>"
      + "<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='ac'>"
        + "<filter type='and'>"
           + "<condition attribute='systemuserid' operator='eq' uitype='systemuser'  value='{" + systemUserId + "}' />"
        + "</filter>"
      + "</link-entity>"
    + "</link-entity>"
  + "</entity>"
+ "</fetch>";
            traceservice.Trace(fetchXML.ToString());
            RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
            {
                Query = new FetchExpression(fetchXML)
            };

            EntityCollection returnCollection = ((RetrieveMultipleResponse)service.Execute(fetchRequest1)).EntityCollection;
            return returnCollection;


        }

      
    }
}
