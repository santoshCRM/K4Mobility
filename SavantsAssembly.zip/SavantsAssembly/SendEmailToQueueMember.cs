using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SavantsAssembly
{

    /// <summary>
    /// PluginEntryPoint plug-in.
    /// This is a generic entry point for a plug-in class. Use the Plug-in Registration tool found in the CRM SDK to register this class, import the assembly into CRM, and then create step associations.
    /// A given plug-in can have any number of steps associated with it. 
    /// </summary>    
    public class SendEmailToQueueMember : CodeActivity
    {
        #region Workflow Arguments
        [Input("Queue")]
        [RequiredArgument]
        [ReferenceTarget("queue")]
        public InArgument<EntityReference> Queue { get; set; }

        [Input("Email")]
        [RequiredArgument]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> Email { get; set; }


        #endregion
        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            traceService.Trace("Workflow Started");
            try
            {
                GetMember(service, Queue.Get(executionContext), Email.Get(executionContext));
                SendEmailRequest sendEmailreq = new SendEmailRequest
                {
                    EmailId = Email.Get(executionContext).Id,
                    TrackingToken = "",
                    IssueSend = true
                };

                SendEmailResponse sendEmailresp = (SendEmailResponse)service.Execute(sendEmailreq);

            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException("Error occured !!" + ex.Message.ToString());
            }
        }
        private void GetMember(IOrganizationService service, EntityReference Queue, EntityReference Email)
        {
            if (Queue != null)
            {
                try
                {


                    string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
"  <entity name='systemuser'>" +
"    <attribute name='fullname' />" +
"    <attribute name='systemuserid' />" +
"    <order attribute='fullname' descending='false' />" +
"    <link-entity name='queuemembership' from='systemuserid' to='systemuserid' visible='false' intersect='true'>" +
"      <link-entity name='queue' from='queueid' to='queueid' alias='ac'>" +
"        <filter type='and'>" +
"          <condition attribute='queueid' operator='eq'  value='{" + Queue.Id + "}' />" +
"        </filter>" +
"      </link-entity>" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
                    RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                    {
                        Query = new FetchExpression(fetchXML)
                    };

                    EntityCollection userRecords = ((RetrieveMultipleResponse)service.Execute(fetchRequest1)).EntityCollection;
                    EntityCollection to = new EntityCollection();
                    if (userRecords != null && userRecords.Entities != null && userRecords.Entities.Count > 0 && userRecords.Entities[0] != null)
                    {
                        Entity email = new Entity(Email.LogicalName, Email.Id);
                        foreach (Entity user in userRecords.Entities)
                        {
                            Entity toParty = new Entity("activityparty");
                            toParty.Attributes["partyid"] = new EntityReference(user.LogicalName, user.Id);
                            to.Entities.Add(toParty);
                        }
                        email.Attributes["to"] = to;
                        service.Update(email);
                    }

                }
                catch (Exception exc)
                {
                    throw new Exception("Error in GetMember function" + exc.ToString());
                }

            }

        }
    }
}
