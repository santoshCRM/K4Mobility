﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class ConvertQuoteToSalesOrder : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("Quote")]
        [ReferenceTarget("quote")]
        public InArgument<EntityReference> Quote { get; set; }

        [RequiredArgument]
        [Output("SalesOrder")]
        [ReferenceTarget("salesorder")]
        public OutArgument<EntityReference> SalesOrder { get; set; }
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Quote.Get<EntityReference>(executionContext) != null)
                {
                    #region Convert Quote to SalesOrder
                    ColumnSet salesOrderColumns =
                       new ColumnSet("salesorderid", "totalamount");
                    // Convert the quote to a sales order
                    ConvertQuoteToSalesOrderRequest convertQuoteRequest =
                        new ConvertQuoteToSalesOrderRequest()
                        {
                            QuoteId = Quote.Get(executionContext).Id,
                            ColumnSet = salesOrderColumns
                        };
                    ConvertQuoteToSalesOrderResponse convertQuoteResponse =
                        (ConvertQuoteToSalesOrderResponse)service.Execute(convertQuoteRequest);
                    SalesOrder.Set(executionContext, new EntityReference(convertQuoteResponse.Entity.LogicalName,
                        convertQuoteResponse.Entity.Id));
                    #endregion

                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in ConvertQuoteToSalesOrder workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
