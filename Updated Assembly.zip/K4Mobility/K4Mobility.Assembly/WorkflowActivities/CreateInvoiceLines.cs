using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{
	public class CreateInvoiceLines : CodeActivity
	{
        #region variable used
        private string traceMessage = string.Empty;

		[Input("ProductRef")]
		[ReferenceTarget("product")]
		public InArgument<EntityReference> ProductRef
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("ProductName")]
		public InArgument<string> ProductName
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("Amount")]
		public InArgument<Money> Amount
		{
			get;
			set;
		}

		[RequiredArgument]
		[Input("Invoice")]
		[ReferenceTarget("invoice")]
		public InArgument<EntityReference> Invoice
		{
			get;
			set;
		}
        #endregion
        protected override void Execute(CodeActivityContext executionContext)
		{
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
			{
				traceMessage = "Workflow started.";
				tracingService.Trace(traceMessage);
				if (Invoice.Get<EntityReference>(executionContext) != null)
				{
					if (ProductRef.Get<EntityReference>(executionContext) != null)
					{
						Entity MyProduct = service.Retrieve(ProductRef.Get<EntityReference>(executionContext).LogicalName,
                            ProductRef.Get<EntityReference>(executionContext).Id, new ColumnSet(new string[1]
						{
							"defaultuomid"
						}));
						Entity invoicedetail = new Entity("invoicedetail");
						invoicedetail.Attributes["invoiceid"]=Invoice.Get<EntityReference>(executionContext);
						invoicedetail.Attributes["productid"]=ProductRef.Get<EntityReference>(executionContext);
						invoicedetail.Attributes["quantity"]= decimal.One;
						traceMessage += "\n Step 1";
						if (MyProduct.Attributes.Contains("defaultuomid"))
						{
							traceMessage += "\n Primary unit found";
							invoicedetail.Attributes["uomid"]= MyProduct.Attributes["defaultuomid"];
							service.Create(invoicedetail);
							traceMessage += "\n opportunityproduct Created";
						}
					}
					else
					{
						traceMessage += "\n Step 1.1";
						Entity invoicedetail = new Entity("invoicedetail");
                        invoicedetail.Attributes["invoiceid"]= Invoice.Get<EntityReference>(executionContext);
						invoicedetail.Attributes["productdescription"]=ProductName.Get<string>(executionContext);
						invoicedetail.Attributes["quantity"]=decimal.One;
						invoicedetail.Attributes["isproductoverridden"]=true;
						invoicedetail.Attributes["priceperunit"]=Amount.Get<Money>(executionContext);
						service.Create(invoicedetail);
						traceMessage += "\n invoicedetail Created";
					}
				}
			}
			catch (Exception ex)
			{
				  tracingService.Trace(traceMessage);
				throw new InvalidPluginExecutionException("error occured in CreateInvoiceLines workflow: " + ex.Message.ToString());
			}
		}
	}
}
