﻿using System;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

namespace K4Mobility.Assembly.WorkflowActivities
{
    public class CreateOppLine : CodeActivity
    {

        #region variable used
        [RequiredArgument]
        [Input("ProductRef")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> ProductRef { get; set; }

        [RequiredArgument]
        [Input("Opportunity")]
        [ReferenceTarget("opportunity")]
        public InArgument<EntityReference> Opportunity { get; set; }
        string traceMessage = string.Empty;
        #endregion
        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (ProductRef.Get<EntityReference>(executionContext) != null && Opportunity.Get<EntityReference>(executionContext) != null)
                {
                    Entity Product = service.Retrieve(ProductRef.Get<EntityReference>(executionContext).LogicalName,
                                     ProductRef.Get<EntityReference>(executionContext).Id, new ColumnSet("defaultuomid"));

                    Entity opportunityproduct = new Entity("opportunityproduct");
                    opportunityproduct.Attributes["opportunityid"] = Opportunity.Get<EntityReference>(executionContext);
                    opportunityproduct.Attributes["productid"] = ProductRef.Get<EntityReference>(executionContext);
                    opportunityproduct.Attributes["quantity"] = (decimal)1;
                    traceMessage += "\n Step 1";
                    if (Product.Attributes.Contains("defaultuomid"))
                    {
                        traceMessage += "\n Primary unit found";
                        opportunityproduct.Attributes["uomid"] = Product.Attributes["defaultuomid"];
                        service.Create(opportunityproduct);
                        traceMessage += "\n opportunityproduct Created";
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in CreateOppLine workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
