﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace K4Mobility.Assembly.WorkflowActivities
{

    public class SendEmail: CodeActivity
    {
        private string traceMessage = string.Empty;

        [RequiredArgument]
        [Input("Email")]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> Email
        {
            get;
            set;
        }

        #region Execute  function
        protected override void Execute(CodeActivityContext executionContext)
        {
            //Create the tracing service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            try
            {
                traceMessage = "Workflow started.";
                tracingService.Trace(traceMessage);
                if (Email.Get<EntityReference>(executionContext) != null)
                {
                    SendEmailRequest SendEmailRequest = new SendEmailRequest();
                    SendEmailRequest.EmailId=(Email.Get<EntityReference>(executionContext).Id);
                    SendEmailRequest.TrackingToken="";
                    SendEmailRequest.IssueSend=(true);
                    SendEmailResponse Response =(SendEmailResponse) service.Execute(SendEmailRequest);

                }
                else
                    traceMessage += " No Record found to update.";
            }
            catch (Exception ex)
            {
                tracingService.Trace(traceMessage);
                throw new InvalidPluginExecutionException("error occured in SendEmail workflow: " + ex.Message.ToString());
            }

        }
        #endregion
    }
}
