﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class ConvertQuoteToSalesOrder
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference Quote = new EntityReference("quote", new Guid("B02A7880-8363-E911-A95D-000D3AF2CB54"));
            #endregion

            if (Quote != null)
            {
                try
                {

                   
                    #region Convert Quote to SalesOrder


                    // Define columns to be retrieved after creating the order
                    ColumnSet salesOrderColumns =
                        new ColumnSet("salesorderid", "totalamount");

                    // Convert the quote to a sales order
                    ConvertQuoteToSalesOrderRequest convertQuoteRequest =
                        new ConvertQuoteToSalesOrderRequest()
                        {
                            QuoteId = Quote.Id,
                            ColumnSet = salesOrderColumns
                        };
                    ConvertQuoteToSalesOrderResponse convertQuoteResponse =
                        (ConvertQuoteToSalesOrderResponse)service.Execute(convertQuoteRequest);
                    Entity salesOrder = convertQuoteResponse.Entity;
                    Guid _salesOrderId = salesOrder.Id;

                    Console.WriteLine("Converted Quote to SalesOrder.");

                    #endregion

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }

    }
}
