﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
  public  class CreateContactProductPlan
    {
        public void Execute(IOrganizationService service)
        {
            
            #region Variable to Update
            EntityReference order = new EntityReference("salesorder", new Guid("13C19ED7-DA65-E911-A96B-000D3AF2C6B2"));
            EntityReference Contact = new EntityReference("contact", new Guid("BED209AB-C165-E911-A95E-000D3AF2CA3F"));
            #endregion


            #region Contact Product Lines
            string fetchSubscrption = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"  <entity name='salesorderdetail'>" +
"    <attribute name='productid' />" +
"    <attribute name='extendedamount' />" +
"    <attribute name='quantity' />" +

"    <filter type='and'>" +
"      <condition attribute='salesorderid' operator='eq' value='{" + order.Id + "}' />" +
"    </filter>" +
"    <link-entity name='product' from='productid' to='productid' link-type='inner' alias='ab'>" +
"    <attribute name='k4_productsubtype' />" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            EntityCollection orderLines = service.RetrieveMultiple(new FetchExpression(fetchSubscrption));
            foreach (Entity orderline in orderLines.Entities)
            {
                if (orderline.Attributes.Contains("quantity"))
                {
                 decimal Quantity= (decimal)orderline.Attributes["quantity"];
                    for(int x=0;x<Quantity;x++)
                    {
                        Entity contactproductline = new Entity("k4_contactproductline");
                        contactproductline.Attributes["k4_contact"] = Contact;
                        if (orderline.Attributes.Contains("productid"))
                        {
                            contactproductline.Attributes["k4_name"] = ((EntityReference)orderline.Attributes["productid"]).Name;
                            contactproductline.Attributes["k4_product"] = ((EntityReference)orderline.Attributes["productid"]);
                        }
                        if (orderline.Attributes.Contains("ab.k4_productsubtype"))
                            contactproductline.Attributes["k4_productsubtype"] = new OptionSetValue(((Microsoft.Xrm.Sdk.OptionSetValue)((Microsoft.Xrm.Sdk.AliasedValue)orderline.Attributes["ab.k4_productsubtype"]).Value).Value);
                        // new OptionSetValue(636130000);
                        if (orderline.Attributes.Contains("extendedamount"))
                            contactproductline.Attributes["k4_amount"] = (Money)orderline.Attributes["extendedamount"];
                        service.Create(contactproductline);
                    }
                }
                    
            }
            #endregion
            
        }

    }
}
