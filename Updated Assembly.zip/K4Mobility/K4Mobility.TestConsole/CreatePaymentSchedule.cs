﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    public class CreatePaymentSchedule
    {
        public void Execute(IOrganizationService service)
        {
            Money amount = new Money();
            #region Variable to Update
            EntityReference Opportunity = new EntityReference("opportunity", new Guid("4E4B6F15-FFA9-E911-A961-000D3AF2CA3F"));
            EntityReference Account = new EntityReference("account", new Guid("4D4B6F15-FFA9-E911-A961-000D3AF2CA3F"));
            Money InstallationFee = new Money(Convert.ToDecimal("0.0"));
            DateTime ActivationDate = DateTime.Now;
            #endregion

            EntityCollection opportunityproduct = getoppInfo(service, Opportunity.Id.ToString());
            decimal k4_baseplancost = 0.0m;
            decimal k4_associatedplancost = 0.0m;
            decimal k4_4gpackcost = 0.0m;
            decimal k4_servicefee = 0.0m;
            if (opportunityproduct.Entities.Count > 0)
            {
                var details = from so in (IEnumerable<Entity>)opportunityproduct.Entities
                                 group so by ((Microsoft.Xrm.Sdk.AliasedValue) so.Attributes["OppProduct.k4_productsubtype"]).Value into TotaledOrders
                                 select new
                                 {
                                     CustomerId = TotaledOrders.Key,
                                     TotalValue = TotaledOrders.Sum((Entity s) => ((Money)((Microsoft.Xrm.Sdk.AliasedValue)s.Attributes["OppProduct.baseamount"]).Value).Value),
                                     Orders = TotaledOrders.ToList()
                                 };
                foreach (var item in details)
                {
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130000)//Subscription
                    {
                        k4_baseplancost = item.TotalValue;
                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130001)//Top Up Plan-VSAT
                    {
                        k4_associatedplancost = item.TotalValue;
                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130002)//HardWare
                    {
                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130003)//Top Up Plan-4G
                    {
                        k4_4gpackcost = item.TotalValue;
                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130004)// Hardware Installation Fee
                    {
                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130005)//Activation Fee
                    {
                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130006)//Service Fee
                    {
                        k4_servicefee = item.TotalValue;
                    }
                    if (((Microsoft.Xrm.Sdk.OptionSetValue)item.CustomerId).Value == 636130007)//Survey Fee
                    {
                    }
                }
            }
            int num9 = 1;
            int num10 = 2;
            int days = 7;
            for (int i = num9; i <= num10; i++)
            {
                CreateBillingInvoice(service, Opportunity, 
                    Account, ActivationDate, new Money(Convert.ToDecimal("0.0")), new Money(k4_baseplancost), 
                    new Money(Convert.ToDecimal("0.0")), new Money(k4_associatedplancost), 
                    new Money(k4_4gpackcost), new Money(k4_servicefee), new Money(Convert.ToDecimal("0.0")),
                    new Money(k4_baseplancost + k4_associatedplancost + k4_4gpackcost + k4_servicefee), i, days);
            }
        }
        public void CreateBillingInvoice(IOrganizationService service, EntityReference Opportunity, EntityReference Account, DateTime ActivationDate,
            Money InstallationFee, Money k4_baseplancost,
            Money k4_hardwarecost, Money k4_associatedplancost,
            Money k4_4gpackcost, Money k4_servicefee, Money k4_activationfee, Money amount, int month, int days)
        {
            Entity msdyn_payment = new Entity("msdyn_payment");
            msdyn_payment.Attributes["msdyn_account"] = Account;
            msdyn_payment.Attributes["k4_opportunity"] = Opportunity;
            msdyn_payment.Attributes["msdyn_paymenttype"] = new OptionSetValue(690970002);
            msdyn_payment.Attributes["msdyn_name"] = ("Billing Invoice - " + ActivationDate.AddMonths(month).ToUniversalTime().ToString());
            msdyn_payment.Attributes["msdyn_date"] = ActivationDate.AddMonths(month).ToUniversalTime();
            msdyn_payment.Attributes["k4_duedateforpayment"] = ActivationDate.AddMonths(month).AddDays(days).ToUniversalTime();
            msdyn_payment.Attributes["k4_installationfee"] = InstallationFee;
            msdyn_payment.Attributes["k4_baseplancost"] = k4_baseplancost;
            msdyn_payment.Attributes["k4_hardwarecost"] = k4_hardwarecost;
            msdyn_payment.Attributes["k4_associatedplancost"] = k4_associatedplancost;
            msdyn_payment.Attributes["k4_4gpackcost"] = k4_4gpackcost;
            msdyn_payment.Attributes["k4_servicefee"] = k4_servicefee;
            msdyn_payment.Attributes["k4_activationfee"] = k4_activationfee;
            msdyn_payment.Attributes["k4_4goveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_vsatoveragecost"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["k4_other"] = new Money(Convert.ToDecimal("0.0"));
            msdyn_payment.Attributes["msdyn_amount"] = amount;
            service.Create(msdyn_payment);
        }
            private EntityCollection getoppInfo(IOrganizationService service, string oppId)
        {
            string fetchQuery = "<fetch top='50' >  <entity name='opportunity' >    <filter>      <condition attribute='opportunityid' operator='eq'  value='{" + oppId + "}' />    </filter>    <link-entity name='opportunityproduct' from='opportunityid' to='opportunityid' link-type='inner' alias='OppProduct' >      <attribute name='baseamount' />      <attribute name='k4_productsubtype' />    </link-entity>  </entity></fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchQuery));
        }
    }
}
