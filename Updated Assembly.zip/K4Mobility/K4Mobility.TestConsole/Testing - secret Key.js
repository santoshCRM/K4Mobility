﻿'use strict';
var https = require('https');

//set these values to retrieve the oauth token
var crmorg = 'https://k4mobilityltdsb.crm8.dynamics.com';
//Application ID
var clientid = 'f5220755-0fce-4e12-b180-8077cd262ba9';
var Client_secret = 'AAkCRQVfsIAx7VWQV0VFfPcamsS0FfaTSYmndtdGy4U=';
//var username = 'admin@k4mobilityltd.onmicrosoft.com';
//var userpassword = 'K4Mobility@123';
var tokenendpoint = 'https://login.microsoftonline.com/6a9fbffa-96d5-47ff-843d-3a291cc10465/oauth2/token';

//set these values to query your crm data
var crmwebapihost = 'k4mobilityltdsb.api.crm8.dynamics.com';
//var crmwebapipath = '/api/data/v9.1/contacts?$select=fullname,contactid'; //basic query to select contacts
var ProductID = '8382041F-7450-E911-A95D-000D3AF2C9D4'
var fetchQuery = "%3Cfetch%20top%3D%2250%22%3E%0A%3Centity%20name%3D%22dynamicproperty%22%3E%0A%3Cattribute%20name%3D%22defaultvaluestring%22%2F%3E%0A%3Cattribute%20name%3D%22name%22%2F%3E%0A%3Cfilter%3E%0A%3Ccondition%20attribute%3D%22statecode%22%20operator%3D%22eq%22%20value%3D%220%22%2F%3E%0A%3Ccondition%20attribute%3D%22statuscode%22%20operator%3D%22eq%22%20value%3D%221%22%2F%3E%0A%3C%2Ffilter%3E%0A%3Clink-entity%20name%3D%22product%22%20from%3D%22parentproductid%22%20to%3D%22regardingobjectid%22%20alias%3D%22Product%22%3E%0A%3Cattribute%20name%3D%22name%22%2F%3E%0A%3Cattribute%20name%3D%22productid%22%2F%3E%0A%3Cfilter%3E%0A%3Ccondition%20attribute%3D%22statuscode%22%20operator%3D%22eq%22%20value%3D%221%22%2F%3E%0A%3Ccondition%20attribute%3D%22k4_productsubtype%22%20operator%3D%22eq%22%20value%3D%22636130000%22%2F%3E%0A%3C%2Ffilter%3E%0A%3C%2Flink-entity%3E%0A%3C%2Fentity%3E%0A%3C%2Ffetch%3E";
var crmwebapipath = '/api/data/v9.1/dynamicproperties?fetchXml=' + fetchQuery;

//remove https from tokenendpoint url
tokenendpoint = tokenendpoint.toLowerCase().replace('https://', '');

//get the authorization endpoint host name
var authhost = tokenendpoint.split('/')[0];

//get the authorization endpoint path
var authpath = '/' + tokenendpoint.split('/').slice(1).join('/');

//build the authorization request
//if you want to learn more about how tokens work, see IETF RFC 6749 - https://tools.ietf.org/html/rfc6749
var reqstring = 'client_id=' + clientid;
reqstring += '&resource=' + encodeURIComponent(crmorg);
reqstring += '&client_secret=' + Client_secret;
reqstring += '&grant_type=client_credentials';

//set the token request parameters
var tokenrequestoptions = {
    host: authhost,
    path: authpath,
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(reqstring)
    }
};

//make the token request
var tokenrequest = https.request(tokenrequestoptions, function (response) {
    //make an array to hold the response parts if we get multiple parts
    var responseparts = [];
    response.setEncoding('utf8');
    response.on('data', function (chunk) {
        //add each response chunk to the responseparts array for later
        responseparts.push(chunk);
    });
    response.on('end', function () {
        //once we have all the response parts, concatenate the parts into a single string
        var completeresponse = responseparts.join('');
        //console.log('Response: ' + completeresponse);
        console.log('Token response retrieved . . . ');

        //parse the response JSON
        var tokenresponse = JSON.parse(completeresponse);
        console.log(tokenresponse);
        //extract the token
        var token = tokenresponse.access_token;

        //pass the token to our data retrieval function
        getData(token);
    });
});
tokenrequest.on('error', function (e) {
    console.error(e);
});

//post the token request data
tokenrequest.write(reqstring);

//close the token request
tokenrequest.end();


function getData(token) {
    //set the web api request headers
    var requestheaders = {
        'Authorization': 'Bearer ' + token,
        'OData-MaxVersion': '4.0',
        'OData-Version': '4.0',
        'Accept': 'application/json',
        'Content-Type': 'application/json; charset=utf-8',
        'Prefer': 'odata.maxpagesize=500',
        'Prefer': 'odata.include-annotations=OData.Community.Display.V1.FormattedValue'
    };

    //set the crm request parameters
    var crmrequestoptions = {
        host: crmwebapihost,
        path: crmwebapipath,
        method: 'GET',
        headers: requestheaders
    };

    //make the web api request
    var crmrequest = https.request(crmrequestoptions, function (response) {
        //make an array to hold the response parts if we get multiple parts
        var responseparts = [];
        response.setEncoding('utf8');
        response.on('data', function (chunk) {
            //add each response chunk to the responseparts array for later
            console.log("chunk");
            responseparts.push(chunk);
        });

        response.on('end', function () {
            //once we have all the response parts, concatenate the parts into a single string
            var completeresponse = responseparts.join('');
            console.log(completeresponse);
            //parse the response JSON
            if (completeresponse != "") {
                var collection = JSON.parse(completeresponse).value;

                //loop through the results and write out the fullname
                collection.forEach(function (row, i) {
                    console.log(row['Product.name'] + ":" + row['Product.productid'] + ":" + row['name'] + ":" + row['defaultvaluestring']);

                });
            }
        });
    });
    crmrequest.on('error', function (e) {

        console.error(e);
    });
    //crmrequest.write(crmrequestoptions);
    //close the web api request
    crmrequest.end();
}